"""STEP 5 · Short-term memory: checkpointer + thread_id

    thread "A":  [msg1, msg2, msg3 ...]  ◄── saved after every step by the checkpointer
    thread "B":  [ ]                         a new thread starts empty

Run:  python -m steps.step5_short_term_memory
NEW in this step: InMemorySaver, config={"configurable": {"thread_id": ...}}.
"""
from langchain.agents import create_agent
from langgraph.checkpoint.memory import InMemorySaver

from agents.prompts import TOOLS_PROMPT
from config import get_llm
from tools import BASIC_TOOLS

agent = create_agent(get_llm(), tools=BASIC_TOOLS, system_prompt=TOOLS_PROMPT,
                     checkpointer=InMemorySaver())          # <- the only new line


def chat(text: str, thread: str) -> str:
    config = {"configurable": {"thread_id": thread}}        # <- which conversation
    return agent.invoke({"messages": [{"role": "user", "content": text}]}, config)["messages"][-1].content


print("[A]", chat("My name is Mahesh.", "A"))
print("[A]", chat("What is my name?", "A"))                 # remembered (same thread)
print("[B]", chat("What is my name?", "B"))                 # unknown (new thread)
print("\nStored in thread A:", len(agent.get_state({"configurable": {"thread_id": "A"}}).values["messages"]), "messages")
