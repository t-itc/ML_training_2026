"""Build docs/LangChain_Agents_Memory_Instructor_Guide.html (same visual style as the tutorial)."""
from __future__ import annotations

import html
import re
from pathlib import Path

SRC = Path(__file__).resolve().parent
OUT = SRC.parents[0] / "LangChain_Agents_Memory_Instructor_Guide.html"
TITLE = "Instructor Guide — Building AI Agents with LangChain, Tools & Memory"

PREP = ["Python 3.10+ and the project installed on the trainer laptop (pip install -r requirements.txt — pinned versions)",
        "Ollama running; ollama pull llama3.2:3b done (optional: qwen2.5:7b for a more reliable demo)",
        "pytest -q → 38 passed; steps/step1…step8 and every scripts/m*.py run once with your model",
        "Optional: ollama pull nomic-embed-text for the real-embeddings variant of m4_semantic_memory",
        "Learners got the zip + setup instructions the day before (model download is about 2 GB)",
        "storage/ cleared before class (delete storage/*.db) so demos start clean",
        "Tutorial HTML open in the browser, light theme, zoom 125% for the projector",
        "Terminal font size large; two terminals ready (needed for the --session 1/2 demo)",
        "Optional: Langfuse from the Guardrails session running (docker compose up -d) with keys in .env",
        "Backup plan rehearsed: LLM_PROVIDER=mock gives deterministic output for every demo"]

TAIL = """
<p class="muted" style="text-align:center;margin:30px 0">DS Training · Informationtechconsultants · Instructor Guide</p>
</div></main>
<button class="totop" id="toTop" aria-label="Back to top">↑</button>
<script>
(function(){"use strict";
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
$$(".code").forEach(b=>{const code=$("code",b);const raw=code.textContent.replace(/^\\n/,"").replace(/\\s+$/,"");code.textContent=raw;
  const h=document.createElement("div");h.className="ch";h.innerHTML='<span class="dots"><i></i><i></i><i></i></span><span class="ttl"></span><span class="lang"></span><button class="copy" type="button">Copy</button>';
  $(".ttl",h).textContent=b.dataset.title||"";$(".lang",h).textContent=b.dataset.lang||"";b.prepend(h);
  $(".copy",h).onclick=e=>{const ta=document.createElement("textarea");ta.value=raw;document.body.appendChild(ta);ta.select();try{document.execCommand("copy");e.target.textContent="✓ Copied";}catch(_){}ta.remove();};});
const sb=$("#sidebar");let grp="";$$("section.lesson").forEach(s=>{if(s.dataset.group!==grp){grp=s.dataset.group;const g=document.createElement("div");g.className="grp";g.textContent=grp;sb.appendChild(g);}
  const a=document.createElement("a");a.href="#"+s.id;a.innerHTML='<span class="n">•</span><span class="t"></span>';$(".t",a).textContent=s.dataset.title;a.onclick=()=>document.body.classList.remove("nav-open");sb.appendChild(a);});
const items=__PREP__;const host=$("#prepCheck");items.forEach(t=>{const l=document.createElement("label");l.innerHTML='<input type="checkbox"><span>'+esc(t)+'</span>';$("input",l).onchange=e=>l.classList.toggle("done",e.target.checked);host.appendChild(l);});
const root=document.documentElement,btn=$("#themeBtn");const sys=()=>matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";const cur=()=>root.getAttribute("data-theme")||sys();
const paint=()=>{btn.textContent=cur()==="dark"?"☀️":"🌙";};btn.onclick=()=>{root.setAttribute("data-theme",cur()==="dark"?"light":"dark");paint();};paint();
$("#printBtn").onclick=()=>{const p=root.getAttribute("data-theme");root.setAttribute("data-theme","light");print();setTimeout(()=>{p?root.setAttribute("data-theme",p):root.removeAttribute("data-theme");},500);};
addEventListener("beforeprint",()=>$$("details").forEach(d=>d.open=true));
$("#menuBtn").onclick=()=>document.body.classList.toggle("nav-open");
addEventListener("scroll",()=>{const h=document.documentElement;$("#scrollbar").style.width=(100*h.scrollTop/Math.max(1,h.scrollHeight-h.clientHeight))+"%";$("#toTop").classList.toggle("show",h.scrollTop>600);
  const mark=innerHeight*.35;let c=null;$$("section.lesson").forEach(s=>{if(s.getBoundingClientRect().top<=mark)c=s;});$("#curSec").textContent=c?c.dataset.title:"";
  $$("a",sb).forEach(a=>a.classList.toggle("active",!!c&&a.getAttribute("href")==="#"+c.id));},{passive:true});
$("#toTop").onclick=()=>scrollTo({top:0});
})();
</script>
</body></html>
"""


def main() -> None:
    import json

    head = (SRC / "00_head.html").read_text(encoding="utf-8").replace("__TITLE__", html.escape(TITLE))
    head = head.replace("AI Agents with LangChain, Tools &amp; Memory<small>DS Training · Agentic AI</small>",
                        "Instructor Guide<small>AI Agents with LangChain, Tools &amp; Memory</small>")
    head = head.replace('<div class="logo" aria-hidden="true">🤖</div>',
                        '<div class="logo" aria-hidden="true" style="background:linear-gradient(135deg,#b45309,#7c2d12)">🎓</div>')
    head = re.sub(r'<div class="prog".*?</div></div><b id="progPct">0%</b></div>', "", head, flags=re.S)
    head = re.sub(r'<button class="tb-btn grad" id="wbOpen".*?</button>', "", head, flags=re.S)
    body = (SRC / "ig_body.html").read_text(encoding="utf-8")
    doc = head + body + TAIL.replace("__PREP__", json.dumps(PREP, ensure_ascii=False))
    OUT.write_text(doc, encoding="utf-8")
    print(f"wrote {OUT.name} ({len(doc) // 1024} KB)")


if __name__ == "__main__":
    main()
