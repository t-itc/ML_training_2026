"""API request/response schemas and the LLM output schema (all strict: unknown fields are rejected)."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.config import get_policy

_REQ = get_policy()["request"]

Status = Literal["answered", "abstained", "blocked", "review", "pending_approval", "tool_result", "fallback"]
ToolName = Literal["get_leave_balance", "submit_leave_request", "update_bank_details", "escalate_to_hr"]


# ----------------------------------------------------------------------------- API
class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    message: str = Field(min_length=_REQ["min_message_chars"], max_length=_REQ["max_message_chars"],
                         description="The employee's question or request.")
    session_id: Optional[str] = Field(default=None, pattern=r"^[A-Za-z0-9_-]{1,64}$")

    @field_validator("message")
    @classmethod
    def no_control_chars(cls, v: str) -> str:
        if any(ord(c) < 32 and c not in "\n\t" for c in v):
            raise ValueError("control characters are not allowed")
        return v


class Citation(BaseModel):
    label: str
    doc_id: str
    title: str
    section: str


class Telemetry(BaseModel):
    mode: Literal["langfuse", "fallback"]
    trace_id: Optional[str] = None
    fallback_reason: Optional[str] = None


class ChatResponse(BaseModel):
    request_id: str
    status: Status
    answer: str
    citations: list[Citation] = []
    reason_code: str
    approval_id: Optional[str] = None
    policy_version: str
    telemetry: Telemetry


class ApprovalDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: Literal["approve", "reject"]
    comment: str = Field(default="", max_length=500)


# ----------------------------------------------------------------------------- LLM output
class ToolCall(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: ToolName
    arguments: dict = {}


class LLMOutput(BaseModel):
    """The ONLY shape we accept from the model. Anything else -> fallback."""
    model_config = ConfigDict(extra="forbid")

    answer: str = Field(max_length=4000)
    citations: list[str] = Field(default_factory=list, max_length=8)
    abstain: bool = False
    tool_call: Optional[ToolCall] = None
