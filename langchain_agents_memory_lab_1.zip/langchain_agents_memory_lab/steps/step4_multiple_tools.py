"""STEP 4 · Multiple tools: the LLM chooses which ones (and can call several at once)

                ┌─► calculator
    you ──► model ─► get_current_datetime      parallel tool calls in ONE step
                └─► get_weather · search_knowledge · query_employee

Run:  python -m steps.step4_multiple_tools
NEW in this step: a tool registry, automatic tool selection, parallel calls, tool errors.
"""
from langchain.agents import create_agent

from agents.prompts import TOOLS_PROMPT
from config import get_llm
from tools import BASIC_TOOLS   # calculator, get_current_datetime, get_weather, search_knowledge, query_employee

agent = create_agent(get_llm(), tools=BASIC_TOOLS, system_prompt=TOOLS_PROMPT)

for question in ["What is 250 multiplied by 12, and what is today's date?",
                 "How many leave days can I carry forward?",
                 "What's the weather in Atlantis?"]:            # a tool that returns an error
    result = agent.invoke({"messages": [{"role": "user", "content": question}]})
    called = [tc["name"] for m in result["messages"] if m.type == "ai" for tc in (m.tool_calls or [])]
    print(f"\nQ: {question}\n   tools: {called}\n   A: {result['messages'][-1].content[:150]}")
