"""Aria — the Intelligent Personal AI Assistant, built up in stages.

    basic       LLM + system prompt                              (Module 2)
    tools       + calculator, datetime, weather, search, database (Module 3)
    short_term  + checkpointer  (memory inside one thread)        (Module 4.3)
    long_term   + Store + memory tools (memory across threads)    (Module 4.4)
    agentic     + memory policy, retrieval before every call,
                  reflection after every turn                     (Module 4.5 / 5)
"""
from __future__ import annotations

from langchain.agents import create_agent
from langchain.agents.middleware import wrap_tool_call
from langchain.messages import ToolMessage

from agents.prompts import BASIC_PROMPT, MEMORY_PROMPT, TOOLS_PROMPT
from config import get_llm
from memory.agentic_memory import memory_injection, reflect_and_log
from memory.long_term import UserContext, get_store
from memory.short_term import get_checkpointer
from tools import ALL_TOOLS, BASIC_TOOLS, MEMORY_TOOLS

STAGES = ("basic", "tools", "short_term", "long_term", "agentic")


@wrap_tool_call
def handle_tool_errors(request, handler):
    """If a tool raises, return the error to the model as a ToolMessage instead of crashing the run."""
    try:
        return handler(request)
    except Exception as exc:  # noqa: BLE001 - we want every failure visible to the agent
        return ToolMessage(
            content=f"Error: tool '{request.tool_call['name']}' failed ({type(exc).__name__}: {exc}). "
                    "Tell the user and try another approach.",
            tool_call_id=request.tool_call["id"],
            name=request.tool_call["name"],
            status="error",
        )


def build_agent(stage: str = "agentic", *, llm=None, checkpointer=None, store=None, tools=None):
    """Create the assistant for a given stage. Pass checkpointer/store to share them between agents."""
    if stage not in STAGES:
        raise ValueError(f"stage must be one of {STAGES}")
    llm = llm or get_llm()

    if stage == "basic":
        return create_agent(llm, tools=[], system_prompt=BASIC_PROMPT, checkpointer=checkpointer)

    if stage in ("tools", "short_term"):
        if stage == "short_term" and checkpointer is None:
            checkpointer = get_checkpointer("memory")
        return create_agent(llm, tools=tools or BASIC_TOOLS, system_prompt=TOOLS_PROMPT,
                            middleware=[handle_tool_errors], checkpointer=checkpointer)

    checkpointer = checkpointer if checkpointer is not None else get_checkpointer("memory")
    store = store if store is not None else get_store("sqlite")

    if stage == "long_term":
        return create_agent(llm, tools=tools or ALL_TOOLS, system_prompt=MEMORY_PROMPT,
                            middleware=[handle_tool_errors], checkpointer=checkpointer,
                            store=store, context_schema=UserContext)

    # agentic: the prompt is rebuilt before EVERY model call with retrieved memories
    return create_agent(llm, tools=tools or (BASIC_TOOLS + MEMORY_TOOLS),
                        middleware=[memory_injection(TOOLS_PROMPT), reflect_and_log, handle_tool_errors],
                        checkpointer=checkpointer, store=store, context_schema=UserContext)


def ask(agent, text: str, *, thread_id: str | None = None, user_id: str | None = None,
        callbacks: list | None = None) -> tuple[str, dict]:
    """Send one user message; return (final answer text, full result state)."""
    config: dict = {}
    if thread_id:
        config["configurable"] = {"thread_id": thread_id}
    if callbacks:
        config["callbacks"] = callbacks
    kwargs = {"context": UserContext(user_id=user_id)} if user_id else {}
    result = agent.invoke({"messages": [{"role": "user", "content": text}]}, config=config, **kwargs)
    return result["messages"][-1].content, result


def tools_called(result: dict, since_last_human: bool = True) -> list[str]:
    msgs = result["messages"]
    if since_last_human:
        idx = max(i for i, m in enumerate(msgs) if m.type == "human")
        msgs = msgs[idx:]
    return [tc["name"] for m in msgs if m.type == "ai" for tc in (m.tool_calls or [])]
