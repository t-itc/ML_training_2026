"""Sparse (keyword) retrieval: TF-IDF and BM25."""
from __future__ import annotations

import re

import numpy as np
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer

from app.dense_retriever import Result, matches_filters

STOPWORDS = {
    "a", "an", "the", "is", "are", "am", "was", "be", "to", "of", "in", "on", "for", "and", "or",
    "what", "how", "do", "does", "i", "my", "me", "can", "with", "at", "by", "from", "it", "this",
    "that", "when", "much", "many", "each", "per", "any", "must", "may", "have", "has", "get",
}


def tokenize(text: str) -> list[str]:
    """Lowercase words and numbers; 'VPN-417' -> ['vpn', '417']. No stemming,
    so 'working' and 'work' are different tokens (a classic BM25 limitation)."""
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOPWORDS]


class BM25Retriever:
    def __init__(self, docs: list[dict], text_key: str = "text", k1: float = 1.5, b: float = 0.75):
        self.docs = docs
        self.corpus_tokens = [tokenize(d[text_key]) for d in docs]
        self.bm25 = BM25Okapi(self.corpus_tokens, k1=k1, b=b)

    def search(self, query: str, top_k: int = 5, filters: dict | None = None) -> list[Result]:
        scores = self.bm25.get_scores(tokenize(query))
        allowed = np.array([matches_filters(d, filters) for d in self.docs])
        scores = np.where(allowed, scores, -np.inf)
        order = np.argsort(-scores, kind="stable")[:top_k]
        # documents with score 0 share no query term - BM25 has no evidence for them
        return [Result(self.docs[i], float(scores[i]), "bm25") for i in order if scores[i] > 0]


class TfidfRetriever:
    def __init__(self, docs: list[dict], text_key: str = "text"):
        self.docs = docs
        self.vectorizer = TfidfVectorizer(tokenizer=tokenize, lowercase=False, token_pattern=None)
        self.matrix = self.vectorizer.fit_transform([d[text_key] for d in docs])    # sparse (n_docs, vocab)

    def search(self, query: str, top_k: int = 5, filters: dict | None = None) -> list[Result]:
        q = self.vectorizer.transform([query])
        scores = (self.matrix @ q.T).toarray().ravel()           # rows are L2-normalised -> cosine
        allowed = np.array([matches_filters(d, filters) for d in self.docs])
        scores = np.where(allowed, scores, -np.inf)
        order = np.argsort(-scores, kind="stable")[:top_k]
        return [Result(self.docs[i], float(scores[i]), "tfidf") for i in order if scores[i] > 0]
