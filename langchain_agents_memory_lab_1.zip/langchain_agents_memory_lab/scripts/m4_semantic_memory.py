"""Module 4B — semantic memory: save → embed → search in natural language → top-K → compare with keywords.

    python -m scripts.m4_semantic_memory                 # offline toy concept embeddings (explainable, 10 dims)
    python -m scripts.m4_semantic_memory --embed ollama  # real embeddings: ollama pull nomic-embed-text
    python -m scripts.m4_semantic_memory -k 2 -q "What language should code samples use?"
"""
import argparse

from memory.embeddings import DIMS, toy_vector
from memory.long_term import get_store, put_memory, search_memories
from scripts._common import LINE, banner

USER = "mahesh"
MEMORIES = [
    ("explanation_style", "User prefers explanations with Python examples", "preference"),
    ("role", "User is a Data Scientist", "profile"),
    ("tech_stack", "User primarily works with LangChain and LangGraph", "skill"),
    ("location", "User is based in Pune", "profile"),
    ("lesson_answer_length", "Feedback 'too long' → keep answers short (5-8 lines)", "feedback"),
]
QUERIES = [
    "Show me a programming-based explanation.",
    "Which city is my office in?",
    "Give me a brief summary of RAG.",
    "Recommend a portfolio idea for me.",
]


def fmt(items, k: int = 3) -> str:
    if not items:
        return "      (no match)"
    out = []
    for i in items[:k]:
        score = f"{i.score:.2f}" if getattr(i, "score", None) is not None else " kw "
        out.append(f"      {score}  {i.key:<22} {i.value['content']}")
    return "\n".join(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--embed", choices=["toy", "ollama"], default="toy")
    ap.add_argument("-k", type=int, default=3, help="top-K memories to retrieve")
    ap.add_argument("-q", "--query", help="your own natural-language query")
    args = ap.parse_args()
    banner(f"Module 4B · Keyword vs semantic memory retrieval (embeddings: {args.embed})")

    print("\n1) SAVE memories (the semantic store embeds each one on put())")
    keyword_store = get_store("memory")                                   # no index -> keyword overlap
    semantic_store = get_store("memory", semantic=True, embed=args.embed)  # vector index -> cosine similarity
    for key, content, cat in MEMORIES:
        put_memory(keyword_store, USER, key, content, cat)
        put_memory(semantic_store, USER, key, content, cat)                # embedded on put()

    for key, content, _ in MEMORIES:
        print(f"   {key:<22} {content}")

    print("\n2) EMBEDDINGS (text -> vector)")
    if args.embed == "toy":
        v = toy_vector(MEMORIES[0][1])
        print(f"   {MEMORIES[0][1]!r}\n   -> " + "  ".join(f"{d}={x:.2f}" for d, x in zip(DIMS, v) if x)
              + f"   (10 dims, the other {sum(1 for x in v if not x)} are 0)")
    else:
        from memory.embeddings import get_embeddings

        emb, dims = get_embeddings("ollama")
        v = emb.embed_query(MEMORIES[0][1])
        print(f"   {MEMORIES[0][1]!r}\n   -> {len(v)} numbers, first five: {[round(x, 3) for x in v[:5]]}")

    print(f"\n3) SEARCH in natural language, 4) keep the TOP-{args.k}, 5) COMPARE with keyword retrieval")
    for q in [args.query] if args.query else QUERIES:
        print("\n" + "-" * 88 + f"\nQuery: {q}")
        print("   KEYWORD  (word overlap):")
        print(fmt(search_memories(keyword_store, USER, q, k=args.k), args.k))
        print(f"   SEMANTIC (cosine similarity of embeddings, top-{args.k}):")
        print(fmt(search_memories(semantic_store, USER, q, k=args.k), args.k))
    print("\n" + LINE + "\nThe top-k semantic hits are what memory_injection() would add to the system prompt.")


if __name__ == "__main__":
    main()
