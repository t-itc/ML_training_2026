"""Every beginner step script and demo script runs end-to-end with the mock model."""
import runpy

import pytest

STEPS = ["step1_basic_llm", "step2_first_agent", "step3_custom_tool", "step4_multiple_tools",
         "step5_short_term_memory", "step6_long_term_memory", "step7_agentic_memory", "step8_complete_aria"]


@pytest.mark.parametrize("name", STEPS)
def test_step_runs(name, capsys):
    runpy.run_module(f"steps.{name}", run_name="__main__")
    assert capsys.readouterr().out.strip()


def test_tool_failure_demo(capsys):
    from scripts import m3_tool_failure

    m3_tool_failure.main()
    out = capsys.readouterr().out
    assert "run FAILED: ConnectionError" in out and "status=error" in out


def test_llm_extraction_path_uses_structured_output():
    from memory.agentic_memory import extract

    cands = extract("My name is Mahesh and I prefer short answers.", mode="llm")
    assert {c["key"] for c in cands} == {"name", "answer_length"}
