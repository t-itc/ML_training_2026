"""RAG chunking, embeddings and retrieval (teaching implementation)."""
