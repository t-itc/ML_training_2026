# AcmeHR assistant: guardrail policy

The machine-readable policy is `app/policy/policy.yaml`. This document explains it. Both are versioned together:
every change bumps `version`, and the release gate refuses to ship a policy whose hash was not evaluated against
the regression set (`python -m eval.run_regression && python -m scripts.release_gate`).

Current version: **2026.11.1**

## 1. Request limits

| Layer | Limit | Response |
|---|---|---|
| HTTP body | 8 192 bytes (`request.max_body_bytes`) | 413 |
| Schema `message` | 1–2 000 characters, no control characters | 422 (field and error type only; input never echoed) |
| Schema extras | unknown fields rejected (`extra="forbid"`): a client cannot send `roles` | 422 |
| `session_id` | `^[A-Za-z0-9_-]{1,64}$` | 422 |

## 2. Input policy (deterministic)

Signals are evaluated in this order; the first deciding signal wins. **block > review > allow**.

| # | Signal | Detector | Decision | `reason_code` |
|---|---|---|---|---|
| 1 | Secret in message (password, API key, AWS key, private key, JWT) | `pii.SECRET_PATTERNS` | block | `secret_in_message` |
| 2 | PII type whose action is `block` (Aadhaar, card, bank account) | `pii.apply_pii_policy` | block | `pii_not_accepted` |
| 3 | Prompt-injection rule score ≥ 0.6 | `input_policy.INJECTION_RULES` | block | `prompt_injection` |
| 3b | Injection score 0.25–0.6 | same | allow + flag `injection_suspected` | `ok` |
| 4 | Sensitive topic: harassment, wellbeing, legal | keyword lists | **review** (human) | `sensitive_<category>` |
| 5 | No HR keyword | allow-list | block | `off_topic` |

**Review route.** A `review` decision never produces an automated answer. It creates a confidential item
(`kind=review`) in the approval queue for `hr_admin`, returns a reference, and for the wellbeing category adds a
pointer to emergency services / the Employee Assistance Programme.

## 3. PII policy

| Type | Example | To the LLM | In traces / logs / approval queue |
|---|---|---|---|
| EMAIL | ravi@gmail.com | redacted `<EMAIL>` | masked |
| PHONE | +91 98765 43210 | redacted `<PHONE>` | masked |
| PAN | ABCDE1234F | redacted `<PAN>` | masked |
| EMPLOYEE_ID | E1001 | kept (needed for HR context) | masked in content; the authenticated employee ID is the trace `user_id` (pseudonymous) |
| AADHAAR | 2345 6789 0123 | **request blocked** | masked |
| CARD (Luhn-valid) | 4111 1111 1111 1111 | **request blocked** | masked |
| BANK_ACCOUNT | "account number is 123456789012" | **request blocked** (bank changes use the secure form) | masked |
| Secrets | password, keys, tokens | **request blocked** | masked |

Company addresses (`@acme.example`) are not personal data and are not redacted.
Masking is applied by the Langfuse client `mask` function (all span inputs, outputs, metadata), by the telemetry
fallback writer, and by the approval queue. Names are never logged. Message text is never written to the fallback log.

## 4. Retrieval and authorization

* Roles come only from the authenticated principal (`data/users.json` in the demo; OIDC/JWT in production).
* `data/documents/catalog.json` is the **source of truth** for document access (`allowed_roles`).
* Pre-filter: the vector query has a `where` filter on ACL metadata copied into the index.
* Post-filter: each hit is re-checked against the catalog. Mismatches are dropped and counted as
  `acl_violations` (trace score; alert on > 0 - it means the index is stale or tampered).
* Similarity thresholds are calibrated per embedder (`minilm: 0.30`, `hashing: 0.15`). No chunk above the threshold →
  abstain without calling the LLM.
* Chunks whose injection score ≥ 0.6 are quarantined and never reach the prompt (`quarantine_injected_chunks`).

## 5. Prompt

Retrieved text is untrusted data: sanitised (tags, `[INST]`, delimiters neutralised), wrapped in blocks with a random
per-request boundary, and the system prompt states that document content cannot change rules or request tools.
The model must return `{"answer", "citations", "abstain", "tool_call": null}`. A random canary detects prompt leaks.

## 6. Output policy

| Check | Result |
|---|---|
| Not valid JSON / schema violation | fallback (`output_policy:invalid_json` / `schema:*`) |
| Canary in answer | fallback (`prompt_leak`) |
| Secret in answer | fallback |
| PII in answer | masked, flagged |
| Citation label not in the prompt | dropped, flagged |
| Answer > 1 200 chars | truncated, flagged |
| `tool_call` not null | **fallback** + `tool_call_rejected` score: the model followed instructions from somewhere else |
| No citations | abstain |
| Groundedness < 0.6 | abstain |

Groundedness = LLM judge (Ollama) with a deterministic number check (an invented number scores 0), or the
lexical check alone in mock/CI mode.

## 7. Tools and human approval

| Tool | Impact | Path |
|---|---|---|
| `get_leave_balance` | low | executed immediately; caller's own data only |
| `submit_leave_request` | high | approval by `hr_admin` |
| `update_bank_details` | high | approval by `hr_admin`; no account numbers collected in chat |
| `escalate_to_hr` | high | approval by `hr_admin` |

* Tools are selected only by deterministic intent rules on the **user** message, per sentence; questions
  ("how do I change my bank account?") are informational, requests ("please update my bank details") are actions.
* Arguments come from the authenticated principal and deterministic extraction (dates), never from model output.
* Approvals: role check, no self-approval, atomic claim (no double execution), decision recorded as a Langfuse score
  on the original trace.

## 8. Changing this policy

1. Edit `policy.yaml`, bump `version`, update this document.
2. `python -m eval.run_regression` (deterministic) and, for release candidates, `--live`.
3. `python -m scripts.release_gate` must pass: same policy hash as evaluated, all critical cases pass,
   pass rates ≥ `eval/baseline.json`.
4. Add a regression case for every incident or false positive you fix.
