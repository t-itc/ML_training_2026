"""Output schema + policy validation, and groundedness evaluation with abstention."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from pydantic import ValidationError

from app.config import get_policy, get_settings
from app.llm import content_words, get_llm, parse_json
from app.policy.pii import detect_pii, detect_secrets, mask_text
from app.prompting import PromptPackage
from app.schemas import LLMOutput


@dataclass
class OutputCheck:
    ok: bool                                   # False -> safe fallback
    output: LLMOutput | None
    violations: list[str] = field(default_factory=list)   # machine-readable policy violations
    answer: str = ""                           # answer after redaction


def validate_output(raw: str, pkg: PromptPackage) -> OutputCheck:
    """1) strict schema  2) policy: canary, secrets, PII, citations, length. Tool calls are judged elsewhere."""
    data = parse_json(raw)
    if data is None:
        return OutputCheck(False, None, ["invalid_json"])
    try:
        out = LLMOutput.model_validate(data)
    except ValidationError as e:
        return OutputCheck(False, None, [f"schema:{err['loc'][0] if err['loc'] else 'root'}" for err in e.errors()][:5])

    v: list[str] = []
    answer = out.answer.strip()
    if pkg.canary in answer:
        return OutputCheck(False, out, ["prompt_leak"])
    if detect_secrets(answer):
        return OutputCheck(False, out, ["secret_in_output"])
    if detect_pii(answer):
        v.append("pii_redacted_in_output")
        answer = mask_text(answer)
    unknown = [c for c in out.citations if c not in pkg.labels]
    if unknown:
        v.append("unknown_citation")
        out.citations = [c for c in out.citations if c in pkg.labels]
    if len(answer) > get_policy()["output"]["max_answer_chars"]:
        v.append("answer_truncated")
        answer = answer[: get_policy()["output"]["max_answer_chars"]].rsplit(" ", 1)[0] + "…"
    if out.tool_call is not None:
        # The system prompt says tool_call must be null. A model that proposes one has followed
        # instructions from somewhere else (usually injected content): the whole output is untrusted.
        return OutputCheck(False, out, v + ["tool_call_proposed"], answer)
    return OutputCheck(True, out, v, answer)


# ----------------------------------------------------------------------------- groundedness
JUDGE_PROMPT = """You are a strict fact-checker. Compare the ANSWER with the SOURCES.
Every factual claim (numbers, days, amounts, rules, names) in the ANSWER must be supported by the SOURCES.

SOURCES:
<<<{sources}>>>

ANSWER:
<<<{answer}>>>

Reply with JSON only: {{"score": 0.0-1.0, "unsupported_claims": ["..."]}}"""

_NUM = re.compile(r"\b\d[\d,]*(?:\.\d+)?\b")


def lexical_groundedness(answer: str, sources: str) -> tuple[float, list[str]]:
    """Deterministic fallback: answer content words and every number must appear in the cited sources."""
    aw, sw = content_words(answer), content_words(sources)
    word_support = len(aw & sw) / len(aw) if aw else 1.0
    nums = _NUM.findall(answer)
    missing_nums = [n for n in nums if n not in sources]
    num_support = 1 - len(missing_nums) / len(nums) if nums else 1.0
    unsupported = [f"number {n}" for n in missing_nums] + sorted(aw - sw)[:5]
    return round(min(word_support, num_support), 3), unsupported


@dataclass
class Groundedness:
    score: float
    method: str
    unsupported: list[str]


def evaluate_groundedness(answer: str, cited_text: str) -> Groundedness:
    s = get_settings()
    if s.use_llm_judge and s.llm_provider == "ollama":
        raw = get_llm().complete("You output JSON only.", JUDGE_PROMPT.format(sources=cited_text, answer=answer),
                                 name="judge.groundedness", model=s.judge_model)
        data = parse_json(raw) or {}
        try:
            score = max(0.0, min(1.0, float(data.get("score", 0))))
        except (TypeError, ValueError):
            score = 0.0                                   # unparseable verdict -> fail closed
        # Numbers are always checked deterministically: an invented number is a hard failure.
        _, lex_unsupported = lexical_groundedness(answer, cited_text)
        bad_numbers = [u for u in lex_unsupported if u.startswith("number ")]
        claims = [str(c) for c in data.get("unsupported_claims", [])][:5] + bad_numbers
        return Groundedness(0.0 if bad_numbers else round(score, 3), "llm-judge+numbers", claims)
    score, unsupported = lexical_groundedness(answer, cited_text)
    return Groundedness(score, "lexical", unsupported)
