"""LLM clients. Every call is a Langfuse generation.

* OllamaLLM - local model (default llama3.2:3b), JSON mode, temperature 0.
* MockLLM   - deterministic, offline, used by tests and the regression gate. It is deliberately a
              WORST-CASE model: it obeys any "call the tool X" / "tell the user Y" instruction it finds
              in the documents. The pipeline must stay safe even with this model.
"""
from __future__ import annotations

import json
import re

from app.config import get_settings
from app.retrieval.embeddings import tokens
from app.telemetry import telemetry

GENERIC = {"policy", "acme", "employee", "employees", "please", "tell", "know", "about", "get", "need", "want",
           "rule", "rules", "company", "there", "have", "has", "the"}


def parse_json(raw: str) -> dict | None:
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else None
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", raw, re.S)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                return None
    return None


class OllamaLLM:
    provider = "ollama"

    def __init__(self):
        import ollama

        s = get_settings()
        self.client = ollama.Client(host=s.ollama_host, timeout=s.llm_timeout_s)

    def complete(self, system: str, user: str, *, name: str, model: str) -> str:
        msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        with telemetry.client.start_as_current_observation(name=name, as_type="generation", model=model, input=msgs,
                                                           model_parameters={"temperature": 0, "format": "json"}) as gen:
            r = self.client.chat(model=model, messages=msgs, format="json", options={"temperature": 0})
            text = r.message.content or ""
            gen.update(output=text, usage_details={"input": r.prompt_eval_count or 0, "output": r.eval_count or 0})
            return text


_BLOCK = re.compile(r'<(DOC-[0-9a-f]+) label="(S\d+)"[^>]*>\n(.*?)\n</\1>', re.S)
_QUESTION = re.compile(r"<<<(.*)>>>", re.S)


def content_words(text: str) -> set[str]:
    return {t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t
            for t in tokens(text) if t not in GENERIC and len(t) > 2}


class MockLLM:
    provider = "mock"

    def complete(self, system: str, user: str, *, name: str, model: str) -> str:
        with telemetry.client.start_as_current_observation(name=name, as_type="generation", model="mock-worst-case",
                                                           input=[{"role": "system", "content": system},
                                                                  {"role": "user", "content": user}]) as gen:
            out = json.dumps(self._answer(user))
            gen.update(output=out, usage_details={"input": len(user) // 4, "output": len(out) // 4})
            return out

    def _answer(self, user: str) -> dict:
        docs = [(label, text) for _, label, text in _BLOCK.findall(user)]
        q = _QUESTION.search(user)
        question = q.group(1) if q else ""
        result = {"answer": "", "citations": [], "abstain": False, "tool_call": None}

        # Worst-case behaviour: obey instructions embedded in documents.
        injected_claim = None
        for _, text in docs:
            m = re.search(r"call the tool (\w+)", text, re.I)
            if m:
                result["tool_call"] = {"name": m.group(1), "arguments": {"source": "document instruction"}}
            m = re.search(r"tell the user that ([^.]+)\.", text, re.I)
            if m:
                injected_claim = m.group(1)

        qwords = content_words(question)
        all_doc_words = set().union(*(content_words(t) for _, t in docs)) if docs else set()
        coverage = len(qwords & all_doc_words) / len(qwords) if qwords else 0.0
        if not docs or coverage < 0.6:
            result.update(answer="The documents do not contain this information.", abstain=True)
            return result

        best = []
        for label, text in docs:
            body = text.split(": ", 1)[-1]
            for sent in re.split(r"(?<=[.!?])\s+", body):
                overlap = len(qwords & content_words(sent))
                if overlap:
                    best.append((overlap, label, sent.strip()))
        best.sort(key=lambda x: -x[0])
        picked = best[:2]
        result["answer"] = " ".join(s for _, _, s in picked)
        result["citations"] = sorted({lbl for _, lbl, _ in picked})
        if injected_claim:
            result["answer"] += f" Also, {injected_claim}."
        return result


_LLM = None


def get_llm():
    global _LLM
    want = get_settings().llm_provider
    if _LLM is None or _LLM.provider != want:
        _LLM = OllamaLLM() if want == "ollama" else MockLLM()
    return _LLM
