# Expense Reimbursement Policy

## Submission deadline
Expense claims must be submitted in SpendWise within 30 calendar days of the expense date. Claims submitted 31 to 90 days late need Finance Controller approval. Claims older than 90 days are not reimbursed.

## Receipts
Original receipts are mandatory for any expense above INR 500.

## Travel
Domestic hotel stays are reimbursed up to INR 6,000 per night in metro cities and INR 4,000 per night elsewhere.
