"""Second-stage reranking with a cross-encoder."""
from __future__ import annotations

from app.dense_retriever import Result

DEFAULT_RERANKER = "cross-encoder/ms-marco-MiniLM-L-6-v2"


class Reranker:
    """A cross-encoder reads (query, document) TOGETHER and outputs one relevance
    score. More accurate than comparing two separate embeddings, but it must run
    once per candidate at query time - so only rerank a short candidate list."""

    def __init__(self, model_name: str = DEFAULT_RERANKER):
        from sentence_transformers import CrossEncoder       # lazy import (heavy)
        try:
            self.model = CrossEncoder(model_name)
        except Exception as exc:
            raise RuntimeError(f"Could not load {model_name}: {exc}. "
                               "The first run needs internet access to download the model.") from exc

    def rerank(self, query: str, candidates: list[Result], top_k: int | None = None) -> list[Result]:
        if not candidates:
            return []
        pairs = [(query, r.doc["text"]) for r in candidates]
        scores = self.model.predict(pairs)        # raw relevance scores (logits), higher = more relevant
        reranked = sorted(zip(candidates, scores), key=lambda x: -float(x[1]))
        out = [Result(r.doc, float(s), "rerank") for r, s in reranked]
        return out[:top_k] if top_k else out
