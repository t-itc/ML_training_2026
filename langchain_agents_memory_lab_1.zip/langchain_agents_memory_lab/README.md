# Building AI Agents with LangChain, Tools & Memory — Lab

Build **Aria**, an intelligent personal AI assistant, in five stages: a basic LangChain agent → custom
**tools** → **short-term memory** (LangGraph checkpointer + `thread_id`) → **long-term memory**
(LangGraph Store + per-user namespaces) → **agentic memory** (the agent decides what to remember,
retrieves memories before every model call, updates stale facts and learns from feedback).
It runs locally with Ollama (`llama3.2:3b`). OpenAI is optional, and an offline mock model lets every
test and demo run without any LLM.

```
                    config={"configurable": {"thread_id": ...}}   context=UserContext(user_id)
 user ─► main.py ─► ┌──────────────────────── create_agent(...)  (LangGraph graph) ───────────────────────┐
                    │  @dynamic_prompt memory_injection ──► model node ◄──► tools node ──► @after_agent    │
                    │  (retrieve memories → system prompt)   (LLM)      calculator · datetime   reflect_and_log│
                    │                                                    weather · search · db (episodes,   │
                    │                                                    save/search/delete     missed facts)│
                    │                                                    memory, profile                    │
                    └───────────┬──────────────────────────────────────────────┬──────────────────────────┘
                                │ short-term                                    │ long-term + agentic
                     SqliteSaver / InMemorySaver                      SqliteStore / InMemoryStore
                     storage/checkpoints.db  (per thread_id)          storage/memory.db  ((user, "memories"), (user, "episodes"))
```

Tested with **langchain 1.5.1 · langchain-core 1.8.3 · langgraph 1.2.22 · langgraph-checkpoint-sqlite 3.1.3 ·
langchain-ollama 1.1.0 · langchain-openai 1.8.1 · Python 3.13** (3.10+ supported). `requirements.txt` pins exactly
these versions; `requirements-lock.txt` freezes every transitive dependency (`pip install -r requirements-lock.txt`
gives an identical environment); `requirements-flex.txt` has version ranges as a fallback. Verified: a clean virtual
environment built from `requirements.txt` passes all 38 tests and runs every script with the mock model.

---

## 1. Project structure

```text
langchain_agents_memory_lab/
├── main.py                  Interactive chat with Aria (any stage, persistent memory, /commands)
├── config.py                Settings from .env + get_llm()  (ollama | openai | mock)
├── agents/
│   ├── assistant_agent.py   build_agent(stage) · ask() · tools_called() · handle_tool_errors middleware
│   ├── prompts.py           System prompts per stage
│   ├── mock_llm.py          ScriptedToolModel: offline rule-based model that speaks the tool-calling protocol
│   └── observability.py     AgentTracer callback (LLM/tool events, tokens, latency) + optional Langfuse
├── tools/
│   ├── calculator.py        Safe AST arithmetic (no eval)
│   ├── datetime_tool.py     Current date/time for an IANA time zone
│   ├── weather.py           Sample data (offline) or Open-Meteo (WEATHER_MODE=live)
│   ├── search.py            Keyword search over Acme HR/IT policies + AI notes
│   ├── database.py          Parameterised SQLite employee lookup
│   └── memory_tools.py      save_memory · search_memory · get_user_profile · delete_memory (ToolRuntime)
├── memory/
│   ├── short_term.py        get_checkpointer() (InMemorySaver / SqliteSaver), thread helpers
│   ├── long_term.py         get_store() (InMemoryStore / SqliteStore), namespaces, put/search/episodes
│   ├── agentic_memory.py    Memory policy, extraction, @dynamic_prompt retrieval, @after_agent reflection
│   └── embeddings.py        Semantic search: Ollama nomic-embed-text or offline ToyConceptEmbeddings (teaching)
├── data/                    knowledge_base.json · employees.csv · weather.json
├── storage/                 checkpoints.db · memory.db · acme.db (created at run time, git-ignored)
├── steps/                   Beginner coding path: one runnable file per concept
│   ├── step1_basic_llm.py        a chat model call
│   ├── step2_first_agent.py      create_agent
│   ├── step3_custom_tool.py      @tool + validation
│   ├── step4_multiple_tools.py   tool selection, parallel calls
│   ├── step5_short_term_memory.py  checkpointer + thread_id
│   ├── step6_long_term_memory.py   Store + ToolRuntime + context
│   ├── step7_agentic_memory.py     @dynamic_prompt + policy
│   └── step8_complete_aria.py      the complete agent (build_agent("agentic"))
├── scripts/
│   ├── m2_first_agent.py    Module 2 · first agent, no tools (--graph: LangGraph nodes/edges)
│   ├── m3_tools.py          Module 3 · tool selection, parallel calls, tool errors
│   ├── m3_tool_failure.py   Module 3.5 · a raising tool with vs without the error middleware
│   ├── m4_short_term.py     Module 4.3 · checkpointer + thread_id, restart comparison (--phase write/read)
│   ├── m4_long_term.py      Module 4.4 · Store across sessions (--session 1 / 2)
│   ├── m4_agentic.py        Module 4.5 · policy, retrieval, feedback, updates, episodes
│   ├── m4_extraction.py     Module 4.5 · rule-based vs LLM-based memory extraction, side by side
│   ├── m4_semantic_memory.py       Module 4B · keyword vs semantic (embedding) memory retrieval
│   ├── m5_scenarios.py      Module 5 · the 7 end-to-end test scenarios (PASS/FAIL table)
│   └── m6_inspect.py        Module 6 · stream steps, tool failures, tokens/latency, memory retrieval debug
├── tests/                   38 offline pytest tests (mock LLM, temp storage)
├── notebooks/               langchain_agents_memory_lab.ipynb (guided lab) + make_notebook.py (generator)
├── docs/                    LangChain_Agents_Memory_Tutorial.html + Instructor_Guide.html + src/ (build.py)
├── .env.example  requirements.txt (pinned)  requirements-lock.txt (full lock)  requirements-flex.txt  .gitignore
```

## 2. Setup

### Windows (PowerShell)

```powershell
cd langchain_agents_memory_lab
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
ollama pull llama3.2:3b          # install Ollama first: https://ollama.com/download
pytest -q
```

### macOS / Linux

```bash
cd langchain_agents_memory_lab
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
ollama pull llama3.2:3b
pytest -q
```

To use OpenAI instead, set `LLM_PROVIDER=openai`, `OPENAI_API_KEY=...` and `OPENAI_MODEL` in `.env`.
To run everything without an LLM, set `LLM_PROVIDER=mock`
(PowerShell: `$env:LLM_PROVIDER="mock"`, bash: `export LLM_PROVIDER=mock`).

## 3. Run

**Beginner coding path** (teach in this order, line by line):

```bash
python -m steps.step1_basic_llm          # 1 basic LLM
python -m steps.step2_first_agent        # 2 first agent
python -m steps.step3_custom_tool        # 3 one custom tool
python -m steps.step4_multiple_tools     # 4 multiple tools
python -m steps.step5_short_term_memory  # 5 short-term memory
python -m steps.step6_long_term_memory   # 6 long-term memory
python -m steps.step7_agentic_memory     # 7 agentic memory
python -m steps.step8_complete_aria      # 8 complete Aria
```

**Module demos and the app:**

```bash
python -m scripts.m2_first_agent --graph      # Module 2 · the LangGraph graph behind create_agent
python -m scripts.m2_first_agent --trace      # Module 2
python -m scripts.m3_tools                    # Module 3
python -m scripts.m3_tools -q "What's the weather in Pune and who is Arjun's manager?"
python -m scripts.m3_tool_failure             # intentional tool failure: with vs without middleware
python -m scripts.m4_short_term               # Module 4.3   (part 5 = restart comparison)
python -m scripts.m4_short_term --phase write --saver sqlite   # two-process restart test, then:
python -m scripts.m4_short_term --phase read  --saver sqlite
python -m scripts.m4_long_term --session 1    # Module 4.4   then, in a NEW terminal:
python -m scripts.m4_long_term --session 2
python -m scripts.m4_agentic                  # Module 4.5
python -m scripts.m4_extraction               # Module 4.5 rules vs LLM extraction
python -m scripts.m4_semantic_memory                 # Module 4B (offline toy embeddings)
python -m scripts.m4_semantic_memory --embed ollama  # Module 4B with real embeddings (ollama pull nomic-embed-text)
python -m scripts.m5_scenarios                # Module 5 test scenarios
python -m scripts.m6_inspect                  # Module 6

python main.py                                # chat with Aria (agentic stage, user "mahesh")
python main.py --trace --user priya           # print every LLM/tool event, another user
python main.py --stage tools                  # compare with an earlier stage

pytest -q                                     # 38 offline tests
jupyter notebook notebooks/langchain_agents_memory_lab.ipynb
python docs/src/build.py                      # rebuild the tutorial (walkers use the real code)
python docs/src/build_guide.py                # rebuild the instructor guide
```

Chat commands in `main.py`: `/new` `/thread <id>` `/user <id>` `/memories` `/episodes` `/history` `/trace` `/forget-all` `/help` `/quit`.
Threads are scoped per user (`mahesh:default` ≠ `priya:default`), and `/user` starts a fresh thread, so one user's
conversation history can never appear for another user.

> **About the mock model:** `LLM_PROVIDER=mock` is a scripted, rule-based test double. It speaks the real tool-calling
> protocol so the graph, tools, checkpointer, store and middleware really run, but it does **not** reason. Use it for
> tests and as a classroom fallback, never to judge agent quality.

## 4. Expected output

`python -m scripts.m3_tools` (recorded with `LLM_PROVIDER=mock`; Ollama wording and timings differ):

```
Registered tools: calculator, get_current_datetime, get_weather, search_knowledge, query_employee
----------------------------------------------------------------------------------------
   [     7 ms] llm         ms=1 in_tok=188 out_tok=55 decision=call calculator,get_current_datetime
   [    10 ms] tool_start  tool=get_current_datetime input={'timezone': 'Asia/Kolkata'}
   [    11 ms] tool_end    ms=1 status=ok output=Today is Wednesday, 18 November 2026. Current time is 22:27 ...
   [    11 ms] tool_start  tool=calculator input={'expression': '250 * 12'}
   [    12 ms] tool_end    ms=0 status=ok output=250 * 12 = 3,000
   [    14 ms] llm         ms=0 in_tok=211 out_tok=23 decision=final answer

User : What is 250 multiplied by 12, and what is today's date?
Tools: calculator, get_current_datetime
Aria : 250 × 12 = 3,000. Today is Wednesday, 18 November 2026. Current time is 22:27 (Asia/Kolkata).
   steps: 2 LLM call(s), 2 tool call(s), 14 ms
```

`python -m scripts.m5_scenarios`:

```
#  Scenario                  Expected behaviour                        Result
1  Ask a calculation         calls calculator                          PASS
2  Ask today's date          calls get_current_datetime                PASS
3  Share user preference     saves relevant memory                     PASS
4  Ask follow-up question    uses short-term memory (same thread)      PASS
5  Start new session         retrieves long-term memory (new thread)   PASS
6  Give feedback             updates agentic memory (lesson)           PASS
7  Related question later    uses preference + lesson                  PASS

7/7 scenarios passed
```

With the mock all 7 pass deterministically. With `llama3.2:3b` results vary between runs (small models
sometimes skip a tool or a memory write). `qwen2.5:7b` or an OpenAI model are more reliable.

`python -m scripts.m4_semantic_memory` (offline toy embeddings):

```
Query: Show me a programming-based explanation.
   KEYWORD  (word overlap):
       kw   location               User is based in Pune          <- matched the word "based"
       kw   role                   User is a Data Scientist
   SEMANTIC (cosine similarity of embeddings, top-3):
      0.95  explanation_style      User prefers explanations with Python examples
```

## 5. Configuration (`.env`)

| Variable | Default | Meaning |
|---|---|---|
| `LLM_PROVIDER` | `ollama` | `ollama` (local), `openai` (needs `OPENAI_API_KEY`), `mock` (offline, scripted) |
| `CHAT_MODEL` | `llama3.2:3b` | Ollama model; must support tool calling (`llama3.1`, `qwen2.5`, …) |
| `OLLAMA_BASE_URL` | `http://localhost:11434` | Ollama server |
| `OPENAI_MODEL` | `gpt-4.1-mini` | Any current OpenAI chat model with tool calling |
| `TEMPERATURE` | `0` | Lower = more repeatable tool choice |
| `USER_ID` | `mahesh` | Default user for `main.py` (long-term memory namespace) |
| `STORAGE_DIR` | `storage` | Where `checkpoints.db`, `memory.db`, `acme.db` live |
| `MEMORY_TOP_K` | `5` | Max relevant memories injected per model call (agentic stage) |
| `AUTO_REFLECT` | `true` | After-agent reflection: log episodes + save facts the agent missed |
| `REFLECTION_MODE` | `rules` | Extractor used by reflection: `rules` (regex) or `llm` (`with_structured_output`) |
| `WEATHER_MODE` | `offline` | `live` = Open-Meteo API (free, no key) with offline fallback |
| `LANGSMITH_TRACING`, `LANGSMITH_API_KEY` | – | Optional LangSmith tracing (no code change) |
| `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_BASE_URL` | – | Optional Langfuse tracing (`pip install langfuse`) |

## 6. Troubleshooting

| Symptom | Fix |
|---|---|
| `Failed to connect to Ollama` / `ConnectionError` | Start Ollama (app or `ollama serve`); check `OLLAMA_BASE_URL`; `ollama pull llama3.2:3b` |
| `... does not support tools` | Use a tool-capable model: `llama3.2`, `llama3.1`, `qwen2.5`, `mistral-nemo` |
| Agent answers math without calling the calculator | Small-model behaviour: keep `TEMPERATURE=0`, check tool docstrings/prompt rules, try `qwen2.5:7b` |
| Error saying the checkpointer requires a `thread_id` | Pass `config={"configurable": {"thread_id": "..."}}` when a checkpointer is set |
| Agent forgets after restart | `InMemorySaver`/`InMemoryStore` live in RAM; use `get_checkpointer("sqlite")` / `get_store("sqlite")` |
| Memories leak between users | Always pass `context=UserContext(user_id=...)`; never let the LLM choose the user id |
| `runtime` shows up in the tool schema | Annotate exactly `runtime: ToolRuntime` (from `langchain.tools`) |
| `ZoneInfoNotFoundError` on Windows | `pip install tzdata` (in `requirements.txt`) |
| `ImportError` for `AgentExecutor` / `ConversationBufferMemory` | Pre-1.0 code; use `create_agent` + a checkpointer |
| Pinned install fails on your Python | `pip install -r requirements-flex.txt` |
| `m4_semantic_memory --embed ollama`: model not found | `ollama pull nomic-embed-text`, or run without `--embed` (offline toy embeddings) |
| Demo state is messy | `/forget-all` in `main.py` or delete `storage/*.db` |
| `LLM_PROVIDER=openai` → authentication error | Set `OPENAI_API_KEY` in `.env` (never in code) |

## 7. Memory governance (what the lab does, and what it does not)

| Concern | In this lab | Add in production |
|---|---|---|
| User isolation | Namespace `(user_id, …)`; `user_id` from `context` (never from the LLM); threads scoped per user | User id from authentication; tenant id in namespaces |
| Sensitive data | Rule-based `evaluate()` rejects secrets; episodes redacted | Dedicated PII detection (e.g. Presidio), encryption at rest |
| Prompt injection / memory poisoning | Instruction-like "memories" rejected; prompt says memories are data | Review high-impact writes; keep memories out of the instruction block |
| Update / deletion | Stable keys + versions, `delete_memory`, `/forget-all` | User-facing "forget me", audit log |
| Retention | – | Store TTL, e.g. `SqliteStore(conn, ttl={"default_ttl": 60*24*90})` (minutes) |
| Sensitive actions | Read-only tools | `HumanInTheLoopMiddleware` approvals |

The policy is **rule-based**: good for teaching and as a first filter, not a complete enterprise security control.
"Learning" from feedback is memory-based adaptation (lessons injected into the prompt); model weights never change.

## 8. Toward production

* **Persistence:** `PostgresSaver` (`langgraph-checkpoint-postgres`) and `PostgresStore` with pgvector for semantic memory search.
* **Semantic memory:** `get_store("sqlite", semantic=True)` (Ollama `nomic-embed-text` + sqlite-vec) or your vector DB behind `search_memory`.
* **Privacy & governance:** keep the memory policy, add PII redaction (Guardrails session), user-facing "what do you remember / forget me", memory TTL (`ttl=` on the Store), audit fields (`source`, `version`).
* **Context control:** `SummarizationMiddleware` for long threads; cap `MEMORY_TOP_K`; periodically compress episodes into lessons.
* **Safe actions:** `HumanInTheLoopMiddleware` for side-effect tools; `ToolCallLimitMiddleware` / `ModelCallLimitMiddleware` against loops.
* **Serving (capstone):** wrap `ask()` in FastAPI (Day 1) + Docker Compose with Ollama (Day 2) + Langfuse tracing and evaluation (Guardrails session); take `user_id` from authentication.
* **Quality loop:** trace everything (Langfuse/LangSmith), build eval sets from real conversations, re-run `m5_scenarios`-style evals on every prompt/tool/model change.
