"""Run everything and write reports/TEST_REPORT.md.

    python -m scripts.test_report

1. pytest (unit, API, acceptance) -> reports/junit.xml
2. regression set (deterministic) -> reports/regression_results.json + regression_report.md
3. release gate
"""
from __future__ import annotations

import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"

ACCEPTANCE = [
    ("TestUnauthorizedDocumentsNeverEnterThePrompt", "Unauthorized documents never enter the prompt"),
    ("TestInjectionInRetrievedContentDoesNotTriggerTools", "Injection in retrieved content does not trigger tool execution"),
    ("TestUnsupportedQuestionsAbstain", "Unsupported questions abstain"),
    ("TestEveryRequestHasATraceOrDocumentedFallback", "Every request has a trace or an explicitly documented telemetry failure path"),
    ("TestLogsAndTracesDoNotExposePII", "Logs and traces do not expose unnecessary PII or secrets"),
    ("TestPolicyChangeIsEvaluatedBeforeRelease", "A policy change is evaluated against the regression set before release"),
]
REQUIREMENTS = [
    ("1. FastAPI request schema and input size limit", "app/schemas.py, app/main.py (body_size_limit)", "test_api.py"),
    ("2. Input policy with deterministic signals and a review route", "app/policy/input_policy.py, policy.yaml `input`", "test_policies.py, test_api.py::test_review_route_creates_review_item"),
    ("3. PII detection/redaction according to a documented policy", "app/policy/pii.py, policy.yaml `pii`, docs/POLICY.md", "test_policies.py, acceptance 5"),
    ("4. Retrieval with server-side user/document authorization", "app/retrieval/retriever.py, data/documents/catalog.json", "acceptance 1"),
    ("5. Prompt that treats retrieved text as untrusted data", "app/prompting.py", "test_policies.py, acceptance 2"),
    ("6. Output schema and policy validation", "app/schemas.py (LLMOutput), app/policy/output_policy.py", "acceptance 2, 3"),
    ("7. Groundedness evaluation and abstention", "app/policy/output_policy.py, app/pipeline.py", "acceptance 3"),
    ("8. Langfuse traces and scores with policy/model version metadata", "app/telemetry.py, app/pipeline.py", "acceptance 4"),
    ("9. Regression dataset and test report", "eval/regression_set.jsonl, eval/run_regression.py, this report", "acceptance 6"),
    ("10. Safe fallback and human approval for high-impact actions", "app/tools/*, app/main.py approvals routes", "test_api.py, acceptance 2"),
]


def main() -> int:
    REPORTS.mkdir(exist_ok=True)
    junit = REPORTS / "junit.xml"
    py = subprocess.run([sys.executable, "-m", "pytest", "-q", f"--junitxml={junit}"], cwd=ROOT, capture_output=True, text=True)
    reg = subprocess.run([sys.executable, "-m", "eval.run_regression"], cwd=ROOT, capture_output=True, text=True)
    gate = subprocess.run([sys.executable, "-m", "scripts.release_gate"], cwd=ROOT, capture_output=True, text=True)

    cases = []
    for tc in ET.parse(junit).getroot().iter("testcase"):
        failed = tc.find("failure") is not None or tc.find("error") is not None
        cases.append((tc.get("classname", ""), tc.get("name", ""), not failed, float(tc.get("time", 0))))
    total, passed = len(cases), sum(c[2] for c in cases)
    s = json.loads((REPORTS / "regression_results.json").read_text())["summary"]

    L = ["# Test report: AcmeHR policy assistant", "",
         f"Generated {datetime.now(timezone.utc):%Y-%m-%d %H:%M UTC} · policy **{s['policy_version']}** (`{s['policy_sha']}`) · "
         f"prompt `{s['prompt_version']}` · model `{s['chat_model']}` · embedder `{s['embedder']}`", "",
         "## Summary", "",
         "| Suite | Result |", "|---|---|",
         f"| pytest (unit + API + acceptance) | {'✅' if py.returncode == 0 else '❌'} {passed}/{total} passed |",
         f"| Regression set ({s['mode']}) | {'✅' if reg.returncode == 0 else '❌'} {s['passed']}/{s['cases']} passed, critical {s['critical_passed']}/{s['critical_cases']} |",
         f"| Release gate | {'✅ passed' if gate.returncode == 0 else '❌ blocked'} |", "",
         "## Acceptance tests", "", "| # | Acceptance criterion | Tests | Result |", "|---|---|---|---|"]
    for i, (cls, text) in enumerate(ACCEPTANCE, 1):
        mine = [c for c in cases if c[0].endswith(cls)]
        ok = all(c[2] for c in mine) and mine
        L.append(f"| {i} | {text} | {len(mine)} | {'✅ pass' if ok else '❌ fail'} |")
    L += ["", "## Requirement traceability", "", "| Requirement | Implementation | Verified by |", "|---|---|---|"]
    L += [f"| {r} | {impl} | {t} |" for r, impl, t in REQUIREMENTS]
    L += ["", "## Regression by category", "", "| Category | Passed | Rate |", "|---|---|---|"]
    L += [f"| {k} | {v['passed']}/{v['total']} | {v['rate']:.0%} |" for k, v in s["by_category"].items()]
    failed = [c for c in cases if not c[2]]
    if failed:
        L += ["", "## Failed tests", ""] + [f"- `{c[0]}::{c[1]}`" for c in failed]
    L += ["", "## All tests", "", "| Test | Result | Time (s) |", "|---|---|---|"]
    L += [f"| `{c[0].split('.')[-1]}::{c[1]}` | {'✅' if c[2] else '❌'} | {c[3]:.2f} |" for c in cases]
    L += ["", "## Release gate output", "", "```", gate.stdout.strip(), "```", "",
          "Detailed regression results: [regression_report.md](regression_report.md)", ""]
    (REPORTS / "TEST_REPORT.md").write_text("\n".join(L))
    print(f"pytest {passed}/{total} · regression {s['passed']}/{s['cases']} · gate {'PASSED' if gate.returncode == 0 else 'BLOCKED'}")
    print(f"wrote {REPORTS / 'TEST_REPORT.md'}")
    return 0 if (py.returncode == 0 and reg.returncode == 0 and gate.returncode == 0) else 1


if __name__ == "__main__":
    sys.exit(main())
