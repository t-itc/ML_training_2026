"""FastAPI service.

    uvicorn app.main:app --reload
    POST /v1/chat                          employee question or request
    GET  /v1/approvals?status=pending      HR admin: pending tool approvals and review requests
    POST /v1/approvals/{id}/decision       HR admin: approve or reject (executes approved tools)
    GET  /healthz                          versions, index size, telemetry mode
"""
from __future__ import annotations

import json
import logging
import uuid
from contextlib import asynccontextmanager
from functools import lru_cache
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.config import get_policy, get_settings
from app.pipeline import handle_chat, versions
from app.schemas import ApprovalDecision, ChatRequest, ChatResponse
from app.telemetry import telemetry
from app.tools import approvals
from app.tools.registry import execute_approved

log = logging.getLogger("hr_assistant")


@asynccontextmanager
async def lifespan(_: FastAPI):
    telemetry.startup_check()
    log.info("telemetry: %s", telemetry.status())
    yield
    telemetry.flush()


app = FastAPI(title="AcmeHR Policy Assistant", version="1.0.0", lifespan=lifespan)


# ----------------------------------------------------------------------------- request size limit
@app.middleware("http")
async def body_size_limit(request: Request, call_next):
    limit = get_policy()["request"]["max_body_bytes"]
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > limit:
        return JSONResponse({"detail": f"request body exceeds {limit} bytes"}, status_code=413)
    if request.method in ("POST", "PUT", "PATCH"):
        body = await request.body()          # also covers chunked uploads without content-length
        if len(body) > limit:
            return JSONResponse({"detail": f"request body exceeds {limit} bytes"}, status_code=413)
    response = await call_next(request)
    return response


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, exc: RequestValidationError):
    # Do not echo the rejected input back (it may contain PII); report field + type only.
    errors = [{"loc": e.get("loc"), "type": e.get("type")} for e in exc.errors()]
    return JSONResponse({"detail": errors}, status_code=422)


# ----------------------------------------------------------------------------- authentication
bearer = HTTPBearer(auto_error=False)


@lru_cache(maxsize=1)
def _users() -> dict:
    data = json.loads(Path(get_settings().users_file).read_text(encoding="utf-8"))
    return {k: v for k, v in data.items() if not k.startswith("_")}


def principal(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    """Roles come from the identity store, never from the request. Swap for OIDC/JWT validation in production."""
    if creds is None or creds.credentials not in _users():
        raise HTTPException(status_code=401, detail="invalid or missing bearer token")
    return _users()[creds.credentials]


def require_role(role: str):
    def dep(p: dict = Depends(principal)) -> dict:
        if role not in p["roles"]:
            raise HTTPException(status_code=403, detail=f"{role} role required")
        return p
    return dep


# ----------------------------------------------------------------------------- routes
@app.post("/v1/chat", response_model=ChatResponse)
def chat(req: ChatRequest, request: Request, p: dict = Depends(principal)) -> ChatResponse:
    request_id = request.headers.get("x-request-id") or f"req_{uuid.uuid4().hex[:16]}"
    if not request_id.replace("_", "").replace("-", "").isalnum() or len(request_id) > 64:
        request_id = f"req_{uuid.uuid4().hex[:16]}"
    return handle_chat(req.message, p, session_id=req.session_id, request_id=request_id)


@app.get("/v1/approvals")
def list_approvals(status: str | None = "pending", p: dict = Depends(require_role("hr_admin"))) -> list[dict]:
    return approvals.list_items(status)


@app.post("/v1/approvals/{approval_id}/decision")
def decide(approval_id: str, body: ApprovalDecision, p: dict = Depends(require_role("hr_admin"))) -> dict:
    try:
        item = approvals.decide(approval_id, p, body.decision, body.comment, execute_approved)
    except approvals.ApprovalError as e:
        raise HTTPException(status_code=e.status_code, detail=str(e))
    telemetry.client.create_score(name="human_decision", value=body.decision, data_type="CATEGORICAL",
                                  trace_id=item.get("trace_id"), comment=f"{approval_id} by {p['user_id']}") if item.get("trace_id") else None
    return item


@app.get("/healthz")
def health() -> dict:
    from app.retrieval.store import get_collection
    try:
        chunks = get_collection().count()
    except Exception:
        chunks = 0
    return {"status": "ok" if chunks else "degraded: run `python -m scripts.ingest`", "index_chunks": chunks,
            "telemetry": telemetry.status(), **versions()}
