"""STEP 6 · Long-term memory: a Store shared by all threads

    thread "s1" ──save_memory──►  Store[("mahesh","memories")]  ◄──search_memory── thread "s2"

Run:  python -m steps.step6_long_term_memory
NEW in this step: InMemoryStore, namespaces, ToolRuntime (runtime.store / runtime.context), context_schema.
"""
from dataclasses import dataclass

from langchain.agents import create_agent
from langchain.tools import ToolRuntime, tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.store.memory import InMemoryStore

from agents.prompts import MEMORY_PROMPT
from config import get_llm


@dataclass
class Ctx:
    user_id: str                                            # set by the APP on every call, never by the LLM


@tool
def save_memory(content: str, category: str, runtime: ToolRuntime[Ctx], key: str | None = None) -> str:
    """Save a durable fact about the user (name, role, skills, preferences)."""
    ns = (runtime.context.user_id, "memories")              # one namespace per user
    runtime.store.put(ns, key or content[:30], {"content": content, "category": category})
    return f"Saved: {content}"


@tool
def search_memory(query: str, runtime: ToolRuntime[Ctx]) -> str:
    """Return what is stored about the current user."""
    items = runtime.store.search((runtime.context.user_id, "memories"))
    return "\n".join(f"- {i.value['content']}" for i in items) or "(nothing stored)"


store = InMemoryStore()                                     # use SqliteStore to survive restarts
agent = create_agent(get_llm(), tools=[save_memory, search_memory], system_prompt=MEMORY_PROMPT,
                     checkpointer=InMemorySaver(), store=store, context_schema=Ctx)


def chat(text: str, thread: str, user: str = "mahesh") -> str:
    out = agent.invoke({"messages": [{"role": "user", "content": text}]},
                       {"configurable": {"thread_id": thread}}, context=Ctx(user_id=user))
    return out["messages"][-1].content


print("[s1]", chat("I am a Data Scientist.", "s1"))
print("[s1]", chat("I primarily work with Python and LangChain.", "s1"))
print("[s2]", chat("Suggest a project for me.", "s2"))                  # NEW thread, still personalised
print("[s3 priya]", chat("Suggest a project for me.", "s3", user="priya"))  # other user: no access
print("\nStore:", [(i.key, i.value["content"]) for i in store.search(("mahesh", "memories"))])
