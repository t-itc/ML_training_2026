"""Module 3.5 — an intentional tool failure, with and without the error-handling middleware.

    python -m scripts.m3_tool_failure

The weather API is "down": the tool RAISES ConnectionError (an unexpected failure, not an "Error: ..." string).
  1. without middleware -> LangChain 1.x re-raises the exception and the whole agent run fails
  2. with handle_tool_errors (@wrap_tool_call) -> the error becomes a ToolMessage(status="error"),
     the model reads it and answers gracefully
"""
from langchain.agents import create_agent
from langchain.tools import tool

from agents.assistant_agent import handle_tool_errors
from agents.prompts import TOOLS_PROMPT
from config import get_llm
from scripts._common import banner, show


@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    raise ConnectionError(f"weather API timed out for {city!r}")


QUESTION = "What's the weather in Pune?"


def main() -> None:
    banner("Module 3.5 · Intentional tool failure")

    print("\n1) WITHOUT error-handling middleware")
    agent = create_agent(get_llm(), tools=[get_weather], system_prompt=TOOLS_PROMPT)
    try:
        agent.invoke({"messages": [{"role": "user", "content": QUESTION}]})
        print("   (no exception — your model did not call the tool)")
    except Exception as exc:  # noqa: BLE001
        print(f"   💥 run FAILED: {type(exc).__name__}: {exc}")

    print("\n2) WITH middleware=[handle_tool_errors]")
    agent = create_agent(get_llm(), tools=[get_weather], system_prompt=TOOLS_PROMPT, middleware=[handle_tool_errors])
    result = agent.invoke({"messages": [{"role": "user", "content": QUESTION}]})
    for m in result["messages"]:
        if m.type == "tool":
            print(f"   ToolMessage status={m.status}: {m.content[:90]}")
    show(QUESTION, result["messages"][-1].content)


if __name__ == "__main__":
    main()
