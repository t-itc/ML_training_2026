"""Chat with Aria — the complete Intelligent Personal AI Assistant (persistent memory).

    python main.py                         # agentic stage, user 'mahesh', thread 'default'
    python main.py --stage tools --trace   # any stage: basic | tools | short_term | long_term | agentic
    python main.py --user priya

Commands:  /new  /thread <id>  /user <id>  /memories  /episodes  /history  /trace  /forget-all  /help  /quit
"""
from __future__ import annotations

import argparse
import uuid

from agents.assistant_agent import STAGES, ask, build_agent, tools_called
from agents.observability import get_callbacks
from config import describe_llm, get_settings
from memory.long_term import clear_user, format_memories, get_store, list_memories, recent_episodes
from memory.short_term import get_checkpointer, scoped_thread_id, show_thread


def main() -> None:
    ap = argparse.ArgumentParser(description="Chat with Aria")
    ap.add_argument("--stage", choices=STAGES, default="agentic")
    ap.add_argument("--user", default=get_settings().default_user_id)
    ap.add_argument("--thread", default="default")
    ap.add_argument("--trace", action="store_true", help="print LLM/tool events")
    args = ap.parse_args()

    store = get_store("sqlite")
    checkpointer = get_checkpointer("sqlite")
    agent = build_agent(args.stage, checkpointer=checkpointer, store=store) if args.stage != "basic" \
        else build_agent("basic", checkpointer=checkpointer)
    user, thread, trace = args.user, args.thread, args.trace
    uses_ctx = args.stage in ("long_term", "agentic")

    print(f"Aria · stage={args.stage} · {describe_llm()}")
    print(f"user={user} thread={thread}   (type /help for commands)\n")
    while True:
        try:
            text = input(f"{user}@{thread} > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not text:
            continue
        cmd, _, arg = text.partition(" ")
        if cmd in ("/quit", "/exit"):
            break
        if cmd == "/help":
            print(__doc__)
        elif cmd == "/new":
            thread = f"t-{uuid.uuid4().hex[:6]}"
            print(f"   new thread: {thread} (short-term memory is empty, long-term memory is kept)")
        elif cmd == "/thread" and arg:
            thread = arg
        elif cmd == "/user" and arg:
            # identity change = new conversation; thread ids are also scoped per user (see below)
            user, thread = arg, "default"
            print(f"   switched to user {user!r} on thread 'default' — {user}'s own history and memories")
        elif cmd == "/memories":
            print(format_memories(list_memories(store, user)))
        elif cmd == "/episodes":
            for e in recent_episodes(store, user, n=10):
                print(f"   {e.key[:15]} {e.value['question'][:60]!r} tools={e.value['tools']}")
        elif cmd == "/history":
            print("\n".join(show_thread(agent, scoped_thread_id(user, thread))) or "   (empty thread)")
        elif cmd == "/trace":
            trace = not trace
            print(f"   trace {'on' if trace else 'off'}")
        elif cmd == "/forget-all":
            print(f"   deleted {clear_user(store, user)} items for {user}")
        elif cmd.startswith("/"):
            print("   unknown command — /help")
        else:
            answer, result = ask(agent, text, thread_id=scoped_thread_id(user, thread), user_id=user if uses_ctx else None,
                                 callbacks=get_callbacks(echo=True) if trace else None)
            used = tools_called(result)
            if used:
                print(f"   (tools: {', '.join(used)})")
            print(f"Aria > {answer}\n")


if __name__ == "__main__":
    main()
