"""Test environment: deterministic, offline, isolated.

* mock worst-case LLM + hashing embedder (no Ollama, no model download)
* temporary Chroma index, approval DB and telemetry fallback log per test session
* Langfuse disabled unless a test enables it with an in-memory span exporter
"""
import json
import os
import tempfile
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="hr_tests_"))
os.environ.update({
    "LLM_PROVIDER": "mock", "EMBEDDER": "hashing", "USE_LLM_JUDGE": "false",
    "CHROMA_DIR": str(_TMP / "chroma"), "APPROVALS_DB": str(_TMP / "approvals.sqlite3"),
    "TELEMETRY_FALLBACK_LOG": str(_TMP / "telemetry_fallback.jsonl"), "APP_ENV": "test",
})
for k in ("LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY", "LANGFUSE_BASE_URL", "LANGFUSE_HOST"):
    os.environ.pop(k, None)

ROOT = Path(__file__).resolve().parents[1]
USERS = {v["name"].split()[0].lower(): v for k, v in json.loads((ROOT / "data/users.json").read_text()).items()
         if not k.startswith("_")}
TOKENS = {"ravi": "tok-emp-ravi", "priya": "tok-mgr-priya", "anita": "tok-hr-anita"}


@pytest.fixture(scope="session", autouse=True)
def index():
    from app.retrieval.store import ingest
    return ingest(reset=True)


@pytest.fixture
def users():
    return USERS


@pytest.fixture
def client():
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        yield c


@pytest.fixture
def auth():
    return lambda who: {"Authorization": f"Bearer {TOKENS[who]}"}


@pytest.fixture
def fallback_log():
    p = Path(os.environ["TELEMETRY_FALLBACK_LOG"])
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("")
    return p


@pytest.fixture
def capture_prompts(monkeypatch):
    """Record every (system, user) prompt that reaches the LLM."""
    from app import llm
    seen: list[str] = []
    real = llm.MockLLM.complete

    def spy(self, system, user, *, name, model):
        seen.append(system + "\n" + user)
        return real(self, system, user, name=name, model=model)

    monkeypatch.setattr(llm.MockLLM, "complete", spy)
    return seen


@pytest.fixture
def langfuse_memory(monkeypatch):
    """Enable Langfuse with an in-memory exporter; record scores instead of sending them."""
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
    from app.telemetry import telemetry

    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-test")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-test")
    monkeypatch.setenv("LANGFUSE_BASE_URL", "http://127.0.0.1:9")
    exporter = InMemorySpanExporter()
    telemetry.configure(span_exporter=exporter)
    scores: list[dict] = []
    monkeypatch.setattr(telemetry.client, "score_current_trace",
                        lambda **kw: scores.append(kw | {"trace_id": telemetry.client.get_current_trace_id()}))
    monkeypatch.setattr(telemetry.client, "create_score", lambda **kw: scores.append(kw))
    yield {"exporter": exporter, "scores": scores, "telemetry": telemetry}
    monkeypatch.delenv("LANGFUSE_PUBLIC_KEY")
    monkeypatch.delenv("LANGFUSE_SECRET_KEY")
    telemetry.configure()
