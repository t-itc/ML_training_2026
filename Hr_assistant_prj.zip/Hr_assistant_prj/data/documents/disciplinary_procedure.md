# Disciplinary Procedure (Managers and HR only)

## Verbal and written warnings
A first verbal warning is recorded in PeopleHub by the manager. A written warning requires a meeting with HR present and stays on file for 12 months.

## Final warning
A final written warning is issued only after HR review and remains on file for 24 months.
