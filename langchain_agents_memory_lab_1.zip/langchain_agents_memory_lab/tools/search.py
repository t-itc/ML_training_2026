"""Search tool — keyword search over a small local knowledge base (Acme policies + AI notes).

Swap the body for Tavily / a RAG retriever later; the tool contract stays the same.
"""
from __future__ import annotations

import json
import re

from langchain.tools import tool

from config import PROJECT_ROOT

KB = json.loads((PROJECT_ROOT / "data" / "knowledge_base.json").read_text(encoding="utf-8"))
_STOP = {"the", "a", "an", "is", "what", "how", "many", "can", "i", "do", "of", "to", "in", "for", "and", "my", "me", "about", "on"}


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in _STOP and len(t) > 1}


def search_kb(query: str, k: int = 2) -> list[dict]:
    q = _tokens(query)
    scored = []
    for doc in KB:
        score = 2 * len(q & set(doc["tags"])) + len(q & _tokens(doc["title"] + " " + doc["text"]))
        if score:
            scored.append((score, doc))
    return [d for _, d in sorted(scored, key=lambda x: -x[0])[:k]]


@tool(parse_docstring=True)
def search_knowledge(query: str) -> str:
    """Search the company knowledge base (HR policies, IT policies, AI notes).

    Use for questions about leave, work from home, learning budget, passwords, laptops,
    RAG, agents or LangGraph. Returns the most relevant passages with their ids.

    Args:
        query: A short search query, e.g. "leave carry forward".
    """
    hits = search_kb(query)
    if not hits:
        return f"No results for {query!r}."
    return "\n".join(f"[{d['id']}] {d['title']}: {d['text']}" for d in hits)
