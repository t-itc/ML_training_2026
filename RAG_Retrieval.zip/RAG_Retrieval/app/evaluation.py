"""Retrieval evaluation metrics with binary relevance (a document is relevant or not)."""
from __future__ import annotations

import math
from typing import Callable


def precision_at_k(retrieved: list[str], relevant: set[str], k: int) -> float:
    """Share of the top-k results that are relevant."""
    top = retrieved[:k]
    return sum(1 for d in top if d in relevant) / k


def recall_at_k(retrieved: list[str], relevant: set[str], k: int) -> float:
    """Share of all relevant documents that appear in the top-k."""
    if not relevant:
        return 0.0
    return sum(1 for d in retrieved[:k] if d in relevant) / len(relevant)


def reciprocal_rank(retrieved: list[str], relevant: set[str]) -> float:
    """1 / position of the FIRST relevant result (0 if none). Averaged -> MRR."""
    for pos, d in enumerate(retrieved, start=1):
        if d in relevant:
            return 1.0 / pos
    return 0.0


def ndcg_at_k(retrieved: list[str], relevant: set[str], k: int) -> float:
    """Normalised Discounted Cumulative Gain: rewards relevant results more
    the higher they are ranked. 1.0 = all relevant docs at the very top."""
    dcg = sum(1.0 / math.log2(pos + 1) for pos, d in enumerate(retrieved[:k], start=1) if d in relevant)
    ideal_hits = min(len(relevant), k)
    idcg = sum(1.0 / math.log2(pos + 1) for pos in range(1, ideal_hits + 1))
    return dcg / idcg if idcg else 0.0


def evaluate(search: Callable[[str, int], list[str]], questions: list[dict], k: int = 3) -> dict:
    """search(question, k) must return a ranked list of document IDs."""
    rows = []
    for q in questions:
        retrieved = search(q["question"], k)
        relevant = set(q["relevant_ids"])
        rows.append({
            "id": q["id"], "question": q["question"], "relevant": sorted(relevant), "retrieved": retrieved,
            "precision": precision_at_k(retrieved, relevant, k),
            "recall": recall_at_k(retrieved, relevant, k),
            "rr": reciprocal_rank(retrieved, relevant),
            "ndcg": ndcg_at_k(retrieved, relevant, k),
        })
    n = len(rows) or 1
    summary = {m: sum(r[m] for r in rows) / n for m in ("precision", "recall", "rr", "ndcg")}
    return {"k": k, "rows": rows, "summary": summary}


def format_summary(name: str, result: dict) -> str:
    s, k = result["summary"], result["k"]
    return (f"{name:<18} P@{k}={s['precision']:.3f}  R@{k}={s['recall']:.3f}  "
            f"MRR={s['rr']:.3f}  nDCG@{k}={s['ndcg']:.3f}")
