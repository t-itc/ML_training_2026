"""Long-term memory — a LangGraph Store keyed by (user_id, "memories").

A Store is a JSON document database with *namespaces* (like folders) and *keys*:

    namespace = ("mahesh", "memories")   key = "role"   value = {"content": "User is a Data Scientist", ...}

It lives outside any conversation thread, so a new thread_id (a new session) can still read it.
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from langgraph.store.base import BaseStore, Item
from langgraph.store.memory import InMemoryStore

from config import get_settings


@dataclass
class UserContext:
    """Runtime context passed on every invoke: agent.invoke(..., context=UserContext("mahesh"))."""
    user_id: str = "mahesh"


# ---------------------------------------------------------------- namespaces
def memory_ns(user_id: str) -> tuple[str, str]:
    return (user_id, "memories")


def episode_ns(user_id: str) -> tuple[str, str]:
    return (user_id, "episodes")


def user_id_from(runtime) -> str:
    ctx = getattr(runtime, "context", None)
    return getattr(ctx, "user_id", None) or get_settings().default_user_id


# ---------------------------------------------------------------- store factory
def get_store(kind: str = "sqlite", path: str | Path | None = None, semantic: bool = False,
              embed: str = "ollama") -> BaseStore:
    """kind='memory' -> InMemoryStore (lost on exit); kind='sqlite' -> survives restarts.

    semantic=True adds a vector index so store.search(query=...) ranks by meaning (cosine similarity).
    embed='ollama' -> nomic-embed-text (real model); embed='toy' -> offline teaching embeddings.
    """
    index = None
    if semantic:
        from memory.embeddings import get_embeddings

        embeddings, dims = get_embeddings(embed)
        index = {"dims": dims, "embed": embeddings, "fields": ["content"]}

    if kind == "memory":
        return InMemoryStore(index=index) if index else InMemoryStore()

    from langgraph.store.sqlite import SqliteStore

    path = Path(path or get_settings().memory_db)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
    store = SqliteStore(conn, index=index) if index else SqliteStore(conn)
    store.setup()  # creates tables on first run, no-op afterwards
    return store


# ---------------------------------------------------------------- CRUD helpers
def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def put_memory(store: BaseStore, user_id: str, key: str, content: str, category: str,
               source: str = "agent") -> tuple[str, str | None]:
    """Create or update one memory. Returns (status, previous_content)."""
    ns = memory_ns(user_id)
    old = store.get(ns, key)
    if old and old.value.get("content", "").strip().lower() == content.strip().lower():
        return "unchanged", old.value["content"]
    value = {
        "content": content.strip(),
        "category": category,
        "source": source,
        "created_at": old.value.get("created_at", _now()) if old else _now(),
        "updated_at": _now(),
        "version": (old.value.get("version", 1) + 1) if old else 1,
    }
    store.put(ns, key, value)
    return ("updated" if old else "created"), (old.value["content"] if old else None)


def list_memories(store: BaseStore, user_id: str, category: str | None = None, limit: int = 100) -> list[Item]:
    items = store.search(memory_ns(user_id), limit=limit)
    if category:
        items = [i for i in items if i.value.get("category") == category]
    return sorted(items, key=lambda i: i.value.get("updated_at", ""), reverse=True)


def delete_memory(store: BaseStore, user_id: str, key: str) -> bool:
    if store.get(memory_ns(user_id), key) is None:
        return False
    store.delete(memory_ns(user_id), key)
    return True


_STOP = {"the", "a", "an", "is", "are", "what", "how", "me", "my", "i", "you", "for", "to", "of", "and", "in",
         "on", "do", "can", "please", "about", "with", "user", "this", "that", "it", "be"}
# tiny synonym map so keyword retrieval feels "semantic enough" for a demo
_EXPAND = {
    "explain": {"explanation", "example", "examples", "style"}, "project": {"skill", "works", "role", "goal"},
    "suggest": {"skill", "works", "role", "goal"}, "recommend": {"skill", "works", "role", "goal"},
    "code": {"python", "example", "examples"}, "rag": {"explanation", "example"},
    "name": {"name"}, "who": {"name", "role"}, "answer": {"answer_length", "concise", "short", "length"},
}


def _tokens(text: str) -> set[str]:
    words = {w for w in re.findall(r"[a-z0-9_]+", text.lower()) if w not in _STOP and len(w) > 1}
    for w in list(words):
        words |= _EXPAND.get(w, set())
    return words


def search_memories(store: BaseStore, user_id: str, query: str, k: int = 5, min_score: float = 0.0) -> list[Item]:
    """Relevant memories for `query`.

    * Store has a vector index  -> semantic search (store.search(query=...)); hits with similarity <= min_score
                                   are dropped (with real embeddings a threshold such as 0.5 avoids injecting noise).
    * Otherwise                -> transparent keyword overlap + always include the user's name/role.
    """
    ns = memory_ns(user_id)
    if getattr(store, "index_config", None):
        hits = store.search(ns, query=query, limit=k)          # ranked by cosine similarity
        return [h for h in hits if h.score is None or h.score > min_score]

    q = _tokens(query)
    scored = []
    for item in store.search(ns, limit=200):
        text = f"{item.key} {item.value.get('category', '')} {item.value.get('content', '')}"
        score = len(q & _tokens(text))
        if item.key in {"name", "role"}:  # identity is always useful context
            score += 0.5
        if score > 0:
            scored.append((score, item.value.get("updated_at", ""), item))
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [i for _, _, i in scored[:k]]


def format_memories(items: list[Item]) -> str:
    if not items:
        return "(no memories yet)"
    return "\n".join(f"- [{i.value.get('category', '?')}/{i.key}] {i.value.get('content')}" for i in items)


# ---------------------------------------------------------------- episodes (agent experience)
def add_episode(store: BaseStore, user_id: str, episode: dict) -> str:
    key = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
    store.put(episode_ns(user_id), key, {**episode, "created_at": _now()})
    return key


def recent_episodes(store: BaseStore, user_id: str, n: int = 3) -> list[Item]:
    items = store.search(episode_ns(user_id), limit=200)
    return sorted(items, key=lambda i: i.key, reverse=True)[:n]


def clear_user(store: BaseStore, user_id: str) -> int:
    """Delete all memories and episodes of a user (used by demos to start clean)."""
    n = 0
    for ns in (memory_ns(user_id), episode_ns(user_id)):
        for item in store.search(ns, limit=1000):
            store.delete(ns, item.key)
            n += 1
    return n
