"""HR tools with impact levels and a deterministic intent router.

Security model
  * Tool selection depends ONLY on the authenticated principal and deterministic rules over the USER
    message. Model output and retrieved documents can never select, trigger or parameterise a tool.
  * If the model proposes a tool call anyway (e.g. after reading an injected document), the proposal is
    rejected and recorded (score tool_call_rejected = 1).
  * low impact  -> executed immediately, read-only, own data only.
  * high impact -> an approval request for an HR admin; nothing is executed by the assistant.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from app.config import get_policy, get_settings

QUESTION_START = re.compile(r"^\s*(how|what|where|when|why|who|which|is|are|does|do|can i|could i|should i)\b", re.I)

INTENTS: list[tuple[str, re.Pattern, bool]] = [
    # (tool, pattern, allowed for question-style messages)
    ("get_leave_balance", re.compile(r"\b(my|remaining|current)\b.{0,20}\bleave balance\b|\bleave days do i have\b"
                                     r"|\bhow many (annual |sick )?leave days (do i have|have i got|are left)\b", re.I), True),
    ("submit_leave_request", re.compile(r"\b(apply|submit|request|book)\b.{0,30}\bleave\b", re.I), False),
    ("update_bank_details", re.compile(r"\b(update|change|modify)\b.{0,20}\bbank (details|account)\b", re.I), False),
    ("escalate_to_hr", re.compile(r"\b(escalate|raise (a |an )?(complaint|ticket|grievance))\b", re.I), False),
]
DATE = re.compile(r"\b(20\d\d-\d\d-\d\d)\b")


def detect_intent(user_text: str) -> str | None:
    """Per sentence: an action tool fires only for a request ("please update my bank details"),
    not for an informational question ("how do I change my bank account?")."""
    for sentence in re.split(r"(?<=[.!?])\s+", user_text.strip()):
        is_question = bool(QUESTION_START.match(sentence))
        for tool, pattern, question_ok in INTENTS:
            if pattern.search(sentence) and (question_ok or not is_question):
                return tool
    return None


@dataclass
class ToolPlan:
    tool: str
    impact: str
    arguments: dict
    needs_input: str | None = None        # message asking the user for missing details


def plan(tool: str, user_text: str, principal: dict) -> ToolPlan:
    cfg = get_policy()["tools"][tool]
    args: dict = {"employee_id": principal["user_id"]}          # always the caller, never from text
    needs = None
    if tool == "submit_leave_request":
        dates = DATE.findall(user_text)
        if len(dates) < 2:
            needs = "Please include the start and end dates as YYYY-MM-DD, e.g. 'apply for leave from 2026-12-01 to 2026-12-05'."
        else:
            start, end = sorted(dates[:2])
            if date.fromisoformat(end) < date.fromisoformat(start):
                needs = "The end date must be after the start date."
            args.update(start=start, end=end)
    elif tool == "update_bank_details":
        args["note"] = "Verify via the secure PeopleHub form. Account numbers are never collected in chat."
    elif tool == "escalate_to_hr":
        args["summary"] = user_text[:200]
    return ToolPlan(tool, cfg["impact"], args, needs)


def run_low_impact(p: ToolPlan) -> str:
    if p.tool == "get_leave_balance":
        balances = json.loads(Path(get_settings().leave_balances_file).read_text())
        b = balances.get(p.arguments["employee_id"])
        if not b:
            return "I could not find a leave balance for your account. Please contact hr@acme.example."
        return f"You have {b['annual']} annual leave days and {b['sick']} sick leave days remaining."
    raise ValueError(f"{p.tool} is not a low-impact tool")


def execute_approved(item: dict) -> dict:
    """Called only by the approval endpoint after an HR admin approves. Simulated side effect."""
    log = Path(get_settings().approvals_db).with_name("executed_actions.jsonl")
    # The employee is always the requester recorded by the server, never a value from stored arguments.
    entry = {"approval_id": item["id"], "tool": item["tool"], "employee_id": item["requester_id"],
             "arguments": item["arguments"], "approved_by": item.get("decided_by")}
    with log.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    return {"executed": True, "tool": item["tool"]}
