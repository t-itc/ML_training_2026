"""Short-term memory — a LangGraph *checkpointer* saves the agent state after every step.

State is stored per thread_id:  config = {"configurable": {"thread_id": "session-1"}}
Same thread_id  -> the agent sees the earlier messages.
New thread_id   -> a fresh conversation (empty history).
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

from langgraph.checkpoint.memory import InMemorySaver

from config import get_settings


def get_checkpointer(kind: str = "memory", path: str | Path | None = None):
    """kind='memory' -> InMemorySaver (lost when Python exits); kind='sqlite' -> survives restarts."""
    if kind == "memory":
        return InMemorySaver()
    from langgraph.checkpoint.sqlite import SqliteSaver

    path = Path(path or get_settings().checkpoint_db)
    path.parent.mkdir(parents=True, exist_ok=True)
    saver = SqliteSaver(sqlite3.connect(str(path), check_same_thread=False))
    saver.setup()
    return saver


def scoped_thread_id(user_id: str, thread: str) -> str:
    """Bind a conversation thread to ONE user: "mahesh:default" and "priya:default" never share history.

    In production the user id comes from authentication, never from the request body or the LLM.
    """
    return f"{user_id}:{thread}"


def thread_config(thread_id: str) -> dict:
    return {"configurable": {"thread_id": thread_id}}


def show_thread(agent, thread_id: str, last: int | None = None) -> list[str]:
    """Return the conversation stored for a thread (what the checkpointer remembers)."""
    snapshot = agent.get_state(thread_config(thread_id))
    msgs = snapshot.values.get("messages", []) if snapshot and snapshot.values else []
    lines = []
    for m in msgs[-last:] if last else msgs:
        label = {"human": "User", "ai": "AI", "tool": f"Tool:{getattr(m, 'name', '')}"}.get(m.type, m.type)
        text = m.content if m.content else f"<calls {', '.join(tc['name'] for tc in m.tool_calls)}>"
        lines.append(f"{label:>22}: {str(text)[:110]}")
    return lines
