"""Memory tools — the agent itself decides when to read and write long-term memory.

`runtime: ToolRuntime` is injected by LangChain and is HIDDEN from the LLM:
the model only sees `content`, `category`, `key`. Through runtime we reach the Store
(runtime.store) and the current user (runtime.context.user_id).
"""
from __future__ import annotations

from typing import Literal

from langchain.tools import ToolRuntime, tool

from memory.agentic_memory import evaluate, make_key
from memory.long_term import (
    UserContext, delete_memory as _delete, format_memories, list_memories, put_memory, search_memories, user_id_from,
)


@tool(parse_docstring=True)
def save_memory(
    content: str,
    category: Literal["profile", "preference", "skill", "goal", "feedback"],
    runtime: ToolRuntime[UserContext],
    key: str | None = None,
) -> str:
    """Save or update a durable fact about the user in long-term memory.

    Use when the user shares their name, role, skills, preferences, goals or feedback.
    Reuse the same key to UPDATE an existing memory (e.g. key="role").

    Args:
        content: One third-person sentence, e.g. "User is a Data Scientist".
        category: profile | preference | skill | goal | feedback.
        key: Optional stable key such as name, role, tech_stack, explanation_style, answer_length.
    """
    if runtime.store is None:
        return "Error: no long-term store configured."
    decision = evaluate(content, category)
    if not decision.allowed:
        return f"Not saved: {decision.reason}."
    k = make_key(decision.category, content, key)
    status, old = put_memory(runtime.store, user_id_from(runtime), k, content, decision.category)
    if status == "updated":
        return f"Updated memory [{decision.category}/{k}]: {content} (was: {old})"
    if status == "unchanged":
        return f"Already known [{decision.category}/{k}]: {content}"
    return f"Saved memory [{decision.category}/{k}]: {content}"


@tool(parse_docstring=True)
def search_memory(query: str, runtime: ToolRuntime[UserContext]) -> str:
    """Search long-term memory for facts about the current user relevant to the query.

    Use before personalising an answer (suggestions, recommendations, 'what do you know about me').

    Args:
        query: What you are looking for, e.g. "skills and role" or "explanation preferences".
    """
    if runtime.store is None:
        return "Error: no long-term store configured."
    return format_memories(search_memories(runtime.store, user_id_from(runtime), query))


@tool(parse_docstring=True)
def get_user_profile(runtime: ToolRuntime[UserContext]) -> str:
    """Return everything stored about the current user (profile, skills, preferences, goals, feedback)."""
    if runtime.store is None:
        return "Error: no long-term store configured."
    return format_memories(list_memories(runtime.store, user_id_from(runtime)))


@tool(parse_docstring=True)
def delete_memory(key: str, runtime: ToolRuntime[UserContext]) -> str:
    """Delete a stored memory by key when the user asks you to forget something.

    Args:
        key: The memory key, e.g. "location".
    """
    if runtime.store is None:
        return "Error: no long-term store configured."
    return f"Deleted memory '{key}'." if _delete(runtime.store, user_id_from(runtime), key) else f"No memory with key '{key}'."
