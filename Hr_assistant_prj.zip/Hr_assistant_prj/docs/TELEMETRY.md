# Telemetry: traces, scores and the failure path

## Normal path (Langfuse)

One trace per request, `hr-assistant.chat`, with:

| Observation | Type | Content |
|---|---|---|
| `guardrail.input_policy` | guardrail | decision, reason, signals (injection score, PII types, topic), WARNING when not allowed |
| `retrieval.authorized` | retriever | roles, chunk ids + similarities, below-threshold and ACL-violation counts (ERROR if violations) |
| `llm.answer` | generation | model, masked prompt, output, token usage |
| `guardrail.output_policy` | guardrail | schema/policy result and violations |
| `evaluator.groundedness` | evaluator | score, method, unsupported claims |
| `judge.groundedness` | generation | judge call (Ollama mode) |

**Trace attributes:** `user_id` (employee ID), `session_id`, tags `hr-assistant`, `policy:<version>`, provider;
`version` = app version; metadata `policy_version`, `policy_sha`, `prompt_version`, `chat_model`, `judge_model`,
`embedder`, `app_version`, `request_id`.

**Trace scores:** `status` (categorical), `input_decision` (categorical), `blocked`, `abstained`, `pii_redacted`,
`human_review`, `approval_required`, `tool_call_rejected`, `output_policy_violation`, `error` (boolean),
`injection_score`, `groundedness`, `acl_violations`, `context_injection_chunks` (numeric).
Approver decisions are added later as `human_decision` on the original trace.

Useful views: filter `tool_call_rejected = 1` (attacks that reached the model), `acl_violations > 0` (index
integrity - page someone), `abstained = 1` grouped by `policy_version` (coverage gaps), `groundedness` histogram.

## Failure path (explicit and tested)

Telemetry never blocks a user request. Every response carries `telemetry.mode`:

* `langfuse` + `trace_id` - the trace exists.
* `fallback` + `fallback_reason` - a **masked audit record** with the same `request_id` was appended to
  `logs/telemetry_fallback.jsonl` (`TELEMETRY_FALLBACK_LOG`).

| `fallback_reason` | When |
|---|---|
| `langfuse_not_configured` | `LANGFUSE_PUBLIC_KEY`/`SECRET_KEY` not set |
| `auth_check_failed` | keys rejected or server unreachable at startup (`/healthz` shows it) |
| `export_errors` | the Langfuse SDK or OTLP exporter logged an error since startup (degraded; restart after fixing) |
| `no_trace_id` | tracing produced no trace id for the request |

Fallback record fields: `ts, request_id, trace_id, user_id, fallback_reason, status, reason_code, policy_version,
prompt_version, scores, docs_in_prompt`. No message text, answers or names. Ship this file to your log platform and
alert when its rate rises.

Tests: `tests/test_acceptance.py::TestEveryRequestHasATraceOrDocumentedFallback`.
