# IT Security Policy

## Phishing
Report suspected phishing emails to security@acme.example within 1 hour. Do not click links or open attachments in suspicious emails.

## Passwords
Passwords must be at least 14 characters. Never share your password with anyone, including IT staff. Multi-factor authentication is mandatory.

## IT Helpdesk
The IT Helpdesk is open Monday to Friday, 8:00 AM to 8:00 PM IST, and Saturday, 9:00 AM to 1:00 PM IST.
