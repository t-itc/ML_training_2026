"""Embedders: MiniLM (real) and a deterministic hashing embedder (tests / CI / offline)."""
from __future__ import annotations

import hashlib
import math
import re
from typing import Protocol

from app.config import get_settings

_TOKEN = re.compile(r"[a-z0-9]+")
STOP = set("a an the of to in on for and or is are was be by with at as it this that from your you i my me we our "
           "do does did can could should would will what which who whom how when where why much many any".split())


def tokens(text: str) -> list[str]:
    return [t for t in _TOKEN.findall(text.lower()) if t not in STOP]


class Embedder(Protocol):
    name: str

    def embed_documents(self, texts: list[str]) -> list[list[float]]: ...
    def embed_query(self, text: str) -> list[float]: ...


class HashingEmbedder:
    """Feature hashing of unigrams + bigrams (+ light stemming). Deterministic, no download."""

    def __init__(self, dim: int = 384):
        self.dim = dim
        self.name = f"hashing-{dim}"

    @staticmethod
    def _stem(t: str) -> str:
        if len(t) > 4 and t.endswith("ies"):
            return t[:-3] + "y"
        for suf in ("ing", "ed"):
            if len(t) > 5 and t.endswith(suf):
                return t[: -len(suf)]
        if len(t) > 3 and t.endswith("s") and not t.endswith("ss"):
            return t[:-1]
        return t

    def _vec(self, text: str) -> list[float]:
        toks = [self._stem(t) for t in tokens(text)]
        feats = toks + [f"{a}_{b}" for a, b in zip(toks, toks[1:])][: len(toks) // 2]
        v = [0.0] * self.dim
        for f in feats:
            h = int(hashlib.md5(f.encode()).hexdigest(), 16)
            v[h % self.dim] += -1.0 if (h >> 8) & 1 else 1.0
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        return [x / n for x in v]

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [self._vec(t) for t in texts]

    def embed_query(self, text: str) -> list[float]:
        return self._vec(text)


class MiniLMEmbedder:
    """sentence-transformers/all-MiniLM-L6-v2, normalised 384-d vectors (same as the RAG module)."""

    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer  # lazy: heavy import

        self.name = model_name
        self._model = SentenceTransformer(model_name)

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._model.encode(texts, batch_size=32, normalize_embeddings=True).tolist()

    def embed_query(self, text: str) -> list[float]:
        return self._model.encode([text], normalize_embeddings=True)[0].tolist()


_EMB: Embedder | None = None


def get_embedder() -> Embedder:
    global _EMB
    s = get_settings()
    if _EMB is None or (s.embedder == "hashing") != isinstance(_EMB, HashingEmbedder):
        _EMB = HashingEmbedder() if s.embedder == "hashing" else MiniLMEmbedder(s.embedding_model)
    return _EMB
