"""Dense (vector) retrieval, metadata filtering and parent-child retrieval."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class Result:
    doc: dict
    score: float
    method: str

    @property
    def id(self) -> str:
        return self.doc["id"]


def matches_filters(doc: dict, filters: dict | None) -> bool:
    """filters = {"department": "HR"} or {"department": ["HR", "IT"], "doc_type": "policy"}."""
    if not filters:
        return True
    for key, allowed in filters.items():
        allowed = allowed if isinstance(allowed, (list, tuple, set)) else [allowed]
        if doc.get(key) not in allowed:
            return False
    return True


class DenseRetriever:
    """Embeds every document once (indexing), then answers queries with
    cosine similarity. ``model`` needs encode_documents() and encode_queries()
    returning L2-normalised vectors (see embeddings.EmbeddingModel)."""

    def __init__(self, docs: list[dict], model, text_key: str = "text"):
        if not docs:
            raise ValueError("No documents to index")
        self.docs, self.model = docs, model
        self.embeddings = model.encode_documents([d[text_key] for d in docs])   # (n_docs, dim)

    def search(self, query: str, top_k: int = 5, filters: dict | None = None) -> list[Result]:
        if not query.strip():
            raise ValueError("Query must not be empty")
        q = self.model.encode_queries([query])[0]                # (dim,)
        scores = self.embeddings @ q                             # cosine (vectors are normalised)
        allowed = np.array([matches_filters(d, filters) for d in self.docs])
        scores = np.where(allowed, scores, -np.inf)              # pre-filter: excluded docs can't win
        order = np.argsort(-scores)[:top_k]
        return [Result(self.docs[i], float(scores[i]), "dense") for i in order if np.isfinite(scores[i])]


class ParentChildRetriever:
    """Search small CHILD chunks (precise match), return their PARENT sections
    (complete context). Several children of one parent count once."""

    def __init__(self, parents, children, model):
        self.parents = {p.id: p for p in parents}
        self.children = children
        self.model = model
        self.child_vecs = model.encode_documents([c.text for c in children])

    def search(self, query: str, top_k: int = 2) -> list[tuple[object, object, float]]:
        q = self.model.encode_queries([query])[0]
        scores = self.child_vecs @ q
        results, seen = [], set()
        for i in np.argsort(-scores):
            child = self.children[i]
            pid = child.metadata["parent_id"]
            if pid in seen:
                continue
            seen.add(pid)
            results.append((self.parents[pid], child, float(scores[i])))   # (parent, matched child, score)
            if len(results) == top_k:
                break
        return results
