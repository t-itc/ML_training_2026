"""ScriptedToolModel — an OFFLINE stand-in for an LLM (LLM_PROVIDER=mock).

It is NOT intelligent: simple rules decide which tool calls to emit and how to word the answer.
It exists so that tests, CI and classroom demos run without Ollama or an API key, and it speaks the
exact same protocol as a real chat model:

    HumanMessage ──► AIMessage(tool_calls=[...]) ──► ToolMessage(s) ──► AIMessage(content="final answer")
"""
from __future__ import annotations

import csv
import re
import uuid
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.utils.function_calling import convert_to_openai_tool
from pydantic import Field

from config import PROJECT_ROOT
from memory.agentic_memory import evaluate, extract_candidates

with open(PROJECT_ROOT / "data" / "employees.csv", encoding="utf-8") as _f:
    _EMPLOYEES = [r["name"] for r in csv.DictReader(_f)]

_HR_IT_WORDS = {"leave", "expense", "helpdesk", "wfh", "work from home", "remote", "learning budget", "password policy", "laptop",
                "software", "carry forward", "policy", "mfa"}
_WORD_OPS = [("multiplied by", "*"), ("times", "*"), ("plus", "+"), ("minus", "-"), ("divided by", "/"),
             ("to the power of", "**"), ("×", "*"), ("÷", "/")]


def _text(m: BaseMessage) -> str:
    return m.content if isinstance(m.content, str) else str(m.content)


def _find_math(q: str) -> str | None:
    s = q.lower()
    for word, op in _WORD_OPS:
        s = s.replace(word, op)
    s = re.sub(r"(?<=\d)\s*x\s*(?=\d)", "*", s)
    s = re.sub(r"(\d+(?:\.\d+)?)\s*% of\s*(\d+(?:\.\d+)?)", r"(\1 / 100) * \2", s)
    best = None
    for m in re.finditer(r"[\d\.\s\(\)\+\-\*/%]+", s):
        cand = m.group().strip()
        if re.search(r"\d\s*(\*\*|[\+\-\*/%])\s*[\d\(]", cand) and (best is None or len(cand) > len(best)):
            best = cand
    if best is None and (m := re.search(r"sqrt\s*\(?\s*(\d+(?:\.\d+)?)\)?", s)):
        best = f"sqrt({m.group(1)})"
    return best


def _call(name: str, **args) -> dict:
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


class ScriptedToolModel(BaseChatModel):
    """Rule-based fake chat model that supports bind_tools() and tool calling."""

    bound_tools: list[str] = Field(default_factory=list)

    @property
    def _llm_type(self) -> str:
        return "scripted-mock"

    def bind_tools(self, tools, **kwargs: Any):  # create_agent calls this with the registered tools
        names = [convert_to_openai_tool(t)["function"]["name"] for t in tools]
        return self.model_copy(update={"bound_tools": names})

    # ------------------------------------------------------------------ protocol
    def _generate(self, messages: list[BaseMessage], stop=None, run_manager=None, **kwargs) -> ChatResult:
        msg = self._respond(messages)
        n_in = sum(len(_text(m)) for m in messages) // 4 + 20
        n_out = max(1, (len(_text(msg)) + len(str(msg.tool_calls))) // 4)
        msg.usage_metadata = {"input_tokens": n_in, "output_tokens": n_out, "total_tokens": n_in + n_out}
        msg.response_metadata = {"model_name": "scripted-mock"}
        return ChatResult(generations=[ChatGeneration(message=msg)])

    def _respond(self, messages: list[BaseMessage]) -> AIMessage:
        system = next((_text(m) for m in messages if isinstance(m, SystemMessage)), "")
        h_idx = max((i for i, m in enumerate(messages) if isinstance(m, HumanMessage)), default=-1)
        question = _text(messages[h_idx]) if h_idx >= 0 else ""
        history = [_text(m) for m in messages[:h_idx] if isinstance(m, HumanMessage)]
        tail = messages[h_idx + 1:]

        if self.bound_tools == ["Memories"]:  # with_structured_output(Memories) from extract_with_llm()
            text = question.split("User message:", 1)[-1].strip()
            mems = [{"category": c["category"], "key": c["key"], "content": c["content"]} for c in extract_candidates(text)]
            return AIMessage(content="", tool_calls=[_call("Memories", memories=mems)])

        if tail and isinstance(tail[-1], ToolMessage):  # tools have run -> write the final answer
            return AIMessage(content=self._final(question, [m for m in tail if isinstance(m, ToolMessage)], system, history))

        calls = self._plan(question, system, history)
        if calls:
            return AIMessage(content="", tool_calls=calls)
        return AIMessage(content=self._direct(question, system, history, memory_text=""))

    # ------------------------------------------------------------------ decide which tools
    def _has(self, name: str) -> bool:
        return name in self.bound_tools

    def _plan(self, question: str, system: str, history: list[str]) -> list[dict]:
        q = question.lower()
        calls: list[dict] = []
        if self._has("calculator") and (expr := _find_math(question)):
            calls.append(_call("calculator", expression=expr))
        if self._has("get_current_datetime") and re.search(r"\b(date|time|today'?s?|what day|day is it)\b", q) \
                and not re.search(r"\b(i'?m|i am)\b.*\btoday\b", q):
            calls.append(_call("get_current_datetime", timezone="Asia/Kolkata"))
        if self._has("get_weather") and "weather" in q:
            m = re.search(r"weather (?:like )?(?:in|at|for) ([a-z ]+?)(?:\?|$|,|\.| and | today| now)", q)
            calls.append(_call("get_weather", city=(m.group(1).strip().title() if m else "Bengaluru")))
        if self._has("query_employee"):
            emp = re.search(r"\b(E\d{3})\b", question, re.I)
            name = next((n.split()[0] for n in _EMPLOYEES if n.split()[0].lower() in q), None)
            if emp or (name and re.search(r"employee|manager|role|leave balance|record|who is|location|department", q)):
                calls.append(_call("query_employee", name_or_id=emp.group(1).upper() if emp else name))
        if self._has("search_knowledge") and (any(w in q for w in _HR_IT_WORDS) or q.startswith("search")) \
                and not any(c["name"] == "query_employee" for c in calls):
            calls.append(_call("search_knowledge", query=re.sub(r"[?.!]", "", question)[:80]))
        if self._has("save_memory"):
            for c in extract_candidates(question):
                if evaluate(c["content"], c["category"]).allowed:  # mock follows the memory policy
                    calls.append(_call("save_memory", content=c["content"], category=c["category"], key=c["key"]))
        if self._has("delete_memory") and (m := re.search(r"\bforget (?:my |about my )?(\w+)", q)):
            calls.append(_call("delete_memory", key=m.group(1)))
        has_memory_ctx = "## What you know about this user" in system
        wants_personal = re.search(r"suggest|recommend|what do you (?:know|remember) about me|who am i|what is my name|what's my name", q)
        name_in_history = any(re.search(r"my name is", h, re.I) for h in history)
        if self._has("search_memory") and not has_memory_ctx and wants_personal and not calls \
                and not ("name" in q and name_in_history):
            calls.append(_call("search_memory", query=question[:80]))
        return calls

    # ------------------------------------------------------------------ word the answer
    def _final(self, question: str, tool_msgs: list[ToolMessage], system: str, history: list[str]) -> str:
        parts, memory_text, saved = [], "", []
        for tm in tool_msgs:
            out = _text(tm)
            if out.startswith("Error"):
                parts.append(f"I couldn't complete the {tm.name} step: {out[7:].split('. ')[0].rstrip('.')}.")
            elif tm.name == "calculator":
                expr, _, res = out.partition(" = ")
                parts.append(f"{expr.replace('*', '×')} = {res}.")
            elif tm.name in {"get_current_datetime", "get_weather"}:
                parts.append(out)
            elif tm.name == "search_knowledge":
                parts.append("According to the knowledge base: " + out.splitlines()[0])
            elif tm.name == "query_employee":
                parts.append("Employee record: " + out)
            elif tm.name == "save_memory":
                saved.append(out)
            elif tm.name == "delete_memory":
                parts.append(out)
            elif tm.name in {"search_memory", "get_user_profile"}:
                memory_text += "\n" + out
        if saved:
            name = re.search(r"User's name is (\w+)", " ".join(saved))
            greet = f"Nice to meet you, {name.group(1)}! " if name else ""
            verb = "updated" if any(s.startswith("Updated") for s in saved) else "will remember"
            facts = "; ".join(re.sub(r"^\w+ memory \[[^\]]+\]: |^Already known \[[^\]]+\]: ", "", s) for s in saved)
            parts.append(f"{greet}Got it — I {verb} that ({facts}). I'll use this in future conversations.")
        if memory_text or not parts:
            parts.append(self._direct(question, system, history, memory_text))
        return " ".join(parts)

    def _direct(self, question: str, system: str, history: list[str], memory_text: str) -> str:
        q = question.lower()
        mem = (system.split("## What you know about this user", 1)[-1] if "## What you know" in system else "") + memory_text
        mem_l = mem.lower()

        if re.search(r"what(?:'s| is) my name|who am i", q):
            for h in reversed(history):
                if m := re.search(r"my name is (\w+)", h, re.I):
                    return f"Your name is {m.group(1).title()}."
            if m := re.search(r"user's name is (\w+)", mem, re.I):
                return f"Your name is {m.group(1)}."
            return "I don't know your name yet — you haven't told me in this conversation."
        rejected = [evaluate(c["content"], c["category"]) for c in extract_candidates(question)]
        rejected = [d for d in rejected if not d.allowed]
        if rejected:
            if "instruction" in rejected[0].reason:
                return "I can't store instructions as memories — I only remember facts about you."
            return "I won't store that — passwords, OTPs and other secrets should never be saved in memory."
        if m := re.search(r"my name is (\w+)", question, re.I):
            return f"Nice to meet you, {m.group(1).title()}!"
        if re.search(r"suggest|recommend", q) and "project" in q:
            return self._project(mem_l, mem)
        if m := re.search(r"explain ([a-z0-9 \-]+)", q):
            return self._explain(m.group(1).strip(), mem_l)
        if re.match(r"^(hi|hello|hey)\b", q):
            return "Hello! I'm Aria, your personal AI assistant. How can I help?"
        if extract_candidates(question):
            return "Thanks for sharing — I'll keep that in mind for this conversation."
        if re.search(r"what do you (know|remember) about me", q):
            facts = [ln.split("] ", 1)[-1] for ln in mem.splitlines() if ln.startswith("- [")]
            return ("Here is what I remember about you: " + "; ".join(facts) + ".") if facts \
                else "I don't have anything stored about you yet."
        return ("[mock model] I can calculate, give the date/time, check the weather, search Acme policies, "
                "look up employees and remember things about you. Set LLM_PROVIDER=ollama for real reasoning.")

    @staticmethod
    def _project(mem_l: str, mem: str) -> str:
        role = re.search(r"user is an? ([a-z ]+)", mem, re.I)
        stack = re.search(r"works with ([^\n.]+)", mem, re.I)
        if stack and "langchain" in stack.group(1).lower():
            who = f"As a {role.group(1).strip()} who" if role else "Since you"
            return (f"{who} works with {stack.group(1).strip()}, I recommend building an AI Agent application: "
                    "a personal assistant with custom tools (calculator, search, database) and long-term memory "
                    "in a LangGraph Store, plus a Langfuse dashboard to trace its decisions.")
        if stack or role:
            base = stack.group(1).strip() if stack else role.group(1).strip()
            return f"Based on your background ({base}), try an end-to-end RAG assistant over your team's documents."
        return ("I don't know your background yet. A good general project: a RAG chatbot over your own documents. "
                "Tell me your role and tech stack and I'll tailor the suggestion.")

    @staticmethod
    def _explain(topic: str, mem_l: str) -> str:
        short = "keep answers short" in mem_l
        wants_code = "python example" in mem_l or "code example" in mem_l
        if "rag" in topic:
            text = ("RAG (Retrieval-Augmented Generation) has two stages: (1) indexing — split documents into chunks, "
                    "embed them and store the vectors; (2) query time — embed the question, retrieve the top-k similar "
                    "chunks and pass them to the LLM as context so the answer is grounded in your data.")
        elif "agent" in topic:
            text = ("An AI agent is an LLM in a loop: it reads the request, decides whether a tool is needed, calls it, "
                    "observes the result and repeats until it can give a final answer.")
        else:
            text = f"{topic.title()}: a concise overview would go here (the mock model only knows RAG and agents)."
        if short:  # lesson learned from feedback: keep it short
            text = {"rag": "In short: RAG retrieves the most relevant chunks from a vector store and gives them to the "
                           "LLM as context, so answers are grounded in your documents.",
                    "agent": "In short: an agent is an LLM in a loop that decides which tools to call until it can answer."
                    }.get("rag" if "rag" in topic else "agent" if "agent" in topic else "", text)
        if "simpler language" in mem_l:  # lesson from "too technical" feedback
            text = {"rag": "In simple terms: RAG is like an open-book exam. Before answering, the assistant looks up "
                           "the most relevant pages in your documents and answers from them instead of from memory.",
                    "agent": "In simple terms: an agent is an assistant that can decide to use tools, such as a "
                             "calculator or a search, before it answers."}.get(
                "rag" if "rag" in topic else "agent" if "agent" in topic else "", text)
        if wants_code:
            text += ("\n\nPython example (you prefer code):\n```python\n"
                     "chunks = splitter.split_documents(docs)\n"
                     "store = Chroma.from_documents(chunks, OllamaEmbeddings(model='nomic-embed-text'))\n"
                     "context = store.similarity_search(question, k=3)\n"
                     "answer = llm.invoke(f'Context: {context}\\nQuestion: {question}')\n```")
        return text
