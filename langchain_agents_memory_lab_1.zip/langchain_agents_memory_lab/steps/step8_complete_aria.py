"""STEP 8 · The complete Aria: everything from steps 1–7 in one agent (agents/assistant_agent.py)

    LLM + 5 tools + 4 memory tools + checkpointer (short-term) + SqliteStore (long-term)
        + memory_injection (retrieve) + reflect_and_log (episodes, missed facts) + handle_tool_errors

Run:  python -m steps.step8_complete_aria          then try the interactive app:  python main.py --trace
"""
from agents.assistant_agent import ask, build_agent, tools_called
from memory.long_term import clear_user, get_store

store = get_store("memory")                  # main.py uses get_store("sqlite") so memories survive restarts
clear_user(store, "mahesh")
aria = build_agent("agentic", store=store)   # the same builder used by main.py, the scripts and the tests

conversation = [
    ("t1", "My name is Mahesh and I prefer explanations with Python examples."),
    ("t1", "What is 18% of 2450, and what is today's date?"),
    ("t2", "What is my name?"),               # new thread -> long-term memory
    ("t2", "Explain RAG architecture"),       # personalised by the stored preference
]
for thread, text in conversation:
    answer, result = ask(aria, text, thread_id=thread, user_id="mahesh")
    print(f"[{thread}] {text}\n      tools={tools_called(result)}\n      {answer[:180]}\n")
