"""Index data/documents into ChromaDB with ACL metadata.   python -m scripts.ingest [--reset]"""
import argparse
import json

from app.retrieval.store import ingest

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true", help="drop and rebuild the collection")
    print(json.dumps(ingest(reset=ap.parse_args().reset), indent=2))
