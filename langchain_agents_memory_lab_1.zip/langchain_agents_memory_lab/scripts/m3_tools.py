"""Module 3 — tools: watch the agent choose and call tools.

    python -m scripts.m3_tools
    python -m scripts.m3_tools -q "What's the weather in Pune and the leave balance of Arjun?"
"""
import argparse

from agents.assistant_agent import ask, build_agent, tools_called
from agents.observability import AgentTracer
from scripts._common import banner, show
from tools import BASIC_TOOLS

DEMO = [
    "What is 250 multiplied by 12, and what is today's date?",   # 2 tools in ONE step (parallel tool calls)
    "What's the weather in Mumbai?",
    "How many leave days can I carry forward?",                   # search tool -> policy HR-01
    "Who is Priya's manager?",                                    # database tool
    "What is 10 divided by 0?",                                   # tool returns an error -> agent explains
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-q", "--question")
    args = ap.parse_args()
    banner("Module 3 · Agent with tools")
    agent = build_agent("tools")
    print("Registered tools:", ", ".join(t.name for t in BASIC_TOOLS))
    for q in [args.question] if args.question else DEMO:
        print("\n" + "-" * 88)
        tracer = AgentTracer()
        answer, result = ask(agent, q, callbacks=[tracer])
        show(q, answer, tools_called(result))
        s = tracer.summary()
        print(f"   steps: {s['llm_calls']} LLM call(s), {s['tool_calls']} tool call(s), {s['total_ms']} ms")


if __name__ == "__main__":
    main()
