"""Module 5 — end-to-end test of the complete assistant (the 7 scenarios from the training plan).

    python -m scripts.m5_scenarios
"""
import re

from agents.assistant_agent import ask, build_agent, tools_called
from memory.long_term import clear_user, get_store, list_memories
from scripts._common import LINE, banner, show

USER = "mahesh"


def main() -> None:
    banner("Module 5 · Intelligent Personal AI Assistant — scenario tests")
    store = get_store("sqlite")
    clear_user(store, USER)
    agent = build_agent("agentic", store=store)
    results = []

    def run(no, scenario, thread, q, expect, test):
        answer, res = ask(agent, q, thread_id=thread, user_id=USER)
        tools = tools_called(res)
        show(q, answer, tools, label=f"{no} {thread}")
        ok = bool(test(answer, tools))
        results.append((no, scenario, expect, ok))
        print(f"   -> {'PASS' if ok else 'FAIL'}: {expect}")

    mems = lambda: " ".join(i.value["content"].lower() for i in list_memories(store, USER))  # noqa: E731
    run(1, "Ask a calculation", "t1", "What is 1250 * 18?", "calls calculator",
        lambda a, t: "calculator" in t and "22,500" in a)
    run(2, "Ask today's date", "t1", "What is today's date?", "calls get_current_datetime",
        lambda a, t: "get_current_datetime" in t)
    run(3, "Share user preference", "t1", "My name is Mahesh and I prefer explanations with Python examples.",
        "saves relevant memory", lambda a, t: "save_memory" in t and "python examples" in mems())
    run(4, "Ask follow-up question", "t1", "What is my name?", "uses short-term memory (same thread)",
        lambda a, t: "mahesh" in a.lower())
    run(5, "Start new session", "t2", "What is my name?", "retrieves long-term memory (new thread)",
        lambda a, t: "mahesh" in a.lower())
    run(6, "Give feedback", "t2", "Your last answer was too long.", "updates agentic memory (lesson)",
        lambda a, t: "keep answers short" in mems())
    run(7, "Related question later", "t3", "Explain RAG architecture", "uses preference + lesson",
        lambda a, t: "python" in a.lower() and bool(re.search(r"in short|```", a.lower())))

    print("\n" + LINE)
    print(f"{'#':<3}{'Scenario':<26}{'Expected behaviour':<42}Result")
    for no, sc, exp, ok in results:
        print(f"{no:<3}{sc:<26}{exp:<42}{'PASS' if ok else 'FAIL'}")
    print(f"\n{sum(r[3] for r in results)}/{len(results)} scenarios passed")


if __name__ == "__main__":
    main()
