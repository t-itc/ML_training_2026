"""DateTime tool — the LLM has no clock, so it must ask one."""
from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from langchain.tools import tool


@tool(parse_docstring=True)
def get_current_datetime(timezone: str = "Asia/Kolkata") -> str:
    """Return the current date, day of week and time.

    Use whenever the user asks about today, the date, the time or the day of the week.

    Args:
        timezone: IANA time zone name, e.g. "Asia/Kolkata", "Europe/London", "UTC".
    """
    try:
        now = datetime.now(ZoneInfo(timezone))
    except (ZoneInfoNotFoundError, ValueError):
        return f"Error: unknown time zone {timezone!r}. Use an IANA name such as 'Asia/Kolkata'."
    return now.strftime(f"Today is %A, %d %B %Y. Current time is %H:%M ({timezone}).")
