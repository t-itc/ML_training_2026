"""Request orchestration: one Langfuse trace per request.

input policy ──block──────────────────────────────────────────────► refusal
     │ review ────────────────────────────────────────────────────► human review queue
     │ allow
     ├─ tool intent (deterministic, user text only) ─ low ─► run ───► tool_result
     │                                               └ high ► approval queue ► pending_approval
     └─ retrieve (ACL) ─ none ─────────────────────────────────────► abstain (no LLM)
            └ prompt (untrusted docs) ─► LLM ─► output schema+policy ─invalid─► fallback
                                                   └ groundedness ─ low ──────► abstain
                                                                    └ ok ─────► answered
"""
from __future__ import annotations

import time
import uuid

from langfuse import observe, propagate_attributes

from app.config import APP_VERSION, get_policy, get_settings
from app.llm import get_llm
from app.policy.input_policy import InputDecision, evaluate_input
from app.policy.output_policy import OutputCheck, evaluate_groundedness, validate_output
from app.prompting import PROMPT_VERSION, PromptPackage, build_prompt
from app.retrieval.retriever import RetrievalResult, retrieve
from app.schemas import ChatResponse, Citation, Telemetry
from app.telemetry import telemetry
from app.tools import approvals
from app.tools.registry import detect_intent, plan, run_low_impact

REFUSALS = {
    "secret_in_message": "Please don't share passwords, keys or tokens in chat. If that was a real secret, change it now and tell security@acme.example.",
    "prompt_injection": "I can't help with that request. I can answer questions about Acme HR policies.",
    "off_topic": "I can only help with Acme HR policies: leave, remote work, expenses, IT security, pay and HR processes.",
}
REVIEW_MESSAGE = ("This needs a person rather than an automated answer. I've passed it confidentially to the HR team "
                  "(reference {ref}); someone will contact you within one working day.")
WELLBEING_SUFFIX = " If you are in immediate danger or thinking about harming yourself, please contact local emergency services or the Employee Assistance Programme now."


def versions() -> dict:
    s, p = get_settings(), get_policy()
    return {"app_version": APP_VERSION, "policy_version": p.version, "policy_sha": p.sha256,
            "prompt_version": PROMPT_VERSION, "llm_provider": s.llm_provider,
            "chat_model": s.chat_model if s.llm_provider == "ollama" else "mock-worst-case",
            "judge_model": s.judge_model if (s.use_llm_judge and s.llm_provider == "ollama") else "lexical",
            "embedder": s.embedder}


# ----------------------------------------------------------------------------- traced steps
@observe(name="guardrail.input_policy", as_type="guardrail", capture_input=False)
def input_step(message: str) -> InputDecision:
    d = evaluate_input(message)
    telemetry.client.update_current_span(
        input={"message": message}, output={"decision": d.decision, "reason": d.reason_code, "signals": d.signals, "flags": d.flags},
        level="WARNING" if d.decision != "allow" or d.flags else "DEFAULT", status_message=d.reason_code)
    return d


@observe(name="retrieval.authorized", as_type="retriever", capture_input=False, capture_output=False)
def retrieval_step(query: str, roles: list[str]) -> RetrievalResult:
    r = retrieve(query, roles)
    telemetry.client.update_current_span(
        input={"query": query, "roles": roles},
        output={"chunks": [{"id": c.chunk_id, "sim": c.similarity} for c in r.chunks], "candidates": r.candidates,
                "below_threshold": r.below_threshold, "acl_violations": r.acl_violations},
        level="ERROR" if r.acl_violations else "DEFAULT")
    return r


@observe(name="guardrail.output_policy", as_type="guardrail", capture_input=False, capture_output=False)
def output_step(raw: str, pkg: PromptPackage) -> OutputCheck:
    chk = validate_output(raw, pkg)
    telemetry.client.update_current_span(input={"raw": raw}, output={"ok": chk.ok, "violations": chk.violations},
                                         level="WARNING" if chk.violations else "DEFAULT")
    return chk


@observe(name="evaluator.groundedness", as_type="evaluator", capture_input=False, capture_output=False)
def grounding_step(answer: str, cited_text: str):
    g = evaluate_groundedness(answer, cited_text)
    telemetry.client.update_current_span(output={"score": g.score, "method": g.method, "unsupported": g.unsupported},
                                         level="WARNING" if g.score < get_policy()["grounding"]["min_score"] else "DEFAULT")
    return g


# ----------------------------------------------------------------------------- main entry
@observe(name="hr-assistant.chat", capture_input=False, capture_output=False)
def handle_chat(message: str, principal: dict, session_id: str | None = None, request_id: str | None = None,
                debug: dict | None = None) -> ChatResponse:
    """`debug` (tests / regression only, never exposed by the API) receives internal metadata and scores."""
    request_id = request_id or f"req_{uuid.uuid4().hex[:16]}"
    pol = get_policy()
    lf = telemetry.client
    t0 = time.perf_counter()
    v = versions()
    out = {"status": "fallback", "answer": pol["output"]["fallback_message"], "reason_code": "internal_error",
           "citations": [], "approval_id": None}
    scores: dict[str, tuple] = {}
    trace_meta: dict = {}

    with propagate_attributes(user_id=principal["user_id"], session_id=session_id, version=APP_VERSION,
                              tags=["hr-assistant", f"policy:{pol.version}", v["llm_provider"]],
                              metadata={k: str(x) for k, x in v.items()} | {"request_id": request_id}):
        lf.update_current_span(input={"message": message, "roles": principal["roles"]})
        try:
            _run(message, principal, request_id, out, scores, trace_meta)
        except Exception as exc:  # never leak internals to the user
            scores["error"] = (1, "BOOLEAN")
            lf.update_current_span(level="ERROR", status_message=type(exc).__name__)
            out.update(status="fallback", answer=pol["output"]["fallback_message"], reason_code=f"error:{type(exc).__name__}")

        scores["status"] = (out["status"], "CATEGORICAL")
        scores["blocked"] = (int(out["status"] == "blocked"), "BOOLEAN")
        scores["abstained"] = (int(out["status"] == "abstained"), "BOOLEAN")
        for name, (val, dtype) in scores.items():
            lf.score_current_trace(name=name, value=val, data_type=dtype)
        lf.update_current_span(output={"status": out["status"], "answer": out["answer"], "reason_code": out["reason_code"]},
                               metadata=trace_meta | {"latency_ms": round((time.perf_counter() - t0) * 1000)})
        trace_id = lf.get_current_trace_id()

    if debug is not None:
        debug.update(meta=trace_meta, scores={k: v_[0] for k, v_ in scores.items()}, trace_id=trace_id)
    tele = telemetry.finalize(request_id, trace_id, {
        "user_id": principal["user_id"], "status": out["status"], "reason_code": out["reason_code"],
        "policy_version": pol.version, "prompt_version": PROMPT_VERSION, "scores": {k: v_[0] for k, v_ in scores.items()},
        "docs_in_prompt": trace_meta.get("docs_in_prompt", [])})
    return ChatResponse(request_id=request_id, policy_version=pol.version, telemetry=Telemetry(**tele),
                        status=out["status"], answer=out["answer"], reason_code=out["reason_code"],
                        citations=out["citations"], approval_id=out["approval_id"])


def _run(message, principal, request_id, out, scores, meta) -> None:
    pol = get_policy()
    lf = telemetry.client

    # 1. Input policy -------------------------------------------------------------
    d = input_step(message)
    scores["input_decision"] = (d.decision, "CATEGORICAL")
    scores["injection_score"] = (d.signals.get("injection_score", 0.0), "NUMERIC")
    scores["pii_redacted"] = (int("pii_redacted" in d.flags), "BOOLEAN")
    if d.decision == "block":
        if d.reason_code == "pii_not_accepted":
            rules = pol["pii"]["types"]
            msg = " ".join(rules[t]["reason"] for t in d.signals["pii_blocked_types"]) + " Please remove it and ask again."
        else:
            msg = REFUSALS[d.reason_code]
        out.update(status="blocked", answer=msg, reason_code=d.reason_code)
        return
    if d.decision == "review":
        aid = approvals.create("review", None, {"category": d.signals.get("sensitive_category"), "message": message},
                               principal["user_id"], "hr_admin", request_id, lf.get_current_trace_id(), pol.version)
        msg = REVIEW_MESSAGE.format(ref=aid) + (WELLBEING_SUFFIX if d.signals.get("sensitive_category") == "wellbeing" else "")
        scores["human_review"] = (1, "BOOLEAN")
        out.update(status="review", answer=msg, reason_code=d.reason_code, approval_id=aid)
        return

    text = d.user_message

    # 2. Tools: deterministic intent on the USER message only ------------------------
    intent = detect_intent(text)
    if intent:
        p = plan(intent, text, principal)
        meta["tool"] = intent
        if p.needs_input:
            out.update(status="answered", answer=p.needs_input, reason_code=f"tool_needs_input:{intent}")
            return
        if p.impact == "low":
            out.update(status="tool_result", answer=run_low_impact(p), reason_code=f"tool:{intent}")
            return
        cfg = pol["tools"][intent]
        aid = approvals.create("tool", intent, p.arguments, principal["user_id"], cfg["approver_role"], request_id,
                               lf.get_current_trace_id(), pol.version)
        scores["approval_required"] = (1, "BOOLEAN")
        out.update(status="pending_approval", approval_id=aid, reason_code=f"approval:{intent}",
                   answer=f"I've sent your '{intent.replace('_', ' ')}' request to HR for approval (reference {aid}). "
                          f"Nothing has been changed yet.")
        return

    # 3. Retrieval with server-side authorization ------------------------------------
    r = retrieval_step(text, principal["roles"])
    scores["acl_violations"] = (r.acl_violations, "NUMERIC")
    if not r.chunks:
        out.update(status="abstained", answer=pol["output"]["abstain_message"], reason_code="no_relevant_documents")
        return

    # 4. Prompt with untrusted documents ---------------------------------------------
    pkg = build_prompt(text, r.chunks)
    meta["docs_in_prompt"] = sorted({c.doc_id for c in pkg.labels.values()})
    meta["quarantined_chunks"] = pkg.quarantined
    scores["context_injection_chunks"] = (len(pkg.quarantined) + len(pkg.flagged), "NUMERIC")
    if not pkg.labels:
        out.update(status="abstained", answer=pol["output"]["abstain_message"], reason_code="all_context_quarantined")
        return

    # 5. LLM + output validation ---------------------------------------------------------
    s = get_settings()
    raw = get_llm().complete(pkg.system, pkg.user, name="llm.answer", model=s.chat_model)
    chk = output_step(raw, pkg)
    if chk.output is not None and chk.output.tool_call is not None:
        scores["tool_call_rejected"] = (1, "BOOLEAN")          # tools never come from model output
        meta["rejected_tool_call"] = chk.output.tool_call.name
    if not chk.ok:
        scores["output_policy_violation"] = (1, "BOOLEAN")
        out.update(status="fallback", answer=pol["output"]["fallback_message"], reason_code="output_policy:" + ",".join(chk.violations))
        return
    o = chk.output
    if o.abstain:
        out.update(status="abstained", answer=pol["output"]["abstain_message"], reason_code="model_abstained")
        return
    if pol["grounding"]["require_citations"] and not o.citations:
        out.update(status="abstained", answer=pol["output"]["abstain_message"], reason_code="no_citations")
        return

    # 6. Groundedness and abstention -------------------------------------------------------
    cited = "\n".join(pkg.labels[c].text for c in o.citations)
    g = grounding_step(chk.answer, cited)
    scores["groundedness"] = (g.score, "NUMERIC")
    if g.score < pol["grounding"]["min_score"]:
        out.update(status="abstained", answer=pol["output"]["abstain_message"], reason_code="low_groundedness")
        return

    cites = [Citation(label=c, doc_id=pkg.labels[c].doc_id, title=pkg.labels[c].title, section=pkg.labels[c].section)
             for c in o.citations]
    out.update(status="answered", answer=chk.answer, citations=cites, reason_code="ok")
