"""Release gate: a policy (or prompt/model) change must be evaluated against the regression set first.

    python -m scripts.release_gate                       # uses reports/regression_results.json
    python -m scripts.release_gate --results path.json --policy path/to/policy.yaml

Fails (exit 1) when:
  * the current policy file hash differs from the one the regression results were produced with;
  * the prompt version differs from the evaluated one;
  * any critical case failed;
  * the pass rate or a category rate is below eval/baseline.json.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def gate(results_path: Path, policy_path: Path | None = None) -> list[str]:
    from app.config import load_policy
    from app.prompting import PROMPT_VERSION

    if not results_path.exists():
        return [f"no regression results at {results_path}: run `python -m eval.run_regression`"]
    s = json.loads(results_path.read_text())["summary"]
    pol = load_policy(policy_path) if policy_path else load_policy()
    base = json.loads((ROOT / "eval" / "baseline.json").read_text())
    problems = []
    if s["policy_sha"] != pol.sha256:
        problems.append(f"policy changed since last regression run (evaluated {s['policy_version']}/{s['policy_sha']}, "
                        f"current {pol.version}/{pol.sha256}): run the regression set")
    if s["prompt_version"] != PROMPT_VERSION:
        problems.append(f"prompt changed ({s['prompt_version']} -> {PROMPT_VERSION}): run the regression set")
    if s["critical_passed"] != s["critical_cases"]:
        problems.append(f"critical cases failing: {s['critical_cases'] - s['critical_passed']}")
    if s["pass_rate"] < base["min_pass_rate"]:
        problems.append(f"pass rate {s['pass_rate']:.2%} < baseline {base['min_pass_rate']:.0%}")
    for cat, min_rate in base["min_category_rate"].items():
        got = s["by_category"].get(cat, {}).get("rate", 0.0)
        if got < min_rate:
            problems.append(f"category {cat}: {got:.0%} < {min_rate:.0%}")
    return problems


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=str(ROOT / "reports" / "regression_results.json"))
    ap.add_argument("--policy", default=None)
    a = ap.parse_args()
    probs = gate(Path(a.results), Path(a.policy) if a.policy else None)
    if probs:
        print("RELEASE BLOCKED")
        for p in probs:
            print(" -", p)
        sys.exit(1)
    print("RELEASE GATE PASSED")
