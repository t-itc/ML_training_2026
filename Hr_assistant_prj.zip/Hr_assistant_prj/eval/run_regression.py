"""Regression evaluation of the full pipeline.

    python -m eval.run_regression              # deterministic: mock worst-case LLM + hashing embedder (CI)
    python -m eval.run_regression --live       # your .env settings (Ollama, MiniLM) - for release candidates
    python -m eval.run_regression --langfuse   # also log as a Langfuse experiment on dataset hr-assistant-regression

Writes reports/regression_results.json (machine-readable, read by the release gate) and
reports/regression_report.md (human-readable). Exit code 1 if any critical case fails.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REPORTS = ROOT / "reports"


def _isolate(live: bool) -> None:
    """Use a throw-away index and approval DB so the evaluation never touches real data."""
    tmp = Path(tempfile.mkdtemp(prefix="hr_eval_"))
    os.environ["CHROMA_DIR"] = str(tmp / "chroma")
    os.environ["APPROVALS_DB"] = str(tmp / "approvals.sqlite3")
    os.environ["TELEMETRY_FALLBACK_LOG"] = str(tmp / "telemetry_fallback.jsonl")
    if not live:
        os.environ["LLM_PROVIDER"] = "mock"
        os.environ["EMBEDDER"] = "hashing"


def check(case: dict, resp, debug: dict, approvals_before: int, approvals_after: list, executed: bool) -> list[str]:
    e, fails = case["expect"], []
    want = e["status"] if isinstance(e["status"], list) else [e["status"]]
    if resp.status not in want:
        fails.append(f"status {resp.status} not in {want} ({resp.reason_code})")
    cited = {c.doc_id for c in resp.citations}
    for d in e.get("cite", []):
        if d not in cited:
            fails.append(f"missing citation {d}")
    in_prompt = set(debug.get("meta", {}).get("docs_in_prompt", []))
    for d in e.get("not_in_prompt", []):
        if d in in_prompt:
            fails.append(f"UNAUTHORIZED DOCUMENT IN PROMPT: {d}")
    for s in e.get("contains", []):
        if s.lower() not in resp.answer.lower():
            fails.append(f"answer lacks '{s}'")
    for s in e.get("not_contains", []):
        if s.lower() in resp.answer.lower():
            fails.append(f"answer contains forbidden '{s}'")
    for k, v in e.get("score", {}).items():
        if debug.get("scores", {}).get(k) != v:
            fails.append(f"score {k}={debug.get('scores', {}).get(k)} != {v}")
    new = approvals_after[approvals_before:]
    if e.get("no_approval") and [a for a in new if a["kind"] == "tool"]:
        fails.append("tool approval created from untrusted input")
    if e.get("no_tool_executed") and executed:
        fails.append("tool executed")
    if "approval_tool" in e and not any(a["tool"] == e["approval_tool"] for a in new):
        fails.append(f"no approval created for {e['approval_tool']}")
    return fails


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--langfuse", action="store_true")
    ap.add_argument("--reports-dir", default=str(DEFAULT_REPORTS))
    args = ap.parse_args(argv)
    _isolate(args.live)

    from app.config import get_policy, reset_caches
    reset_caches()
    from app.pipeline import handle_chat, versions
    from app.retrieval.store import ingest
    from app.telemetry import telemetry
    from app.tools import approvals

    ingest(reset=True)
    users = {v["name"].split()[0].lower(): v for k, v in json.loads((ROOT / "data/users.json").read_text()).items()
             if not k.startswith("_")}
    cases = [json.loads(l) for l in (ROOT / "eval/regression_set.jsonl").read_text().splitlines() if l.strip()]
    executed_log = Path(os.environ["APPROVALS_DB"]).with_name("executed_actions.jsonl")

    def run_case(case: dict) -> dict:
        before = len(approvals.list_items(None))
        debug: dict = {}
        resp = handle_chat(case["message"], users[case["user"]], session_id="regression", debug=debug)
        fails = check(case, resp, debug, before, approvals.list_items(None), executed_log.exists())
        return {"id": case["id"], "category": case["category"], "critical": case["critical"], "passed": not fails,
                "failures": fails, "status": resp.status, "reason_code": resp.reason_code,
                "docs_in_prompt": debug.get("meta", {}).get("docs_in_prompt", []),
                "scores": debug.get("scores", {}), "trace_id": debug.get("trace_id")}

    results = [run_case(c) for c in cases]

    if args.langfuse and telemetry.enabled:
        lf = telemetry.client
        name = "hr-assistant-regression"
        try:
            lf.create_dataset(name=name, description="HR assistant regression set")
        except Exception:
            pass
        for c in cases:
            lf.create_dataset_item(dataset_name=name, id=f"{name}-{c['id']}", input=c,
                                   expected_output=c["expect"], metadata={"category": c["category"], "critical": c["critical"]})
        lf.run_experiment(
            name="HR assistant regression", run_name=f"policy {get_policy().version} {datetime.now():%Y-%m-%d %H:%M}",
            data=lf.get_dataset(name).items, max_concurrency=1, metadata={k: str(v) for k, v in versions().items()},
            task=lambda *, item, **kw: run_case(item.input),
            evaluators=[lambda *, output, **kw: {"name": "passed", "value": 1.0 if output["passed"] else 0.0,
                                                 "comment": "; ".join(output["failures"])[:500]}])
        telemetry.flush()

    by_cat = defaultdict(lambda: [0, 0])
    for r in results:
        by_cat[r["category"]][0] += r["passed"]
        by_cat[r["category"]][1] += 1
    critical = [r for r in results if r["critical"]]
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "mode": "live" if args.live else "deterministic",
        **versions(),
        "cases": len(results), "passed": sum(r["passed"] for r in results),
        "pass_rate": round(sum(r["passed"] for r in results) / len(results), 4),
        "critical_cases": len(critical), "critical_passed": sum(r["passed"] for r in critical),
        "by_category": {k: {"passed": p, "total": t, "rate": round(p / t, 4)} for k, (p, t) in sorted(by_cat.items())},
    }
    REPORTS = Path(args.reports_dir)
    REPORTS.mkdir(parents=True, exist_ok=True)
    (REPORTS / "regression_results.json").write_text(json.dumps({"summary": summary, "results": results}, indent=2))
    (REPORTS / "regression_report.md").write_text(render_md(summary, results))
    print(f"regression: {summary['passed']}/{summary['cases']} passed, critical {summary['critical_passed']}/{summary['critical_cases']}"
          f" | policy {summary['policy_version']} ({summary['policy_sha']})")
    for r in results:
        if not r["passed"]:
            print(f"  FAIL {r['id']}: {'; '.join(r['failures'])}")
    return 0 if summary["critical_passed"] == summary["critical_cases"] else 1


def render_md(s: dict, results: list[dict]) -> str:
    lines = [f"# Regression report", "",
             f"Generated {s['generated_at']} · mode **{s['mode']}** · policy **{s['policy_version']}** (`{s['policy_sha']}`) · "
             f"prompt `{s['prompt_version']}` · model `{s['chat_model']}` · judge `{s['judge_model']}` · embedder `{s['embedder']}`", "",
             f"**{s['passed']}/{s['cases']} passed ({s['pass_rate']:.0%})** · critical **{s['critical_passed']}/{s['critical_cases']}**", "",
             "| Category | Passed | Rate |", "|---|---|---|"]
    lines += [f"| {k} | {v['passed']}/{v['total']} | {v['rate']:.0%} |" for k, v in s["by_category"].items()]
    lines += ["", "| Case | Category | Critical | Result | Status | Reason | Docs in prompt |", "|---|---|---|---|---|---|---|"]
    for r in results:
        res = "✅" if r["passed"] else "❌ " + "; ".join(r["failures"])
        lines.append(f"| `{r['id']}` | {r['category']} | {'yes' if r['critical'] else ''} | {res} | {r['status']} | "
                     f"`{r['reason_code']}` | {', '.join(r['docs_in_prompt']) or '—'} |")
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    sys.exit(main())
