"""Approval queue (SQLite). High-impact tool calls and human-review requests wait here for an HR admin.

Rules enforced here (not in the UI):
  * only principals with the tool's approver_role may decide;
  * nobody can approve their own request (segregation of duties);
  * a request can be decided once; execution happens only after approval;
  * stored arguments are masked - no raw PII or secrets in the queue.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from app.config import get_settings
from app.policy.pii import mask_any

_LOCK = threading.Lock()
SCHEMA = """CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, tool TEXT, arguments TEXT NOT NULL,
  requester_id TEXT NOT NULL, approver_role TEXT NOT NULL, status TEXT NOT NULL,
  request_id TEXT, trace_id TEXT, policy_version TEXT,
  created_at TEXT NOT NULL, decided_by TEXT, decided_at TEXT, comment TEXT, result TEXT)"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _conn() -> sqlite3.Connection:
    path = Path(get_settings().approvals_db)
    path.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(path)
    c.row_factory = sqlite3.Row
    c.execute(SCHEMA)
    return c


def create(kind: str, tool: str | None, arguments: dict, requester_id: str, approver_role: str,
           request_id: str, trace_id: str | None, policy_version: str) -> str:
    aid = f"apr_{uuid.uuid4().hex[:12]}"
    with _LOCK, _conn() as c:
        c.execute("INSERT INTO approvals (id, kind, tool, arguments, requester_id, approver_role, status, request_id,"
                  " trace_id, policy_version, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                  (aid, kind, tool, json.dumps(mask_any(arguments)), requester_id, approver_role, "pending",
                   request_id, trace_id, policy_version, _now()))
    return aid


def list_items(status: str | None = None) -> list[dict]:
    with _conn() as c:
        q = "SELECT * FROM approvals" + (" WHERE status = ?" if status else "") + " ORDER BY created_at"
        rows = c.execute(q, (status,) if status else ()).fetchall()
    return [dict(r) | {"arguments": json.loads(r["arguments"])} for r in rows]


def get(aid: str) -> dict | None:
    with _conn() as c:
        r = c.execute("SELECT * FROM approvals WHERE id = ?", (aid,)).fetchone()
    return dict(r) | {"arguments": json.loads(r["arguments"])} if r else None


class ApprovalError(Exception):
    def __init__(self, status_code: int, message: str):
        super().__init__(message)
        self.status_code = status_code


def decide(aid: str, approver: dict, decision: str, comment: str, executor) -> dict:
    item = get(aid)
    if item is None:
        raise ApprovalError(404, "approval not found")
    if item["approver_role"] not in approver["roles"]:
        raise ApprovalError(403, "approver role required")
    if item["requester_id"] == approver["user_id"]:
        raise ApprovalError(403, "cannot approve your own request")
    if item["status"] != "pending":
        raise ApprovalError(409, f"already {item['status']}")
    # Claim atomically so two approvers can never execute the same request twice.
    with _LOCK, _conn() as c:
        claimed = c.execute("UPDATE approvals SET status='processing' WHERE id=? AND status='pending'", (aid,)).rowcount
    if claimed != 1:
        raise ApprovalError(409, "already being decided")
    result, status = None, "rejected"
    try:
        if decision == "approve":
            result = executor(item | {"decided_by": approver["user_id"]}) if item["kind"] == "tool" else {"note": "reviewed by HR"}
            status = "approved"
    except Exception as exc:  # execution failed: record it, never leave the item stuck in 'processing'
        result, status = {"error": type(exc).__name__}, "failed"
    with _LOCK, _conn() as c:
        c.execute("UPDATE approvals SET status=?, decided_by=?, decided_at=?, comment=?, result=? WHERE id=?",
                  (status, approver["user_id"], _now(), mask_any(comment), json.dumps(result), aid))
    return get(aid)
