"""Module 4.3 — short-term memory with a checkpointer and thread_id.

    python -m scripts.m4_short_term            # InMemorySaver
    python -m scripts.m4_short_term --sqlite   # SqliteSaver -> storage/checkpoints.db (survives restarts)

Real restart test (two terminals / two processes):
    python -m scripts.m4_short_term --phase write --saver sqlite     # then close the terminal
    python -m scripts.m4_short_term --phase read  --saver sqlite     # -> "Your name is Mahesh."
    (repeat with --saver memory -> "I don't know your name yet")
"""
import argparse
import uuid

from agents.assistant_agent import ask, build_agent
from memory.short_term import get_checkpointer, show_thread
from scripts._common import banner, show


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sqlite", action="store_true")
    ap.add_argument("--phase", choices=["write", "read"], help="two-process restart test")
    ap.add_argument("--saver", choices=["memory", "sqlite"], default="sqlite")
    args = ap.parse_args()
    if args.phase:
        agent = build_agent("short_term", checkpointer=get_checkpointer(args.saver))
        q = "My name is Mahesh." if args.phase == "write" else "What is my name?"
        show(q, ask(agent, q, thread_id="restart-demo")[0], label=f"{args.saver}/{args.phase}")
        return
    banner("Module 4.3 · Short-term memory (checkpointer + thread_id)")

    agent_without = build_agent("tools")                                   # no checkpointer
    agent = build_agent("short_term", checkpointer=get_checkpointer("sqlite" if args.sqlite else "memory"))
    t1, t2 = f"thread-A-{uuid.uuid4().hex[:4]}", f"thread-B-{uuid.uuid4().hex[:4]}"

    print("\n1) WITHOUT a checkpointer every call is stateless:")
    show("My name is Mahesh.", ask(agent_without, "My name is Mahesh.")[0])
    show("What is my name?", ask(agent_without, "What is my name?")[0])

    print(f"\n2) WITH a checkpointer, same thread_id = {t1}:")
    show("My name is Mahesh.", ask(agent, "My name is Mahesh.", thread_id=t1)[0], label=t1)
    show("What is my name?", ask(agent, "What is my name?", thread_id=t1)[0], label=t1)

    print(f"\n3) Different thread_id = {t2} (a new conversation):")
    show("What is my name?", ask(agent, "What is my name?", thread_id=t2)[0], label=t2)

    print(f"\n4) What the checkpointer stored for {t1}:")
    print("\n".join(show_thread(agent, t1)))
    snap = agent.get_state({"configurable": {"thread_id": t1}})
    print(f"\n   checkpoint_id={snap.config['configurable']['checkpoint_id'][:18]}…  messages={len(snap.values['messages'])}")

    print("\n5) Restart comparison: a NEW checkpointer object = what a new process sees")
    for kind in ("memory", "sqlite"):
        tid = f"restart-{kind}-{uuid.uuid4().hex[:4]}"
        before = build_agent("short_term", checkpointer=get_checkpointer(kind))
        ask(before, "My name is Mahesh.", thread_id=tid)
        after = build_agent("short_term", checkpointer=get_checkpointer(kind))   # "restarted" app
        answer = ask(after, "What is my name?", thread_id=tid)[0]
        saver = "InMemorySaver" if kind == "memory" else "SqliteSaver  "
        print(f"   {saver} after restart -> {answer}")


if __name__ == "__main__":
    main()
