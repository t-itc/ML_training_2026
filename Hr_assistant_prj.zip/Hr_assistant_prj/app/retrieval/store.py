"""Document catalog (ACL source of truth), chunking, ingestion into ChromaDB."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import chromadb

from app.config import get_settings
from app.retrieval.embeddings import get_embedder

ROLES = ("employee", "manager", "hr_admin")


@dataclass(frozen=True)
class DocMeta:
    doc_id: str
    title: str
    classification: str
    allowed_roles: tuple[str, ...]


def load_catalog(documents_dir: str | None = None) -> dict[str, DocMeta]:
    d = Path(documents_dir or get_settings().documents_dir)
    raw = json.loads((d / "catalog.json").read_text(encoding="utf-8"))
    return {k: DocMeta(k, v["title"], v["classification"], tuple(v["allowed_roles"]))
            for k, v in raw.items() if not k.startswith("_")}


def is_authorized(roles: list[str] | tuple[str, ...], doc: DocMeta) -> bool:
    return bool(set(roles) & set(doc.allowed_roles))


def chunk_markdown(text: str) -> list[tuple[str, str]]:
    """Split on '## ' headings -> [(section, text)]. Small docs keep one section per chunk."""
    title = re.search(r"^# (.+)$", text, re.M)
    parts = re.split(r"^## ", text, flags=re.M)
    chunks = []
    for part in parts[1:]:
        heading, _, body = part.partition("\n")
        body = " ".join(body.split())
        if body:
            chunks.append((heading.strip(), f"{title.group(1) if title else ''} - {heading.strip()}: {body}"))
    return chunks


@lru_cache(maxsize=4)
def _client(path: str):
    return chromadb.PersistentClient(path=path)


def get_collection(create: bool = False):
    s = get_settings()
    client = _client(s.chroma_dir)
    if create:
        return client.get_or_create_collection(s.collection, metadata={"hnsw:space": "cosine"}, embedding_function=None)
    return client.get_collection(s.collection, embedding_function=None)


def ingest(reset: bool = False) -> dict:
    s = get_settings()
    client = _client(s.chroma_dir)
    if reset:
        try:
            client.delete_collection(s.collection)
        except Exception:
            pass
    col = get_collection(create=True)
    catalog = load_catalog()
    emb = get_embedder()
    ids, docs, metas = [], [], []
    for doc_id, meta in catalog.items():
        text = (Path(s.documents_dir) / doc_id).read_text(encoding="utf-8")
        for i, (section, chunk) in enumerate(chunk_markdown(text)):
            ids.append(f"{doc_id}::{i}")
            docs.append(chunk)
            m = {"doc_id": doc_id, "title": meta.title, "section": section, "classification": meta.classification,
                 "embedder": emb.name}
            m.update({f"acl_{r}": r in meta.allowed_roles for r in ROLES})   # copy of the ACL for pre-filtering
            metas.append(m)
    col.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=emb.embed_documents(docs))
    return {"documents": len(catalog), "chunks": len(ids), "embedder": emb.name, "collection": s.collection}
