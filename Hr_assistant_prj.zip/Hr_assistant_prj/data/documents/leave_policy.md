# Leave Policy

## Annual leave
Every permanent employee is entitled to 24 working days of paid annual leave per calendar year. Annual leave accrues at 2 days for each completed month of service.

## Carry forward
A maximum of 10 unused annual leave days may be carried forward to the next calendar year. Any balance above 10 days lapses on 31 March.

## Sick leave
Employees receive 12 days of paid sick leave per year. A medical certificate is required for more than 2 consecutive sick days.

## Applying for leave
Leave requests are submitted in PeopleHub at least 5 working days in advance and must be approved by the reporting manager.
