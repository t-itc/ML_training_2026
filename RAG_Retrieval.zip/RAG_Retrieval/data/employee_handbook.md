# Employee Handbook

## 1. Working Arrangements

### 1.1 Remote Work
Employees may work remotely up to three days per week with manager approval. Remote working arrangements must be recorded in the HR portal. Employees working from home must connect through the company VPN.

### 1.2 Office Hours
Core office hours are 10 AM to 4 PM. Outside core hours, employees may plan their time flexibly.

## 2. Leave

### 2.1 Annual Leave
Employees receive 18 days of annual paid leave per calendar year. Up to five unused days may be carried over to the next year. Leave requests must be submitted at least two weeks in advance.

### 2.2 Sick Leave
Employees are entitled to 10 days of paid sick leave per year. A medical certificate is required for absences longer than two consecutive days.

### 2.3 Parental Leave
Primary caregivers receive 16 weeks of paid parental leave. Secondary caregivers receive 4 weeks.

## 3. Expenses and Travel

### 3.1 Expense Claims
Expense claims must be submitted within 30 days of the transaction date. Itemised receipts are required for every claim above $25.

### 3.2 Travel
Business-class flights are allowed only for journeys longer than eight hours. The daily meal allowance is $60 for domestic trips and $85 for international trips.

## 4. IT and Security

### 4.1 Passwords
Network passwords must be changed every 90 days and must contain at least 12 characters.

### 4.2 Helpdesk
The IT helpdesk operates from 9 AM to 6 PM on weekdays. Error code VPN-417 means the VPN certificate has expired.
