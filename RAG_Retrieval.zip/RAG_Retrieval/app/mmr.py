"""Maximum Marginal Relevance: pick results that are relevant AND different from each other."""
from __future__ import annotations

import numpy as np


def mmr(query_vec: np.ndarray, doc_vecs: np.ndarray, top_k: int = 4, lambda_mult: float = 0.5,
        candidate_ids: list[int] | None = None) -> list[int]:
    """Greedy MMR over normalised vectors.

    score(d) = lambda * sim(query, d) - (1 - lambda) * max sim(d, already selected)

    lambda_mult = 1.0 -> pure relevance (same as plain top-k)
    lambda_mult = 0.0 -> pure diversity
    Returns indices into doc_vecs, in selection order.
    """
    if not 0.0 <= lambda_mult <= 1.0:
        raise ValueError("lambda_mult must be between 0 and 1")
    candidates = list(range(len(doc_vecs))) if candidate_ids is None else list(candidate_ids)
    relevance = doc_vecs @ query_vec                         # sim(query, d) for every doc
    selected: list[int] = []
    while candidates and len(selected) < top_k:
        if selected:
            redundancy = np.max(doc_vecs[candidates] @ doc_vecs[selected].T, axis=1)
        else:
            redundancy = np.zeros(len(candidates))
        scores = lambda_mult * relevance[candidates] - (1 - lambda_mult) * redundancy
        best = candidates[int(np.argmax(scores))]
        selected.append(best)
        candidates.remove(best)
    return selected
