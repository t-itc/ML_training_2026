"""Module 4.5 — agentic memory: the agent decides what to remember, retrieves it and learns from feedback.

    python -m scripts.m4_agentic
"""
from agents.assistant_agent import ask, build_agent, tools_called
from memory.agentic_memory import build_memory_context
from memory.long_term import clear_user, format_memories, get_store, list_memories, recent_episodes
from scripts._common import banner, show

USER = "mahesh"
STEPS = [
    ("i1", "I prefer explanations with Python examples."),        # preference -> stored
    ("i1", "My OTP is 482913, please remember it."),               # secret -> ignored by policy
    ("i2", "Explain RAG architecture"),                            # new session -> retrieves preference
    ("i2", "That was too long."),                                  # feedback -> lesson stored
    ("i3", "Explain RAG architecture"),                            # uses preference + lesson
    ("i3", "Actually I prefer explanations with Java code examples."),  # same key -> UPDATE
]


def main() -> None:
    banner("Module 4.5 · Agentic memory (policy + retrieval + reflection)")
    store = get_store("sqlite")
    clear_user(store, USER)
    agent = build_agent("agentic", store=store)

    for thread, q in STEPS:
        if thread == "i2" and q.startswith("Explain"):
            print("\n   >> Memory retrieved and injected into the system prompt before the model call:")
            print("      " + build_memory_context(store, USER, q).replace("\n", "\n      "))
        answer, result = ask(agent, q, thread_id=thread, user_id=USER)
        show(q, answer, tools_called(result), label=thread)

    print("\n" + "-" * 88 + "\nLong-term memories (agent-managed):")
    for item in list_memories(store, USER):
        v = item.value
        print(f"   {item.key:<22} v{v['version']}  {v['source']:<10} {v['content']}")
    print("\nEpisodes (agent experience log):")
    for e in reversed(recent_episodes(store, USER, n=10)):
        print(f"   {e.value['question'][:55]!r:<60} tools={e.value['tools']}")


if __name__ == "__main__":
    main()
