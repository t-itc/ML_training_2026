"""Build docs/LangChain_Agents_Memory_Tutorial.html from the parts in docs/src.

Code walkers use REAL project code:  <div class="walker" data-src="tools/calculator.py::calculator">
The function/class (including decorators) is extracted with `ast`, so the tutorial never drifts
from the code. Run:  python docs/src/build.py
"""
from __future__ import annotations

import ast
import html
import re
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
ROOT = SRC.parents[1]
PARTS = ["00_head.html", "m0.html", "m1.html", "m2.html", "m3.html", "m4.html", "m4b.html", "m5.html", "m6.html", "m7.html",
         "zz_tail.html"]
OUT = ROOT / "docs" / "LangChain_Agents_Memory_Tutorial.html"
TITLE = "Building AI Agents with LangChain, Tools & Memory — Interactive Tutorial"


def extract(spec: str) -> tuple[str, int]:
    file, _, symbol = spec.partition("::")
    text = (ROOT / file).read_text(encoding="utf-8")
    if not symbol:
        return text.rstrip(), 1
    tree = ast.parse(text)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)) and node.name == symbol:
            start = min([node.lineno] + [d.lineno for d in node.decorator_list])
            lines = text.splitlines()[start - 1:node.end_lineno]
            return "\n".join(lines), start
    raise SystemExit(f"symbol {symbol!r} not found in {file}")


def fill_walkers(doc: str) -> str:
    def repl(m: re.Match) -> str:
        spec = m.group(1)
        code, start = extract(spec)
        file = spec.split("::")[0]
        return (f'<div class="walker" data-file="{file}" data-start="{start}">'
                f'<textarea class="wk-src" hidden>{html.escape(code, quote=False)}</textarea>')
    return re.sub(r'<div class="walker" data-src="([^"]+)">', repl, doc)


def project_data() -> dict[str, str]:
    """JSON blobs for the simulators, taken from the real project (tools + data files)."""
    import csv
    import json
    import os

    os.environ.setdefault("LLM_PROVIDER", "mock")
    sys.path.insert(0, str(ROOT))
    from langchain_core.utils.function_calling import convert_to_openai_tool

    from tools import ALL_TOOLS

    schemas = {t.name: convert_to_openai_tool(t) for t in ALL_TOOLS}
    with open(ROOT / "data" / "employees.csv", encoding="utf-8") as f:
        employees = list(csv.DictReader(f))
    dump = lambda o: json.dumps(o, ensure_ascii=False).replace("</", "<\\/")  # noqa: E731
    return {
        "__TOOL_SCHEMAS__": dump(schemas),
        "__KB__": dump(json.loads((ROOT / "data" / "knowledge_base.json").read_text(encoding="utf-8"))),
        "__WEATHER__": dump(json.loads((ROOT / "data" / "weather.json").read_text(encoding="utf-8"))),
        "__EMPLOYEES__": dump(employees),
        "__CONCEPTS__": dump({k: sorted(v) for k, v in __import__("memory.embeddings", fromlist=["CONCEPTS"]).CONCEPTS.items()}),
    }


def main() -> None:
    doc = "".join((SRC / p).read_text(encoding="utf-8") for p in PARTS)
    for placeholder, value in project_data().items():
        doc = doc.replace(placeholder, value)
    doc = doc.replace("__TITLE__", html.escape(TITLE))
    doc = fill_walkers(doc)
    OUT.write_text(doc, encoding="utf-8")
    print(f"wrote {OUT.relative_to(ROOT)}  ({len(doc) // 1024} KB)")


if __name__ == "__main__":
    sys.exit(main())
