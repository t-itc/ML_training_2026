"""Central configuration: reads .env once and builds the chat model.

Every other module calls `get_settings()` / `get_llm()` so there is exactly one
place to switch between Ollama (default, free, local), OpenAI and the offline mock.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent
load_dotenv(PROJECT_ROOT / ".env")


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    llm_provider: str = os.getenv("LLM_PROVIDER", "ollama").lower()      # ollama | openai | mock
    chat_model: str = os.getenv("CHAT_MODEL", "llama3.2:3b")             # Ollama model name
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    temperature: float = float(os.getenv("TEMPERATURE", "0"))
    storage_dir: Path = PROJECT_ROOT / os.getenv("STORAGE_DIR", "storage")
    default_user_id: str = os.getenv("USER_ID", "mahesh")
    weather_mode: str = os.getenv("WEATHER_MODE", "offline").lower()    # offline | live (Open-Meteo)
    memory_top_k: int = int(os.getenv("MEMORY_TOP_K", "5"))
    auto_reflect: bool = _bool("AUTO_REFLECT", True)
    reflection_mode: str = os.getenv("REFLECTION_MODE", "rules").lower()  # rules | llm (structured-output extractor)
    verbose_tools: bool = _bool("VERBOSE_TOOLS", True)

    @property
    def checkpoint_db(self) -> Path:
        return self.storage_dir / "checkpoints.db"

    @property
    def memory_db(self) -> Path:
        return self.storage_dir / "memory.db"

    @property
    def employee_db(self) -> Path:
        return self.storage_dir / "acme.db"


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.storage_dir.mkdir(parents=True, exist_ok=True)
    return s


def get_llm(provider: str | None = None):
    """Return a LangChain chat model that supports tool calling."""
    s = get_settings()
    provider = (provider or s.llm_provider).lower()

    if provider == "ollama":
        from langchain_ollama import ChatOllama

        return ChatOllama(model=s.chat_model, base_url=s.ollama_base_url, temperature=s.temperature)

    if provider == "openai":
        from langchain_openai import ChatOpenAI  # needs OPENAI_API_KEY in .env

        return ChatOpenAI(model=s.openai_model, temperature=s.temperature)

    if provider == "mock":
        from agents.mock_llm import ScriptedToolModel

        return ScriptedToolModel()

    raise ValueError(f"Unknown LLM_PROVIDER={provider!r}; use ollama, openai or mock")


def describe_llm() -> str:
    s = get_settings()
    return {
        "ollama": f"Ollama · {s.chat_model} @ {s.ollama_base_url}",
        "openai": f"OpenAI · {s.openai_model}",
        "mock": "Mock · scripted offline model (no LLM)",
    }.get(s.llm_provider, s.llm_provider)
