"""Unit tests. They run WITHOUT downloading any model: a tiny fake embedding
model stands in for sentence-transformers. Set RUN_MODEL_TESTS=1 to also run
the integration test with the real MiniLM model.

    python -m pytest -q
"""
import json
import math
import os
import re
import zlib
from pathlib import Path

import numpy as np
import pytest

from app import chunking as ch
from app.dense_retriever import DenseRetriever, matches_filters
from app.evaluation import ndcg_at_k, precision_at_k, recall_at_k, reciprocal_rank, evaluate
from app.hybrid_retriever import HybridRetriever, multi_query_search, reciprocal_rank_fusion
from app.mmr import mmr
from app.sparse_retriever import BM25Retriever, TfidfRetriever, tokenize

ROOT = Path(__file__).resolve().parents[1]
DOCS = json.loads((ROOT / "data" / "company_documents.json").read_text(encoding="utf-8"))
QUESTIONS = json.loads((ROOT / "data" / "test_questions.json").read_text(encoding="utf-8"))
HANDBOOK = (ROOT / "data" / "employee_handbook.md").read_text(encoding="utf-8")


class FakeModel:
    """Bag-of-words hashed into 64 dims, L2-normalised. Not semantic - only for testing plumbing."""

    def _enc(self, texts):
        out = np.zeros((len(texts), 64), dtype=np.float32)
        for i, t in enumerate(texts):
            for w in re.findall(r"[a-z0-9]+", t.lower()):
                out[i, zlib.crc32(w.encode()) % 64] += 1
        n = np.linalg.norm(out, axis=1, keepdims=True)
        n[n == 0] = 1
        return out / n

    encode_documents = _enc
    encode_queries = _enc


# ----------------------------------------------------------------- data
def test_dataset_ids_unique_and_questions_reference_existing_docs():
    ids = [d["id"] for d in DOCS]
    assert len(ids) == len(set(ids))
    for q in QUESTIONS:
        assert set(q["relevant_ids"]) <= set(ids), q["id"]


# ----------------------------------------------------------------- chunking
def test_fixed_size_overlap_is_exact():
    text = "abcdefghijklmnopqrstuvwxyz"
    chunks = ch.fixed_size_chunks(text, chunk_size=10, overlap=3)
    assert all(len(c.text) <= 10 for c in chunks)
    for a, b in zip(chunks, chunks[1:]):
        assert a.text[-3:] == b.text[:3]                 # 3 shared characters
    assert chunks[-1].end == len(text)


def test_fixed_size_rejects_bad_overlap():
    with pytest.raises(ValueError):
        ch.fixed_size_chunks("hello", chunk_size=5, overlap=5)


def test_fixed_size_small_and_empty_input():
    assert len(ch.fixed_size_chunks("hi", 100)) == 1
    assert ch.fixed_size_chunks("", 100) == []


def test_sentence_chunks_keep_sentences_whole():
    text = "One. Two two. " + "Long sentence " * 20 + "end."
    chunks = ch.sentence_chunks(text, max_chars=20)
    for c in chunks:
        assert c.text.endswith(".")
    assert any(len(c.text) > 20 for c in chunks)          # oversized single sentence kept whole


def test_recursive_chunks_respect_size_and_keep_content():
    chunks = ch.recursive_chunks(HANDBOOK, chunk_size=200)
    assert all(len(c.text) <= 200 for c in chunks)
    joined = "".join(c.text for c in chunks)
    assert re.sub(r"\s", "", joined) == re.sub(r"\s", "", HANDBOOK)


def test_markdown_sections_have_heading_path():
    chunks = ch.markdown_section_chunks(HANDBOOK)
    sections = [c.metadata["section"] for c in chunks]
    assert "Employee Handbook > 2. Leave > 2.2 Sick Leave" in sections


def test_parent_child_links():
    parents, children = ch.parent_child_chunks(HANDBOOK, child_max_chars=120)
    by_id = {p.id: p for p in parents}
    assert len(children) > len(parents)
    for c in children:
        assert c.text in by_id[c.metadata["parent_id"]].text


def test_semantic_chunks_split_on_topic_change():
    text = ("Annual leave is 18 days. Leave days carry over. Leave requests need approval. "
            "Passwords change every 90 days. Passwords need 12 characters.")
    chunks = ch.semantic_chunks(text, FakeModel().encode_documents, breakpoint_percentile=70)
    assert len(chunks) >= 2


# ----------------------------------------------------------------- sparse
def test_bm25_finds_exact_error_code():
    results = BM25Retriever(DOCS).search("What does error VPN-417 mean?", 3)
    assert results[0].id == "IT-004"


def test_bm25_misses_synonym_only_document():
    four = [d for d in DOCS if d["id"] in ("HR-001", "HR-002", "HR-003", "FIN-001")]
    ids = [r.id for r in BM25Retriever(four).search("What is the work-from-home policy?", 4)]
    assert "HR-001" in ids            # shares the token 'work'
    assert "HR-003" not in ids        # 'remote working' shares no exact token


def test_tokenizer():
    assert tokenize("Error VPN-417!") == ["error", "vpn", "417"]


def test_tfidf_returns_relevant_doc():
    assert TfidfRetriever(DOCS).search("expense claims deadline", 1)[0].id == "FIN-001"


def test_metadata_filter():
    assert matches_filters({"department": "HR"}, {"department": ["HR", "IT"]})
    results = BM25Retriever(DOCS).search("policy days", 10, filters={"department": "IT"})
    assert results and all(r.doc["department"] == "IT" for r in results)


# ----------------------------------------------------------------- dense / hybrid
def test_dense_retriever_with_filters():
    r = DenseRetriever(DOCS, FakeModel())
    res = r.search("expense claims", 3, filters={"department": "Finance"})
    assert res and all(x.doc["department"] == "Finance" for x in res)
    assert res[0].id == "FIN-001"


def test_rrf_worked_example():
    fused = dict(reciprocal_rank_fusion([["A", "B", "C"], ["B", "C"]], k=60))
    assert math.isclose(fused["B"], 1 / 62 + 1 / 61)
    assert math.isclose(fused["A"], 1 / 61)
    assert list(dict(reciprocal_rank_fusion([["A", "B", "C"], ["B", "C"]], k=60)))[0] == "B"


def test_hybrid_and_multi_query_run():
    dense = DenseRetriever(DOCS, FakeModel())
    hybrid = HybridRetriever(dense, BM25Retriever(DOCS))
    assert hybrid.search("expense claims deadline", 3)[0].id == "FIN-001"
    results, per_query = multi_query_search(dense, "gifts from suppliers", ["larger gifts declared to compliance"], top_k=3)
    assert len(per_query) == 2 and results[0].id == "LEG-001"


# ----------------------------------------------------------------- MMR
def test_mmr_prefers_diversity():
    q = np.array([1.0, 0.0])
    docs = np.array([[0.99, 0.14], [0.98, 0.2], [0.6, 0.8]], dtype=np.float32)
    docs = docs / np.linalg.norm(docs, axis=1, keepdims=True)
    assert mmr(q, docs, top_k=2, lambda_mult=1.0) == [0, 1]       # two near-duplicates
    assert mmr(q, docs, top_k=2, lambda_mult=0.3) == [0, 2]       # second pick is different


# ----------------------------------------------------------------- metrics
def test_metrics_known_values():
    retrieved, relevant = ["X", "A", "Y", "B"], {"A", "B"}
    assert precision_at_k(retrieved, relevant, 2) == 0.5
    assert recall_at_k(retrieved, relevant, 2) == 0.5
    assert reciprocal_rank(retrieved, relevant) == 0.5
    expected = (1 / math.log2(3) + 1 / math.log2(5)) / (1 + 1 / math.log2(3))
    assert math.isclose(ndcg_at_k(retrieved, relevant, 4), expected)


def test_evaluate_perfect_system():
    perfect = {q["question"]: q["relevant_ids"] for q in QUESTIONS}
    res = evaluate(lambda q, k: perfect[q][:k], QUESTIONS, k=3)
    assert res["summary"]["rr"] == 1.0 and res["summary"]["recall"] == 1.0


# ----------------------------------------------------------------- optional real model
@pytest.mark.skipif(os.getenv("RUN_MODEL_TESTS") != "1", reason="set RUN_MODEL_TESTS=1 to download and test MiniLM")
def test_real_model_vacation_question():
    from app.embeddings import EmbeddingModel
    r = DenseRetriever(DOCS, EmbeddingModel("minilm"))
    assert "HR-002" in [x.id for x in r.search("How many vacation days do I get each year?", 3)]
