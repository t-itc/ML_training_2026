"""Shared console helpers for the demo scripts."""
from __future__ import annotations

import sys

from config import describe_llm

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")  # Windows consoles: allow ×, →, emoji

LINE = "=" * 88


def banner(title: str) -> None:
    print(LINE)
    print(f"{title}   |   LLM: {describe_llm()}")
    print(LINE)


def show(q: str, answer: str, tools: list[str] | None = None, label: str = "") -> None:
    tag = f"[{label}] " if label else ""
    print(f"\n{tag}User : {q}")
    if tools is not None:
        print(f"{' ' * len(tag)}Tools: {', '.join(tools) if tools else '(none)'}")
    print(f"{' ' * len(tag)}Aria : {answer}")


def check(name: str, ok: bool) -> bool:
    print(f"   {'PASS' if ok else 'FAIL'}  {name}")
    return ok
