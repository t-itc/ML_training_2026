# Remote Work Policy

## Eligibility and limits
Employees may work remotely up to 3 days per week after completing probation. At least 2 days per week must be spent in the office.

## Anchor days
Tuesday and Thursday are mandatory office anchor days for all teams.

## Approval
The reporting manager approves the remote work schedule. Core collaboration hours are 10:30 to 16:00 IST.
