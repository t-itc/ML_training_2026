"""Hybrid retrieval with Reciprocal Rank Fusion (RRF) and multi-query retrieval."""
from __future__ import annotations

import os
from collections import defaultdict

from app.dense_retriever import Result


def reciprocal_rank_fusion(rankings: list[list[str]], k: int = 60) -> list[tuple[str, float]]:
    """RRF(d) = sum over rankings of 1 / (k + rank(d)), rank starting at 1.

    Uses only RANK positions, never raw scores, so it can merge rankers whose
    scores are on different scales (cosine 0-1 vs BM25 0-15+). k dampens the
    advantage of the very top positions; 60 is the value from the original paper.
    """
    fused: dict[str, float] = defaultdict(float)
    for ranking in rankings:
        for rank, doc_id in enumerate(ranking, start=1):
            fused[doc_id] += 1.0 / (k + rank)
    return sorted(fused.items(), key=lambda kv: (-kv[1], kv[0]))


class HybridRetriever:
    """Run dense and BM25 retrieval, then fuse their rankings with RRF."""

    def __init__(self, dense, sparse, candidates: int = 10, k: int = 60):
        self.dense, self.sparse = dense, sparse
        self.candidates, self.k = candidates, k
        self.by_id = {d["id"]: d for d in dense.docs}

    def search(self, query: str, top_k: int = 5, filters: dict | None = None) -> list[Result]:
        dense_ids = [r.id for r in self.dense.search(query, self.candidates, filters)]
        sparse_ids = [r.id for r in self.sparse.search(query, self.candidates, filters)]
        fused = reciprocal_rank_fusion([dense_ids, sparse_ids], k=self.k)
        return [Result(self.by_id[i], s, "hybrid-rrf") for i, s in fused[:top_k]]


# ---------------------------------------------------------------------------
# Multi-query retrieval
# ---------------------------------------------------------------------------
def generate_query_variants(question: str, n: int = 3, model: str | None = None) -> list[str]:
    """Ask a local Ollama LLM for n rephrasings of the question.
    Returns [] if Ollama is not available, so callers can fall back."""
    model = model or os.getenv("OLLAMA_MODEL", "mistral")
    try:
        import ollama
        prompt = (f"Rewrite the following question in {n} different ways using different words "
                  f"(synonyms, formal and informal wording). Return one question per line, no numbering.\n\n"
                  f"Question: {question}")
        reply = ollama.chat(model=model, messages=[{"role": "user", "content": prompt}],
                            options={"temperature": 0.3})
        lines = [l.strip(" -*0123456789.").strip() for l in reply.message.content.splitlines()]
        return [l for l in lines if l.endswith("?") or len(l.split()) > 3][:n]
    except Exception as exc:                       # no ollama package / server / model
        print(f"[multi-query] Ollama unavailable ({exc}); using the original question only.")
        return []


def multi_query_search(retriever, question: str, variants: list[str], top_k: int = 5,
                       per_query_k: int = 10, k: int = 60) -> tuple[list[Result], dict[str, list[str]]]:
    """Retrieve for the original question AND each variant, then fuse with RRF.
    Returns (fused results, per-query rankings) so the effect can be shown."""
    queries = [question] + [v for v in variants if v.strip() and v != question]
    per_query = {q: [r.id for r in retriever.search(q, per_query_k)] for q in queries}
    fused = reciprocal_rank_fusion(list(per_query.values()), k=k)
    by_id = {d["id"]: d for d in retriever.docs}
    return [Result(by_id[i], s, "multi-query") for i, s in fused[:top_k]], per_query
