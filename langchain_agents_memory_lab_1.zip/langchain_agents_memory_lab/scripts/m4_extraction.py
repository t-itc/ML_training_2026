"""Module 4.5 — rule-based vs LLM-based memory extraction, side by side.

    python -m scripts.m4_extraction                       # uses LLM_PROVIDER from .env (ollama by default)
    LLM_PROVIDER=mock python -m scripts.m4_extraction     # offline: the mock imitates the LLM path with rules

Rule-based : extract_candidates()  regular expressions, deterministic, free, misses paraphrases
LLM-based  : extract_with_llm()    llm.with_structured_output(Memories), understands paraphrases, costs a call
Both outputs then go through the SAME policy: evaluate().
Switch the reflection step between them with REFLECTION_MODE=rules|llm in .env.
"""
from config import get_settings
from memory.agentic_memory import evaluate, extract
from scripts._common import LINE, banner

SENTENCES = [
    "My name is Mahesh and I prefer explanations with Python examples.",   # both should catch this
    "Python is my go-to language and I mostly build LangChain agents.",    # paraphrase: rules miss it
    "Keep it brief please, I read your answers on my phone.",               # paraphrase of a preference
    "I've been doing data science at Acme for six years.",                  # paraphrase of a role
    "My password is Hunter2!",                                              # must be rejected by the policy
    "What's the weather in Pune?",                                          # nothing to remember
]


def show(label: str, cands: list[dict]) -> None:
    if not cands:
        print(f"   {label:<6} (nothing extracted)")
        return
    for c in cands:
        d = evaluate(c["content"], c["category"])
        tag = f"[{c['category']}/{c['key']}]"
        print(f"   {label:<6} {tag:<34} {c['content'][:52]:<52} -> {'STORE' if d.allowed else 'IGNORE'}")


def main() -> None:
    banner("Module 4.5 · Memory extraction: rules vs LLM (structured output)")
    if get_settings().llm_provider == "mock":
        print("NOTE: LLM_PROVIDER=mock — the 'LLM' column is simulated with the same rules, so both columns match.\n"
              "      Run with Ollama/OpenAI to see the LLM catch the paraphrases.")
    for s in SENTENCES:
        print("\n" + "-" * 88 + f"\n{s}")
        show("RULES", extract(s, mode="rules"))
        show("LLM", extract(s, mode="llm"))
    print("\n" + LINE + f"\nReflection currently uses REFLECTION_MODE={get_settings().reflection_mode!r}.")


if __name__ == "__main__":
    main()
