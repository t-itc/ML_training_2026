"""Tool registry — import tool groups from here."""
from tools.calculator import calculator
from tools.database import query_employee
from tools.datetime_tool import get_current_datetime
from tools.memory_tools import delete_memory, get_user_profile, save_memory, search_memory
from tools.search import search_knowledge
from tools.weather import get_weather

BASIC_TOOLS = [calculator, get_current_datetime, get_weather, search_knowledge, query_employee]
MEMORY_TOOLS = [save_memory, search_memory, get_user_profile, delete_memory]
ALL_TOOLS = BASIC_TOOLS + MEMORY_TOOLS

__all__ = ["BASIC_TOOLS", "MEMORY_TOOLS", "ALL_TOOLS", "calculator", "get_current_datetime", "get_weather",
           "search_knowledge", "query_employee", "save_memory", "search_memory", "get_user_profile", "delete_memory"]
