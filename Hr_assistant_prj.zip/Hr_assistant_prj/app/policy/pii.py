"""PII and secret detection, plus redaction according to policy.yaml (pii.types.*.action).

Destinations:
  * LLM prompt   -> per-type action: allow | redact | block   (apply_pii_policy)
  * logs/traces  -> ALWAYS masked: every PII type and every secret (mask_text / mask_any)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from app.config import Policy, get_policy

# Order matters: longer / more specific numbers first; overlapping matches are dropped.
PII_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("EMAIL", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    ("PAN", re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")),
    ("CARD", re.compile(r"\b\d(?:[ -]?\d){12,18}\b")),
    ("BANK_ACCOUNT", re.compile(r"(?:account|a/c|acct)\.?\s*(?:number|no\.?|#)?\s*(?:is|:)?\s*(\d{9,18})\b", re.I)),
    ("AADHAAR", re.compile(r"\b[2-9][0-9]{3}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b")),
    ("PHONE", re.compile(r"(?<!\d)(?:\+91[\s-]?|0)?[6-9]\d{4}[\s-]?\d{5}(?!\d)")),
    ("EMPLOYEE_ID", re.compile(r"\bE\d{4}\b")),
]

SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("API_KEY", re.compile(r"\b(?:sk|pk|rk)-[A-Za-z0-9_-]{16,}\b")),
    ("AWS_KEY", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("PRIVATE_KEY", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")),
    ("PASSWORD", re.compile(r"(?i)\b(?:password|passwd|pwd|passcode)\s*(?:is|=|:)\s*(\S{4,})")),
]

# Public company addresses are not personal data.
ALLOWLIST = re.compile(r"@acme\.example$", re.I)


def _luhn_ok(number: str) -> bool:
    digits = [int(d) for d in re.sub(r"\D", "", number)]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2:
            d = d * 2 - 9 if d * 2 > 9 else d * 2
        total += d
    return total % 10 == 0


@dataclass
class Finding:
    type: str
    start: int
    end: int
    value: str = field(repr=False)          # never logged; repr hides it

    def public(self) -> dict:
        return {"type": self.type}


def _scan(text: str, patterns) -> list[Finding]:
    found: list[Finding] = []
    taken: list[tuple[int, int]] = []
    for ptype, pattern in patterns:
        for m in pattern.finditer(text):
            # Use the captured group if the pattern has one (e.g. the number after "account")
            g = next((i for i in range(1, (m.lastindex or 0) + 1) if m.group(i)), 0)
            s, e = m.span(g)
            value = m.group(g)
            if ptype == "CARD" and not _luhn_ok(value):
                continue
            if ptype == "EMAIL" and ALLOWLIST.search(value):
                continue
            if any(s < te and e > ts for ts, te in taken):
                continue
            taken.append((s, e))
            found.append(Finding(ptype, s, e, value))
    return sorted(found, key=lambda f: f.start)


def detect_pii(text: str) -> list[Finding]:
    return _scan(text, PII_PATTERNS)


def detect_secrets(text: str) -> list[Finding]:
    return _scan(text, SECRET_PATTERNS)


def _replace(text: str, findings: list[Finding]) -> str:
    out = text
    for f in sorted(findings, key=lambda f: f.start, reverse=True):
        out = out[: f.start] + f"<{f.type}>" + out[f.end:]
    return out


@dataclass
class PIIDecision:
    action: str                       # allow | redact | block
    text: str                         # text to forward to the LLM (redacted where required)
    types: list[str]
    blocked_types: list[str]
    reason: str = ""


def apply_pii_policy(text: str, policy: Policy | None = None) -> PIIDecision:
    """Per-type action from policy.yaml. Block wins over redact; allow keeps the value for the LLM."""
    policy = policy or get_policy()
    rules = policy["pii"]["types"]
    findings = detect_pii(text)
    blocked = [f for f in findings if rules.get(f.type, {}).get("action", "redact") == "block"]
    if blocked:
        reasons = sorted({rules[f.type].get("reason", f"{f.type} is not accepted") for f in blocked})
        return PIIDecision("block", _replace(text, findings), sorted({f.type for f in findings}),
                           sorted({f.type for f in blocked}), " ".join(reasons))
    to_redact = [f for f in findings if rules.get(f.type, {}).get("action", "redact") == "redact"]
    action = "redact" if to_redact else "allow"
    return PIIDecision(action, _replace(text, to_redact), sorted({f.type for f in findings}), [])


def mask_text(text: str) -> str:
    """For logs and traces: mask every PII type and every secret, regardless of policy action."""
    return _replace(text, _scan(text, SECRET_PATTERNS + PII_PATTERNS))


def mask_any(data: Any) -> Any:
    if isinstance(data, str):
        return mask_text(data)
    if isinstance(data, dict):
        return {k: mask_any(v) for k, v in data.items()}
    if isinstance(data, (list, tuple)):
        return [mask_any(v) for v in data]
    return data
