"""Module 6 — debugging and observability: stream each step, log tools, tokens, latency, failures.

    python -m scripts.m6_inspect
    python -m scripts.m6_inspect -q "What's the weather in Atlantis?"
"""
import argparse

from agents.assistant_agent import build_agent
from agents.observability import AgentTracer, get_callbacks
from memory.agentic_memory import build_memory_context
from memory.long_term import UserContext, get_store, put_memory, search_memories
from scripts._common import LINE, banner

USER = "mahesh"


def stream_steps(agent, question: str, thread: str) -> None:
    """stream_mode='updates' yields one chunk per graph node: model -> tools -> model ..."""
    print(f"\nQ: {question}")
    config = {"configurable": {"thread_id": thread}}
    for chunk in agent.stream({"messages": [{"role": "user", "content": question}]}, config=config,
                              context=UserContext(USER), stream_mode="updates"):
        for node, update in chunk.items():
            for m in (update or {}).get("messages", []):
                if m.type == "ai" and m.tool_calls:
                    for tc in m.tool_calls:
                        print(f"   {node:<24} ACTION      {tc['name']}({tc['args']})")
                elif m.type == "tool":
                    print(f"   {node:<24} OBSERVATION {str(m.content)[:70]}")
                elif m.type == "ai":
                    print(f"   {node:<24} ANSWER      {str(m.content)[:70]}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-q", "--question")
    args = ap.parse_args()
    banner("Module 6 · Inspecting agent execution")
    store = get_store("memory")
    put_memory(store, USER, "explanation_style", "User prefers explanations with Python examples", "preference")
    put_memory(store, USER, "role", "User is a Data Scientist", "profile")
    agent = build_agent("agentic", store=store)

    print("\n1) Step-by-step execution (stream_mode='updates')")
    stream_steps(agent, args.question or "What is 250 multiplied by 12, and what is today's date?", "dbg-1")

    print("\n2) Tool failure handling — the error goes back to the model as an observation")
    stream_steps(agent, "What's the weather in Atlantis?", "dbg-2")

    print("\n3) Callback tracer: tool logs, tokens and latency")
    tracer = AgentTracer()
    cbs = [tracer] + [c for c in get_callbacks(echo=False) if not isinstance(c, AgentTracer)]
    agent.invoke({"messages": [{"role": "user", "content": "How many leave days can I carry forward?"}]},
                 config={"configurable": {"thread_id": "dbg-3"}, "callbacks": cbs}, context=UserContext(USER))
    print("   summary:", tracer.summary())

    print("\n4) Debugging memory retrieval — what would be injected for a query?")
    q = "Explain RAG architecture"
    print(f"   query: {q!r}")
    print("   top matches:", [i.key for i in search_memories(store, USER, q)])
    print("   " + build_memory_context(store, USER, q).replace("\n", "\n   "))
    print("\n" + LINE + "\nTip: set LANGFUSE_* (or LANGSMITH_TRACING=true) in .env to see the same tree in a UI.")


if __name__ == "__main__":
    main()
