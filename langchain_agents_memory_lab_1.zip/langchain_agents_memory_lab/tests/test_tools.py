from tools import ALL_TOOLS, calculator, get_current_datetime, get_weather, query_employee, search_knowledge
from tools.calculator import safe_eval


def test_calculator_exact():
    assert calculator.invoke({"expression": "250 * 12"}) == "250 * 12 = 3,000"
    assert safe_eval("sqrt(144) + 2 ** 3") == 20
    assert safe_eval("(45 + 5) / 2") == 25


def test_calculator_errors_are_returned_not_raised():
    assert calculator.invoke({"expression": "10 / 0"}).startswith("Error: division by zero")
    assert calculator.invoke({"expression": "__import__('os').system('dir')"}).startswith("Error")


def test_datetime_tool():
    assert "Today is" in get_current_datetime.invoke({})
    assert get_current_datetime.invoke({"timezone": "Mars/Base"}).startswith("Error")


def test_weather_offline_and_unknown_city():
    assert "Pune" in get_weather.invoke({"city": "pune"})
    assert get_weather.invoke({"city": "Atlantis"}).startswith("Error")


def test_search_finds_leave_policy():
    assert "[HR-01]" in search_knowledge.invoke({"query": "leave carry forward"})


def test_database_lookup_is_parameterised():
    assert "Rahul Mehta" in query_employee.invoke({"name_or_id": "E101"})
    assert query_employee.invoke({"name_or_id": "x' OR '1'='1"}).startswith("No employee")


def test_runtime_is_hidden_from_llm_schema():
    for t in ALL_TOOLS:
        props = t.tool_call_schema.model_json_schema().get("properties", {})
        assert "runtime" not in props, t.name
        assert t.description, t.name
