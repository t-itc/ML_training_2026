# Salary Bands 2026 (Confidential - HR only)

## Engineering bands
Band E5 annual fixed pay ranges from INR 32,00,000 to INR 41,00,000. Band E6 ranges from INR 41,00,000 to INR 55,00,000. Band E7 ranges from INR 55,00,000 to INR 72,00,000.

## Review cycle
Band movements are approved by the compensation committee in April each year.
