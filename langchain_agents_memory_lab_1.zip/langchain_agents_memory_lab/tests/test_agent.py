from langchain.tools import tool

from agents.assistant_agent import ask, build_agent, tools_called
from memory.long_term import list_memories, recent_episodes


def test_basic_agent_has_no_tools():
    answer, result = ask(build_agent("basic"), "What is 250 multiplied by 12?")
    assert tools_called(result) == []


def test_multiple_tools_in_one_turn():
    answer, result = ask(build_agent("tools"), "What is 250 multiplied by 12, and what is today's date?")
    assert set(tools_called(result)) == {"calculator", "get_current_datetime"}
    assert "3,000" in answer and "Today is" in answer


def test_tool_exception_is_returned_to_model_not_raised():
    @tool
    def flaky(city: str) -> str:
        """Get the weather for a city."""
        raise ConnectionError("API down")

    flaky.name = "get_weather"
    answer, result = ask(build_agent("tools", tools=[flaky]), "What's the weather in Pune?")
    tool_msgs = [m for m in result["messages"] if m.type == "tool"]
    assert "ConnectionError" in tool_msgs[0].content and tool_msgs[0].status == "error"
    assert "couldn't complete" in answer


def test_short_term_memory_is_per_thread():
    agent = build_agent("short_term")
    ask(agent, "My name is Mahesh.", thread_id="a")
    assert "Mahesh" in ask(agent, "What is my name?", thread_id="a")[0]
    assert "don't know" in ask(agent, "What is my name?", thread_id="b")[0]


def test_long_term_memory_across_threads_and_agents(store):
    ask(build_agent("long_term", store=store), "I primarily work with Python and LangChain.", thread_id="s1", user_id="mahesh")
    fresh_agent = build_agent("long_term", store=store)          # new checkpointer = new session
    answer, result = ask(fresh_agent, "Suggest a project for me.", thread_id="s2", user_id="mahesh")
    assert "search_memory" in tools_called(result) and "AI Agent" in answer
    other, _ = ask(fresh_agent, "Suggest a project for me.", thread_id="s3", user_id="priya")
    assert "don't know your background" in other


def test_agentic_memory_learns_and_ignores_secrets(store):
    agent = build_agent("agentic", store=store)
    ask(agent, "I prefer explanations with Python examples.", thread_id="i1", user_id="mahesh")
    answer, result = ask(agent, "My password is hunter2", thread_id="i1", user_id="mahesh")
    assert "save_memory" not in tools_called(result)
    assert all("hunter2" not in i.value["content"] for i in list_memories(store, "mahesh"))
    assert all("hunter2" not in e.value["question"] for e in recent_episodes(store, "mahesh", 10))

    answer, result = ask(agent, "Explain RAG architecture", thread_id="i2", user_id="mahesh")
    assert tools_called(result) == [] and "```python" in answer          # retrieved via injection, no tool call
    ask(agent, "That was too long.", thread_id="i2", user_id="mahesh")
    answer, _ = ask(agent, "Explain RAG architecture", thread_id="i3", user_id="mahesh")
    assert answer.startswith("In short")


def test_reflection_saves_missed_facts(store):
    """Even with no memory tools, the after-agent reflection step stores durable facts."""
    from tools import BASIC_TOOLS

    agent = build_agent("agentic", store=store, tools=BASIC_TOOLS)
    ask(agent, "I am a Data Scientist.", thread_id="r1", user_id="u9")
    mem = list_memories(store, "u9")
    assert mem and mem[0].value["source"] == "reflection"


def test_scenarios_script_all_pass(capsys):
    from scripts import m5_scenarios

    m5_scenarios.main()
    assert "7/7 scenarios passed" in capsys.readouterr().out


def test_user_switch_never_shares_thread_history():
    """main.py scopes thread ids per user: same thread name, different users -> separate histories."""
    from memory.short_term import scoped_thread_id

    agent = build_agent("short_term")
    ask(agent, "My name is Mahesh.", thread_id=scoped_thread_id("mahesh", "default"))
    answer, _ = ask(agent, "What is my name?", thread_id=scoped_thread_id("priya", "default"))
    assert "don't know" in answer


def test_memory_update_and_recall(store):
    agent = build_agent("agentic", store=store)
    ask(agent, "I prefer Python examples.", thread_id="c1", user_id="u1")
    answer, _ = ask(agent, "Actually, I prefer Java examples.", thread_id="c1", user_id="u1")
    assert "was: User prefers Python examples" in answer
    recalled, _ = ask(agent, "What do you remember about me?", thread_id="c2", user_id="u1")
    assert "Java" in recalled and "Python" not in recalled


def test_feedback_too_technical_changes_next_answer(store):
    agent = build_agent("agentic", store=store)
    ask(agent, "Your previous answer was too technical.", thread_id="d1", user_id="u2")
    answer, _ = ask(agent, "Explain RAG architecture", thread_id="d2", user_id="u2")
    assert answer.startswith("In simple terms")
