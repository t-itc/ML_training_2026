"""STEP 2 · First agent with create_agent (still no tools)

    you ──► [ create_agent: model node ] ──► answer
             (a LangGraph graph with a message state)

Run:  python -m steps.step2_first_agent
NEW in this step: create_agent, system_prompt, the {"messages": [...]} state.
"""
from langchain.agents import create_agent

from config import get_llm

agent = create_agent(
    model=get_llm(),
    tools=[],                                     # no tools yet
    system_prompt="You are Aria, a friendly personal assistant. Answer in at most 3 sentences.",
)

result = agent.invoke({"messages": [{"role": "user", "content": "Hi! Who are you?"}]})

print("Answer:", result["messages"][-1].content)  # the LAST message is the answer
print("\nAll messages in the state:")
for m in result["messages"]:
    print(f"   {m.type:>6}: {str(m.content)[:70]!r}")
