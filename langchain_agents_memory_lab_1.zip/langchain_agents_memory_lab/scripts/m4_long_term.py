"""Module 4.4 — long-term memory with a persistent Store (storage/memory.db).

    python -m scripts.m4_long_term                 # session 1 + session 2 (two separate agents/connections)
    python -m scripts.m4_long_term --session 1     # only save   (run, exit Python ...)
    python -m scripts.m4_long_term --session 2     # ... then a NEW process reads what session 1 saved
"""
import argparse

from agents.assistant_agent import ask, build_agent, tools_called
from memory.long_term import clear_user, format_memories, get_store, list_memories
from scripts._common import banner, show

USER = "mahesh"


def session_1() -> None:
    store = get_store("sqlite")
    clear_user(store, USER)
    agent = build_agent("long_term", store=store)
    print("\n--- Session 1 (thread: s1) ---")
    for q in ["I am a Data Scientist.", "I primarily work with Python and LangChain."]:
        answer, result = ask(agent, q, thread_id="s1", user_id=USER)
        show(q, answer, tools_called(result), label="s1")
    print(f"\nStore namespace ({USER!r}, 'memories') now contains:\n{format_memories(list_memories(store, USER))}")


def session_2() -> None:
    store = get_store("sqlite")             # a fresh connection to the same file = "after a restart"
    agent = build_agent("long_term", store=store)   # and a fresh agent with an EMPTY checkpointer
    print("\n--- Session 2 (new thread: s2, nothing in short-term memory) ---")
    for q in ["Suggest a project for me."]:
        answer, result = ask(agent, q, thread_id="s2", user_id=USER)
        show(q, answer, tools_called(result), label="s2")
    print("\n--- Another user (priya) in a new thread: no access to Mahesh's memories ---")
    answer, result = ask(agent, "Suggest a project for me.", thread_id="s3", user_id="priya")
    show("Suggest a project for me.", answer, tools_called(result), label="s3")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", type=int, choices=[1, 2])
    args = ap.parse_args()
    banner("Module 4.4 · Long-term memory (LangGraph Store, SQLite)")
    if args.session in (None, 1):
        session_1()
    if args.session in (None, 2):
        session_2()


if __name__ == "__main__":
    main()
