"""Input policy: deterministic signals -> allow | review | block.

All signals are cheap, explainable and reproducible, so the same message always gets the
same decision under the same policy version. Every signal is recorded on the trace.
Precedence: block > review > allow.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.config import Policy, get_policy
from app.policy.pii import apply_pii_policy, detect_secrets

# (rule id, pattern, weight). Score = max weight + 0.1 per extra match, capped at 1.0.
INJECTION_RULES: list[tuple[str, re.Pattern, float]] = [
    ("override", re.compile(r"\b(ignore|disregard|forget)\b.{0,25}\b(previous|prior|above|earlier|all|your)\b.{0,20}"
                            r"\b(instructions?|prompts?|rules|directions)\b", re.I | re.S), 0.9),
    ("extract_prompt", re.compile(r"\b(reveal|print|show|repeat|output|tell me|leak)\b.{0,40}"
                                  r"\b(system prompt|hidden prompt|initial prompt|your instructions|your rules)\b", re.I | re.S), 0.85),
    ("jailbreak", re.compile(r"\b(do anything now|developer mode|admin mode|jailbreak|jailbroken)\b|\bDAN\b"), 0.85),
    ("role_change", re.compile(r"\b(you are now|from now on you are|act as|pretend to be)\b.{0,60}"
                               r"\b(unrestricted|unfiltered|admin|no (rules|restrictions|limits))\b", re.I | re.S), 0.8),
    ("bypass", re.compile(r"\b(override|bypass|disable|turn off)\b.{0,30}\b(rules|guidelines|guardrails|safety|filters?|policy)\b", re.I | re.S), 0.75),
    ("fake_tags", re.compile(r"</?(system|assistant|document|context)>|\[/?INST\]|^\s*#+\s*system\b", re.I | re.M), 0.6),
    ("tool_coercion", re.compile(r"\b(call|invoke|execute|run)\b.{0,20}\b(the )?(tool|function)\b", re.I), 0.6),
    ("obfuscation", re.compile(r"\b(base64|rot13|hex)\b.{0,30}\b(decode|decoded|encoded)\b", re.I), 0.4),
    ("roleplay_hint", re.compile(r"\b(pretend|role-?play|hypothetically)\b", re.I), 0.25),
]


def injection_score(text: str) -> tuple[float, list[str]]:
    hits = [(rid, w) for rid, p, w in INJECTION_RULES if p.search(text)]
    if not hits:
        return 0.0, []
    return round(min(1.0, max(w for _, w in hits) + 0.1 * (len(hits) - 1)), 2), [rid for rid, _ in hits]


def _keyword_hit(text: str, words: list[str]) -> str | None:
    low = text.lower()
    return next((w for w in words if re.search(rf"\b{re.escape(w)}", low)), None)


@dataclass
class InputDecision:
    decision: str                          # allow | review | block
    reason_code: str                       # machine-readable reason (first deciding signal)
    user_message: str                      # safe text for the LLM (PII handled per policy)
    signals: dict = field(default_factory=dict)
    flags: list[str] = field(default_factory=list)


def evaluate_input(message: str, policy: Policy | None = None) -> InputDecision:
    policy = policy or get_policy()
    p_in = policy["input"]
    signals: dict = {"chars": len(message)}
    flags: list[str] = []

    # 1. Secrets -> block (and never forwarded or stored)
    secrets = detect_secrets(message)
    signals["secret_types"] = sorted({s.type for s in secrets})
    if secrets and p_in["secrets"]["action"] == "block":
        return InputDecision("block", "secret_in_message", "", signals, flags)

    # 2. PII per documented policy
    pii = apply_pii_policy(message, policy)
    signals["pii_types"] = pii.types
    signals["pii_action"] = pii.action
    if pii.action == "block":
        signals["pii_blocked_types"] = pii.blocked_types
        return InputDecision("block", "pii_not_accepted", "", signals, flags)
    text = pii.text
    if pii.action == "redact":
        flags.append("pii_redacted")

    # 3. Prompt injection (scored on the redacted text)
    score, rules = injection_score(text)
    signals["injection_score"], signals["injection_rules"] = score, rules
    if score >= p_in["injection"]["block_score"]:
        return InputDecision("block", "prompt_injection", "", signals, flags)
    if score >= p_in["injection"]["review_score"]:
        flags.append("injection_suspected")

    # 4. Sensitive topics -> human review route (no automated answer)
    for category, words in p_in["sensitive_topics"]["categories"].items():
        hit = _keyword_hit(text, words)
        if hit:
            signals["sensitive_category"] = category
            return InputDecision(p_in["sensitive_topics"]["action"], f"sensitive_{category}", text, signals, flags)

    # 5. Topic scope
    kw = _keyword_hit(text, p_in["off_topic"]["allow_keywords"])
    signals["topic_keyword"] = kw
    if kw is None and p_in["off_topic"]["action"] == "block":
        return InputDecision("block", "off_topic", "", signals, flags)

    return InputDecision("allow", "ok", text, signals, flags)
