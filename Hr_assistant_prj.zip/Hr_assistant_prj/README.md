# End-to-end project: AcmeHR Policy Assistant (guarded, observable)

An internal HR policy assistant built to the course project brief: FastAPI, deterministic input policy with a
human-review route, documented PII policy, ChromaDB retrieval with server-side authorization, an untrusted-data
prompt, strict output validation, groundedness-based abstention, Langfuse traces and scores with policy/model
versions, a regression set with a release gate, and human approval for high-impact actions.

```
POST /v1/chat ─► size limit + schema ─► auth (roles from identity store)
                 │
                 ├─ input policy (secrets · PII policy · injection score · sensitive topics · scope)
                 │     ├─ block ─────────────────────────────────────────────► refusal
                 │     └─ review ────────────────────────────────────────────► HR review queue
                 ├─ tool intent (deterministic, USER text only)
                 │     ├─ low impact ─► run (own data) ──────────────────────► tool_result
                 │     └─ high impact ─► approval queue (hr_admin, no self-approval) ► pending_approval
                 └─ retrieval: Chroma pre-filter on ACL + post-filter vs catalog.json
                       └─ none ──────────────────────────────────────────────► abstain (no LLM)
                       └─ prompt (sanitised, random boundary, injected chunks quarantined)
                             └─ LLM (JSON) ─► output schema + policy ─ invalid / tool_call ─► fallback
                                                 └─ groundedness (judge + number check) ─ low ─► abstain
                                                                                        └─ ok ─► answer + citations
Every request ─► one Langfuse trace (versions + scores) OR a masked fallback record with the same request_id
```

## 1. Requirements → implementation

| # | Requirement | Where |
|---|---|---|
| 1 | FastAPI request schema and input size limit | `app/schemas.py`, `app/main.py` (`body_size_limit`, 413/422) |
| 2 | Input policy with deterministic signals and a review route | `app/policy/input_policy.py`, `policy.yaml › input` |
| 3 | PII detection/redaction per documented policy | `app/policy/pii.py`, `policy.yaml › pii`, [docs/POLICY.md](docs/POLICY.md) |
| 4 | Retrieval with server-side user/document authorization | `app/retrieval/retriever.py`, `data/documents/catalog.json` |
| 5 | Prompt that treats retrieved text as untrusted data | `app/prompting.py` |
| 6 | Output schema and policy validation | `app/schemas.py › LLMOutput`, `app/policy/output_policy.py` |
| 7 | Groundedness evaluation and abstention | `app/policy/output_policy.py`, `app/pipeline.py` |
| 8 | Langfuse traces and scores with policy/model versions | `app/telemetry.py`, `app/pipeline.py`, [docs/TELEMETRY.md](docs/TELEMETRY.md) |
| 9 | Regression dataset and test report | `eval/regression_set.jsonl` (39 cases), `eval/run_regression.py`, `scripts/test_report.py` |
| 10 | Safe fallback and human approval for high-impact actions | `app/tools/registry.py`, `app/tools/approvals.py`, `/v1/approvals` |

## 2. Project structure

```text
hr_assistant/
├── app/
│   ├── main.py                 FastAPI: /v1/chat, /v1/approvals, /healthz; size limit; bearer auth
│   ├── config.py               Settings (.env) + versioned policy loader (version + sha256)
│   ├── schemas.py              ChatRequest / ChatResponse / LLMOutput (strict, extra=forbid)
│   ├── pipeline.py             Orchestration; one trace per request; scores
│   ├── prompting.py            Untrusted-data prompt, sanitising, quarantine, canary   (PROMPT_VERSION)
│   ├── llm.py                  OllamaLLM + MockLLM (deterministic WORST-CASE model: obeys injected text)
│   ├── telemetry.py            Langfuse client with masking + explicit fallback path
│   ├── policy/
│   │   ├── policy.yaml         ★ the guardrail policy (single source of truth, versioned)
│   │   ├── input_policy.py     deterministic signals → allow | review | block
│   │   ├── pii.py              PII + secrets detection, per-type policy, masking
│   │   └── output_policy.py    schema + policy validation, groundedness
│   ├── retrieval/
│   │   ├── embeddings.py       MiniLM (real) | hashing (offline tests)
│   │   ├── store.py            catalog (ACL), chunking, Chroma ingestion with ACL metadata
│   │   └── retriever.py        pre-filter + post-filter authorization, thresholds
│   └── tools/
│       ├── registry.py         tools, impact levels, deterministic intent router
│       └── approvals.py        SQLite approval/review queue
├── data/
│   ├── documents/              7 policies incl. restricted, confidential and a POISONED wiki page + catalog.json
│   ├── users.json              demo identities (ravi=employee, priya=manager, anita=hr_admin)
│   └── leave_balances.json
├── eval/
│   ├── regression_set.jsonl    39 labelled cases, 21 critical
│   ├── run_regression.py       deterministic / --live / --langfuse experiment
│   └── baseline.json           release thresholds
├── scripts/  ingest.py · release_gate.py · test_report.py
├── tests/    test_acceptance.py (brief's 6 acceptance tests) · test_api.py · test_policies.py
├── reports/  TEST_REPORT.md · regression_report.md · regression_results.json
├── docs/     POLICY.md · TELEMETRY.md
└── langfuse_server/  docker-compose.yml + .env.example (self-hosted Langfuse, keys pre-created)
```

## 3. Setup

```bash
cd hr_assistant
python -m venv venv
venv\Scripts\activate                 # Windows
source venv/bin/activate              # macOS / Linux
pip install torch --index-url https://download.pytorch.org/whl/cpu    # optional: small CPU build for MiniLM
pip install -r requirements.txt
copy .env.example .env                # Windows   (cp on macOS/Linux)

# Langfuse (same stack as the guardrails lab)
cd langfuse_server && copy .env.example .env && docker compose up -d && cd ..
# Ollama
ollama pull llama3.2:3b

python -m scripts.ingest --reset      # index documents with ACL metadata
uvicorn app.main:app --reload         # http://localhost:8000/docs
```

No Ollama, Docker or internet? Set `LLM_PROVIDER=mock`, `EMBEDDER=hashing` and leave the Langfuse keys empty:
everything runs offline and every request is recorded in `logs/telemetry_fallback.jsonl`.

## 4. Try it

```bash
# employee: grounded answer with citation
curl -s localhost:8000/v1/chat -H "Authorization: Bearer tok-emp-ravi" -H "Content-Type: application/json" \
     -d '{"message":"How many leave days can I carry forward?"}'

# employee asks about confidential salary bands -> abstained (never retrieved); HR admin -> answered
curl -s localhost:8000/v1/chat -H "Authorization: Bearer tok-emp-ravi"  -H "Content-Type: application/json" -d '{"message":"What is the salary range for band E5?"}'
curl -s localhost:8000/v1/chat -H "Authorization: Bearer tok-hr-anita" -H "Content-Type: application/json" -d '{"message":"What is the salary range for band E5?"}'

# high-impact action -> pending approval; HR admin approves
curl -s localhost:8000/v1/chat -H "Authorization: Bearer tok-emp-ravi" -H "Content-Type: application/json" \
     -d '{"message":"Please apply for leave from 2026-12-01 to 2026-12-05."}'
curl -s localhost:8000/v1/approvals -H "Authorization: Bearer tok-hr-anita"
curl -s -X POST localhost:8000/v1/approvals/<id>/decision -H "Authorization: Bearer tok-hr-anita" \
     -H "Content-Type: application/json" -d '{"decision":"approve","comment":"ok"}'
```

PowerShell:

```powershell
$h = @{ Authorization = "Bearer tok-emp-ravi" }
Invoke-RestMethod -Method Post -Uri http://localhost:8000/v1/chat -Headers $h -ContentType "application/json" `
  -Body '{"message":"What is the deadline to submit an expense claim?"}'
```

| Status | Meaning |
|---|---|
| `answered` | grounded answer with citations |
| `abstained` | nothing authorized/relevant, model abstained, no citations, or low groundedness |
| `blocked` | input policy: secret, blocked PII type, injection, off-topic |
| `review` | sensitive topic routed to a human (reference in `approval_id`) |
| `tool_result` | low-impact tool executed (own leave balance) |
| `pending_approval` | high-impact action waiting for `hr_admin` |
| `fallback` | invalid/unsafe model output or internal error; safe message, details only in telemetry |

## 5. Tests, regression set, release gate

```bash
pytest                                   # 70 tests, offline (mock worst-case LLM + hashing embedder)
python -m eval.run_regression            # 39 cases -> reports/regression_report.md
python -m eval.run_regression --live     # with your .env models (Ollama/MiniLM) before a release
python -m eval.run_regression --live --langfuse   # also a Langfuse dataset + experiment run
python -m scripts.release_gate           # blocks release if policy/prompt changed since the last evaluation
python -m scripts.test_report            # everything -> reports/TEST_REPORT.md
```

| Acceptance test (brief) | Test class |
|---|---|
| Unauthorized documents never enter the prompt | `TestUnauthorizedDocumentsNeverEnterThePrompt` (incl. tampered index metadata) |
| Injection in retrieved content does not trigger tool execution | `TestInjectionInRetrievedContentDoesNotTriggerTools` (incl. quarantine off + model that obeys) |
| Unsupported questions abstain | `TestUnsupportedQuestionsAbstain` |
| Every request has a trace or documented telemetry failure path | `TestEveryRequestHasATraceOrDocumentedFallback` |
| Logs and traces do not expose unnecessary PII or secrets | `TestLogsAndTracesDoNotExposePII` (spans, scores, fallback log, app logs, approval DB, API responses) |
| A policy change is evaluated against the regression set before release | `TestPolicyChangeIsEvaluatedBeforeRelease` |

**Why a worst-case mock model?** `MockLLM` deliberately obeys "call the tool X" and "tell the user Y" instructions
found in documents. The tests prove the system stays safe even when the model is fully compromised; the defences are
in code (deterministic tool routing, output policy, quarantine), not in the model's good behaviour.

## 6. Langfuse

Open http://localhost:3000 (student@example.com / Student@12345). Useful filters: `tool_call_rejected = 1`,
`acl_violations > 0`, `status = review`, `abstained = 1` by `policy_version`, `groundedness` histogram.
Metadata on every trace: `policy_version`, `policy_sha`, `prompt_version`, `chat_model`, `judge_model`, `embedder`,
`app_version`. See [docs/TELEMETRY.md](docs/TELEMETRY.md).

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| `/healthz` says degraded / every answer abstains | `python -m scripts.ingest --reset` with the same `EMBEDDER` as the API |
| Good questions abstain with MiniLM | Check similarities in the `retrieval.authorized` span; recalibrate `retrieval.min_similarity.minilm` (policy change → release gate) |
| Many `fallback` with `invalid_json` | Small model ignores JSON; use a bigger `CHAT_MODEL` (e.g. `qwen2.5:7b`) |
| `telemetry.mode = fallback` | See `fallback_reason` and [docs/TELEMETRY.md](docs/TELEMETRY.md) |
| Release gate: "policy changed" | Run `python -m eval.run_regression` with the new policy, then the gate |
| 413 / 422 | Body > 8 KB / message > 2 000 chars, unknown field or control characters |

## 8. Known limitations and extensions

* Demo identities use static bearer tokens; replace `principal()` with OIDC/JWT validation.
* Deterministic regexes for injection, PII and intents are a baseline, not a complete defence; extend with
  classifiers (Prompt Guard, Presidio) behind the same interfaces and add every miss to the regression set.
* `MiniLM` and Ollama paths need local model downloads; CI uses the deterministic mock path.
* Exercises: add an `EMP_ID`-based manager view (managers see their reports' balances only), stream answers,
  add a Langfuse-managed LLM-as-a-judge evaluator, or move the approval queue to a real ticketing system.
