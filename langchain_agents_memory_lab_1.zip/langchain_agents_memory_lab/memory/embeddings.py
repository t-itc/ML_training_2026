"""Embeddings for semantic memory search.

* get_embeddings("ollama") -> OllamaEmbeddings("nomic-embed-text")  (real model, 768 dims; `ollama pull nomic-embed-text`)
* get_embeddings("toy")    -> ToyConceptEmbeddings                  (offline TEACHING model, 10 dims)

ToyConceptEmbeddings is NOT a real embedding model. Each dimension is a hand-named concept and a text
scores on a dimension when it contains one of that concept's words. It shows the idea behind embeddings
(meaning -> numbers, similar meaning -> similar vectors) with vectors small enough to read on a slide.
Real models learn hundreds of such dimensions from data, and those dimensions do not have names.
"""
from __future__ import annotations

import math
import re

from langchain_core.embeddings import Embeddings

CONCEPTS: dict[str, set[str]] = {
    "programming": {"python", "java", "code", "coding", "programming", "example", "examples", "snippet", "snippets",
                    "script", "function", "implementation"},
    "explanation": {"explain", "explanation", "explanations", "describe", "teach", "understand", "tutorial"},
    "brevity":     {"short", "concise", "brief", "long", "length", "verbose", "summary", "lines"},
    "simplicity":  {"simple", "simpler", "technical", "plain", "beginner", "jargon", "basic", "easy"},
    "data_science": {"data", "scientist", "ml", "machine", "learning", "model", "models", "analytics", "statistics"},
    "agents":      {"langchain", "langgraph", "agent", "agents", "agentic", "tools", "llm", "ai"},
    "career":      {"project", "projects", "build", "portfolio", "career", "role", "job", "work", "works"},
    "location":    {"pune", "mumbai", "bengaluru", "delhi", "live", "city", "office", "where", "located"},
    "identity":    {"name", "called", "call", "who", "myself"},
    "retrieval":   {"rag", "retrieval", "vector", "embedding", "embeddings", "documents", "search", "chunks"},
}
DIMS = list(CONCEPTS)


def toy_vector(text: str) -> list[float]:
    words = re.findall(r"[a-z]+", text.lower())
    v = [float(sum(w in CONCEPTS[c] for w in words)) for c in DIMS]
    n = math.sqrt(sum(x * x for x in v))
    return [x / n for x in v] if n else v


def cosine(a: list[float], b: list[float]) -> float:
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return sum(x * y for x, y in zip(a, b)) / (na * nb) if na and nb else 0.0


class ToyConceptEmbeddings(Embeddings):
    """Offline, explainable 10-dimensional 'concept' embeddings (teaching only)."""

    dims = len(DIMS)

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [toy_vector(t) for t in texts]

    def embed_query(self, text: str) -> list[float]:
        return toy_vector(text)


def get_embeddings(kind: str = "toy"):
    if kind == "ollama":
        from langchain_ollama import OllamaEmbeddings

        return OllamaEmbeddings(model="nomic-embed-text"), 768
    return ToyConceptEmbeddings(), ToyConceptEmbeddings.dims
