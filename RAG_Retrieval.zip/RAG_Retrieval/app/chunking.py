"""Document chunking strategies.

All functions return a list of ``Chunk`` objects that remember where the text
came from (start/end character offsets) so boundaries can be shown and cited.

Sizes are measured in CHARACTERS unless a function says otherwise.
Embedding models limit TOKENS, not characters - use ``count_tokens`` to check.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Sequence

import numpy as np


@dataclass
class Chunk:
    id: str
    text: str
    start: int                       # character offset in the original text
    end: int                         # exclusive
    metadata: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_SENTENCE_RE = re.compile(r"[^.!?\n]+(?:[.!?]+|$)")


def split_sentences(text: str) -> list[tuple[int, int]]:
    """Return (start, end) offsets of sentences. Simple regex splitter:
    good enough for policies; use spaCy/nltk for abbreviations like 'e.g.'."""
    spans = []
    for m in _SENTENCE_RE.finditer(text):
        start, end = m.start(), m.end()
        while start < end and text[start].isspace():
            start += 1
        while end > start and text[end - 1].isspace():
            end -= 1
        if end > start:
            spans.append((start, end))
    return spans


def count_tokens(text: str, tokenizer=None) -> int:
    """Count tokens with a real tokenizer if given (e.g. ``model.tokenizer``),
    otherwise return a rough estimate (~4 characters per token for English)."""
    if tokenizer is not None:
        return len(tokenizer.encode(text, add_special_tokens=False))
    return max(1, round(len(text) / 4))


def _validate(chunk_size: int, overlap: int) -> None:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and smaller than chunk_size")


# ---------------------------------------------------------------------------
# 1 + 2. Fixed-size chunking (optionally with overlap)
# ---------------------------------------------------------------------------
def fixed_size_chunks(text: str, chunk_size: int = 200, overlap: int = 0, prefix: str = "fx") -> list[Chunk]:
    _validate(chunk_size, overlap)
    chunks: list[Chunk] = []
    step = chunk_size - overlap            # how far the window moves each time
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(Chunk(f"{prefix}-{len(chunks)}", text[start:end], start, end))
        if end == len(text):
            break
        start += step
    return chunks


# ---------------------------------------------------------------------------
# 3. Sentence-based chunking
# ---------------------------------------------------------------------------
def sentence_chunks(text: str, max_chars: int = 300, overlap_sentences: int = 0, prefix: str = "sn") -> list[Chunk]:
    """Group whole sentences until max_chars is reached. A single sentence
    longer than max_chars becomes its own chunk (sentences are never cut)."""
    if max_chars <= 0 or overlap_sentences < 0:
        raise ValueError("max_chars must be positive and overlap_sentences >= 0")
    sents = split_sentences(text)
    chunks: list[Chunk] = []
    i = 0
    while i < len(sents):
        j = i + 1
        while j < len(sents) and sents[j][1] - sents[i][0] <= max_chars:
            j += 1
        start, end = sents[i][0], sents[j - 1][1]
        chunks.append(Chunk(f"{prefix}-{len(chunks)}", text[start:end], start, end))
        if j >= len(sents):
            break
        i = max(i + 1, j - overlap_sentences)   # always move forward
    return chunks


# ---------------------------------------------------------------------------
# 4. Recursive character chunking
# ---------------------------------------------------------------------------
DEFAULT_SEPARATORS = ["\n\n", "\n", ". ", " ", ""]


def recursive_chunks(text: str, chunk_size: int = 300, overlap: int = 0,
                     separators: Sequence[str] = DEFAULT_SEPARATORS, prefix: str = "rc") -> list[Chunk]:
    """Split on the 'largest' separator first (paragraphs), and only fall back
    to smaller separators (lines, sentences, words, characters) for pieces that
    are still too long. Neighbouring small pieces are merged up to chunk_size."""
    _validate(chunk_size, overlap)

    def split(start: int, end: int, seps: Sequence[str]) -> list[tuple[int, int]]:
        if end - start <= chunk_size:
            return [(start, end)]
        sep, rest = seps[0], seps[1:]
        if sep == "":                                    # last resort: hard cut
            return [(s, min(s + chunk_size, end)) for s in range(start, end, chunk_size)]
        pieces, pos = [], start
        while True:
            idx = text.find(sep, pos, end)
            if idx == -1:
                pieces.append((pos, end))
                break
            pieces.append((pos, idx + len(sep)))          # keep the separator with the left piece
            pos = idx + len(sep)
        if len(pieces) == 1:                              # separator not present -> try smaller one
            return split(start, end, rest)
        out = []
        for a, b in pieces:
            out.extend(split(a, b, rest) if b - a > chunk_size else [(a, b)])
        return out

    # merge small neighbouring pieces up to chunk_size
    merged: list[tuple[int, int]] = []
    for a, b in split(0, len(text), list(separators)):
        if merged and b - merged[-1][0] <= chunk_size:
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))

    chunks = []
    for a, b in merged:
        a = max(0, a - overlap) if chunks else a          # optional character overlap
        piece = text[a:b]
        lead = len(piece) - len(piece.lstrip())
        trail = len(piece) - len(piece.rstrip())
        if piece.strip():
            chunks.append(Chunk(f"{prefix}-{len(chunks)}", piece.strip(), a + lead, b - trail))
    return chunks


# ---------------------------------------------------------------------------
# 5. Semantic chunking
# ---------------------------------------------------------------------------
def semantic_chunks(text: str, embed: Callable[[list[str]], np.ndarray],
                    breakpoint_percentile: float = 80.0, max_chars: int = 600, prefix: str = "sm") -> list[Chunk]:
    """Start a new chunk where the meaning changes.

    1. split into sentences
    2. embed every sentence (``embed`` returns L2-normalised vectors)
    3. distance between neighbours = 1 - cosine similarity
    4. distances above the given percentile are 'topic shifts' -> boundaries
    """
    sents = split_sentences(text)
    if len(sents) <= 1:
        return [Chunk(f"{prefix}-0", text.strip(), 0, len(text))] if text.strip() else []
    vecs = embed([text[a:b] for a, b in sents])
    distances = 1.0 - np.sum(vecs[:-1] * vecs[1:], axis=1)       # one per neighbour pair
    threshold = np.percentile(distances, breakpoint_percentile)

    chunks, group_start = [], 0
    for i in range(1, len(sents)):
        too_long = sents[i][1] - sents[group_start][0] > max_chars
        if distances[i - 1] > threshold or too_long:
            a, b = sents[group_start][0], sents[i - 1][1]
            chunks.append(Chunk(f"{prefix}-{len(chunks)}", text[a:b], a, b,
                                {"split_distance": round(float(distances[i - 1]), 3)}))
            group_start = i
    a, b = sents[group_start][0], sents[-1][1]
    chunks.append(Chunk(f"{prefix}-{len(chunks)}", text[a:b], a, b))
    return chunks


# ---------------------------------------------------------------------------
# 6. Document-structure-based chunking (Markdown headings)
# ---------------------------------------------------------------------------
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)


def markdown_section_chunks(markdown: str, prefix: str = "md") -> list[Chunk]:
    """One chunk per section; the heading path is kept as metadata
    (e.g. 'Employee Handbook > Leave > Sick Leave')."""
    heads = list(_HEADING_RE.finditer(markdown))
    chunks, path = [], []
    for k, h in enumerate(heads):
        level, title = len(h.group(1)), h.group(2).strip()
        path = path[: level - 1] + [title]
        body_start = h.end()
        body_end = heads[k + 1].start() if k + 1 < len(heads) else len(markdown)
        body = markdown[body_start:body_end]
        if body.strip():
            lead = len(body) - len(body.lstrip())
            a = body_start + lead
            b = a + len(body.strip())
            chunks.append(Chunk(f"{prefix}-{len(chunks)}", markdown[a:b], a, b,
                                {"section": " > ".join(path), "level": level}))
    return chunks


# ---------------------------------------------------------------------------
# 7. Parent-child chunking
# ---------------------------------------------------------------------------
def parent_child_chunks(markdown: str, child_max_chars: int = 160) -> tuple[list[Chunk], list[Chunk]]:
    """Parents = whole sections (rich context for the LLM).
    Children = small sentence groups inside each parent (precise for search).
    Each child stores ``parent_id`` so a child hit can be swapped for its parent."""
    parents = markdown_section_chunks(markdown, prefix="parent")
    children: list[Chunk] = []
    for p in parents:
        for c in sentence_chunks(p.text, max_chars=child_max_chars, prefix="tmp"):
            children.append(Chunk(f"child-{len(children)}", c.text, p.start + c.start, p.start + c.end,
                                  {"parent_id": p.id, "section": p.metadata["section"]}))
    return parents, children
