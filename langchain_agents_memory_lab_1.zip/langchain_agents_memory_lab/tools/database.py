"""Database tool — read-only, parameterised lookups in a SQLite employee table.

The LLM never writes SQL: it passes a name or id and we run a fixed, safe query.
"""
from __future__ import annotations

import csv
from contextlib import closing
import sqlite3

from langchain.tools import tool

from config import PROJECT_ROOT, get_settings


def get_connection() -> sqlite3.Connection:
    db = get_settings().employee_db
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    if not conn.execute("SELECT name FROM sqlite_master WHERE name='employees'").fetchone():
        conn.execute("CREATE TABLE employees (emp_id TEXT PRIMARY KEY, name TEXT, department TEXT, role TEXT,"
                     " manager TEXT, location TEXT, leave_balance INTEGER)")
        with open(PROJECT_ROOT / "data" / "employees.csv", encoding="utf-8") as f:
            rows = [tuple(r.values()) for r in csv.DictReader(f)]
        conn.executemany("INSERT INTO employees VALUES (?,?,?,?,?,?,?)", rows)
        conn.commit()
    return conn


@tool(parse_docstring=True)
def query_employee(name_or_id: str) -> str:
    """Look up an employee record (role, department, manager, location, leave balance).

    Args:
        name_or_id: Employee id like "E101" or (part of) a name like "Priya".
    """
    term = name_or_id.strip()
    with closing(get_connection()) as conn:
        rows = conn.execute(
            "SELECT * FROM employees WHERE emp_id = ? COLLATE NOCASE OR name LIKE ? LIMIT 5",
            (term, f"%{term}%"),
        ).fetchall()
    if not rows:
        return f"No employee found for {term!r}."
    return "\n".join(
        f"{r['emp_id']} | {r['name']} | {r['role']} ({r['department']}) | manager: {r['manager'] or '-'} | "
        f"{r['location']} | leave balance: {r['leave_balance']} days"
        for r in rows
    )
