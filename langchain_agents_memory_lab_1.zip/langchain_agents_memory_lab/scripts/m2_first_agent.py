"""Module 2 — your first agent: LLM + system prompt, no tools.

    python -m scripts.m2_first_agent
    python -m scripts.m2_first_agent --trace          # print every message in the result
    python -m scripts.m2_first_agent --graph          # show the LangGraph nodes and edges create_agent built
"""
import argparse

from agents.assistant_agent import ask, build_agent
from config import get_llm
from scripts._common import banner, show


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", action="store_true")
    ap.add_argument("-q", "--question")
    ap.add_argument("--graph", action="store_true")
    args = ap.parse_args()
    if args.graph:
        show_graphs()
        return

    banner("Module 2 · First agent (no tools, no memory)")

    # Step 1: test the raw LLM connection (no agent yet)
    reply = get_llm().invoke("Reply with exactly: LLM connection OK")
    print(f"\nRaw LLM test -> {reply.content[:80]}")

    # Step 2: the agent = LLM + system prompt + runtime loop
    agent = build_agent("basic")
    questions = [args.question] if args.question else [
        "Hi! Who are you?",
        "Explain what an AI agent is in two sentences.",
        "What is 250 multiplied by 12?",          # no calculator yet -> the LLM guesses (or the mock says it can't)
    ]
    for q in questions:
        answer, result = ask(agent, q)
        show(q, answer, tools=[])
        if args.trace:
            for m in result["messages"]:
                print(f"      {m.type:<6} {str(m.content)[:90]!r}")
    print("\nNote: without tools the agent can only use what the model already knows — no date, no exact math.")


def show_graphs() -> None:
    """create_agent returns a compiled LangGraph StateGraph: print its nodes and edges per stage."""
    from memory.long_term import get_store

    banner("Module 2.1 · The LangGraph graph behind create_agent")
    for stage in ("basic", "tools", "agentic"):
        g = (build_agent(stage, store=get_store("memory")) if stage == "agentic" else build_agent(stage)).get_graph()
        print(f"\nstage={stage}")
        print("   nodes:", ", ".join(g.nodes))
        for e in g.edges:
            print(f"   edge : {e.source:<28} {'-.->' if e.conditional else '--->'} {e.target}")
    print("\nMermaid source (paste into https://mermaid.live):")
    print(build_agent("tools").get_graph().draw_mermaid())


if __name__ == "__main__":
    main()
