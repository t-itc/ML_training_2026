# RAG Engineering: Chunking, Embeddings and Retrieval

Teaching implementation for this module. Every component is written directly with
Python libraries (no LangChain / LlamaIndex) so each step can be explained.

| Module | Code |
|---|---|
| 1 · Chunking | `app/chunking.py` — fixed, overlap, sentence, recursive, semantic, Markdown-structure, parent-child |
| 2 · Embeddings | `app/embeddings.py` — model wrapper with query/document prefixes, cosine similarity |
| 3 · Retrieval | `app/dense_retriever.py` (dense, metadata filters, parent-child), `app/sparse_retriever.py` (BM25, TF-IDF), `app/mmr.py`, multi-query in `app/hybrid_retriever.py` |
| 4 · Hybrid + reranking | `app/hybrid_retriever.py` (RRF), `app/reranker.py` (cross-encoder) |
| 5 · Evaluation | `app/evaluation.py` — Precision@K, Recall@K, MRR, nDCG@K |

## Project layout

```text
RAG_Retrieval/
├── data/
│   ├── company_documents.json   # 20 policy passages with department / doc_type / category metadata
│   ├── test_questions.json      # 12 questions with expected relevant document IDs
│   └── employee_handbook.md     # longer structured document for chunking demos
├── app/                         # one module per technique + main.py CLI
├── tests/test_retrieval.py      # runs without downloading models
├── RAG_Retrieval_walkthrough.ipynb         # optional: the same demos cell by cell
├── requirements.txt
└── README.md
```

## Setup (Windows PowerShell)

```powershell
cd RAG_Retrieval
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Conda users: `conda activate ds_env` then `pip install -r requirements.txt`.
macOS/Linux: `source .venv/bin/activate`.

**First run needs internet**: models are downloaded from the Hugging Face Hub and cached
(`all-MiniLM-L6-v2` ≈ 90 MB, `bge-small-en-v1.5` ≈ 130 MB, cross-encoder ≈ 90 MB).
Run `python -m app.main evaluate` once before class so everything is cached.

## Run the tests

```powershell
python -m pytest -q                       # fast, no model download (uses a fake embedding model)
$env:RUN_MODEL_TESTS="1"; python -m pytest -q   # also test the real MiniLM model
```

## Demo commands (always run from the project root)

| Module | Command |
|---|---|
| 1 | `python -m app.main chunk` (all methods) · `python -m app.main chunk --method overlap --size 150 --overlap 30` |
| 1 | `python -m app.main parent-child --query "Do I need a doctor's note when I am ill?"` |
| 2 | `python -m app.main embed --query "How many vacation days do I get?"` |
| 2 | `python -m app.main compare-models --models minilm bge-small` |
| 3 | `python -m app.main search --method dense --query "How many vacation days do I get?"` |
| 3 | `python -m app.main search --method bm25 --query "What does error VPN-417 mean?"` |
| 3 | `python -m app.main search --method tfidf --query "expense claim deadline"` |
| 3 | `python -m app.main search --method hybrid --query "password rules" --department IT` |
| 3 | `python -m app.main mmr --lambda-mult 0.5` |
| 3 | `python -m app.main multi-query` (uses Ollama) or `... multi-query --variants "gifts from suppliers" "present from a vendor"` |
| 4 | `python -m app.main wfh-demo` · `python -m app.main rrf-demo` |
| 4 | `python -m app.main search --method rerank --query "What is the work-from-home policy?"` |
| 5 | `python -m app.main evaluate` · `python -m app.main evaluate --k 5 --no-rerank --save` |

Choose another embedding model with the global `--model` option **before** the command:

```powershell
python -m app.main --model bge-small search --method dense --query "vacation days"
```

Available keys: `minilm`, `mpnet`, `bge-small`, `e5-small`, `gte-small`, `nomic`
(`nomic` needs `pip install einops` and runs remote code from the model repository).

Metadata filters: `--department HR|Finance|IT|Facilities|Legal`, `--doc-type policy|procedure|faq`,
`--category leave|remote-work|expenses|travel|security|support|...`.

## Ollama (optional, multi-query)

`multi-query` asks a local LLM for rephrasings of the question.

```powershell
ollama list                          # Ollama must be running (the desktop app starts it)
$env:OLLAMA_MODEL="mistral"          # any NAME from `ollama list`, e.g. llama3.2:1b
python -m app.main multi-query --query "Am I allowed to accept a present from a vendor?"
```

If Ollama is not reachable the command falls back to the original question only — or pass your own `--variants`.

## Notes for interpreting results

* Scores from different methods are on **different scales** (cosine ≈ −1…1, BM25 unbounded, cross-encoder logits). Compare ranks, not raw scores, across methods.
* The dataset is deliberately tiny (20 passages, 12 questions). Results show *how* to compare methods; they do **not** prove that one method is always better. Evaluate on your client's own documents and questions.
* Changing the embedding model requires **re-embedding the whole collection**: vectors from different models live in different spaces (often with different dimensions).
* Sizes in `chunking.py` are in **characters**. Models limit **tokens** — use `count_tokens(text, model.tokenizer)` to check.

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: app` | Run from the project root with `python -m app.main ...` |
| `Could not load ... model` | First run needs internet / proxy (`HTTPS_PROXY`), or copy a cached model and pass its folder path in `MODEL_CONFIGS` |
| `Activate.ps1 cannot be loaded` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| Slow first query | Model loading; later queries are fast. The cross-encoder adds time per candidate. |
| `ollama serve` → port already in use | Ollama is already running; just use it (`ollama list`) |
