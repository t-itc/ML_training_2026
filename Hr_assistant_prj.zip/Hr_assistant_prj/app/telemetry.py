"""Langfuse tracing with an explicit, documented failure path (docs/TELEMETRY.md).

Every request ends in `telemetry.finalize(...)`, which returns one of:
  * mode="langfuse", trace_id=...         -> the trace exists in Langfuse
  * mode="fallback", fallback_reason=...  -> a masked audit record was appended to
                                             logs/telemetry_fallback.jsonl with the same request_id
Fallback reasons:
  langfuse_not_configured   keys missing (e.g. local dev without Langfuse)
  auth_check_failed         keys rejected / server unreachable at startup
  export_errors             the SDK or OTLP exporter logged an error since startup (degraded)
  no_trace_id               tracing produced no trace id for this request
Telemetry never blocks or fails a user request.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

from langfuse import Langfuse

from app.config import APP_VERSION, get_settings
from app.policy.pii import mask_any


class _ExportErrorHandler(logging.Handler):
    def __init__(self, owner: "Telemetry"):
        super().__init__(level=logging.ERROR)
        self.owner = owner

    def emit(self, record: logging.LogRecord) -> None:
        self.owner.export_errors += 1


class Telemetry:
    def __init__(self):
        self.export_errors = 0
        self.disabled_reason: str | None = None
        self._lock = threading.Lock()
        self.configure()

    # ------------------------------------------------------------------ setup
    def configure(self, **client_kwargs) -> None:
        """(Re)create the client. Tests pass span_exporter=InMemorySpanExporter() to inspect spans."""
        s = get_settings()
        configured = bool(os.getenv("LANGFUSE_PUBLIC_KEY") and os.getenv("LANGFUSE_SECRET_KEY"))
        self.enabled = configured
        self.disabled_reason = None if configured else "langfuse_not_configured"
        self.export_errors = 0
        logging.getLogger("langfuse").setLevel(logging.WARNING if configured else logging.CRITICAL)
        if getattr(self, "client", None) is not None:      # reconfigure: drop the old exporter/resources
            try:
                self.client.shutdown()
                from langfuse._client.resource_manager import LangfuseResourceManager
                LangfuseResourceManager.reset()
            except Exception:
                pass
        self.client = Langfuse(mask=lambda *, data, **kw: mask_any(data), environment=s.environment,
                               release=APP_VERSION, tracing_enabled=configured, **client_kwargs)
        # Without keys the SDK is a no-op; silence its per-call warnings - the fallback path is explicit.
        logging.getLogger("langfuse").setLevel(logging.WARNING if configured else logging.CRITICAL)
        if configured:
            h = _ExportErrorHandler(self)
            for name in ("langfuse", "opentelemetry.exporter"):
                lg = logging.getLogger(name)
                lg.handlers = [x for x in lg.handlers if not isinstance(x, _ExportErrorHandler)]
                lg.addHandler(h)

    def startup_check(self) -> None:
        if not self.enabled:
            return
        try:
            ok = self.client.auth_check()
        except Exception:
            ok = False
        if not ok:
            self.enabled, self.disabled_reason = False, "auth_check_failed"

    @property
    def mode(self) -> str:
        return "langfuse" if self.enabled and self.export_errors == 0 else "fallback"

    def status(self) -> dict:
        return {"mode": self.mode, "enabled": self.enabled, "disabled_reason": self.disabled_reason,
                "export_errors": self.export_errors}

    # ------------------------------------------------------------------ per request
    def finalize(self, request_id: str, trace_id: str | None, record: dict) -> dict:
        if self.enabled and self.export_errors == 0 and trace_id:
            return {"mode": "langfuse", "trace_id": trace_id}
        reason = (self.disabled_reason or ("export_errors" if self.export_errors else "no_trace_id"))
        self._write_fallback({"request_id": request_id, "trace_id": trace_id, "fallback_reason": reason, **record})
        return {"mode": "fallback", "trace_id": trace_id, "fallback_reason": reason}

    def _write_fallback(self, rec: dict) -> None:
        path = Path(get_settings().telemetry_fallback_log)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Identifiers needed for audit stay as-is (employee IDs are pseudonymous, like the Langfuse user_id);
        # every other value is masked. Message text is never written to this log.
        keep = {k: rec.pop(k) for k in ("request_id", "trace_id", "user_id") if k in rec}
        rec = {"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"), **keep, **mask_any(rec)}
        with self._lock, path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def flush(self) -> None:
        try:
            self.client.flush()
        except Exception:
            self.export_errors += 1


telemetry = Telemetry()
