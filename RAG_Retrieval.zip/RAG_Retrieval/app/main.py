"""Command-line entry point for every demo.

Run from the project root, for example:
    python -m app.main chunk
    python -m app.main search --method hybrid --query "What is the work-from-home policy?"
    python -m app.main evaluate
Use ``python -m app.main --help`` to list all commands.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------
def load_docs() -> list[dict]:
    return json.loads((DATA / "company_documents.json").read_text(encoding="utf-8"))


def load_questions() -> list[dict]:
    return json.loads((DATA / "test_questions.json").read_text(encoding="utf-8"))


def load_handbook() -> str:
    return (DATA / "employee_handbook.md").read_text(encoding="utf-8")


def build_filters(args) -> dict | None:
    f = {k: getattr(args, k) for k in ("department", "doc_type", "category") if getattr(args, k, None)}
    return f or None


def show(title: str, results) -> None:
    print(f"\n=== {title} ===")
    if not results:
        print("  (no results)")
    for rank, r in enumerate(results, start=1):
        print(f"  #{rank:<2} {r.id:<8} {r.score:>8.4f}  [{r.doc['department']}/{r.doc['doc_type']}] {r.doc['text']}")


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
def cmd_chunk(args) -> None:
    from app import chunking as ch

    text = load_handbook()
    print(f"Handbook: {len(text)} characters, ~{ch.count_tokens(text)} tokens (rough estimate: chars / 4)")
    methods = {
        "fixed": lambda: ch.fixed_size_chunks(text, args.size, 0),
        "overlap": lambda: ch.fixed_size_chunks(text, args.size, args.overlap),
        "sentence": lambda: ch.sentence_chunks(text, args.size, overlap_sentences=1 if args.overlap else 0),
        "recursive": lambda: ch.recursive_chunks(text, args.size, 0),
        "structure": lambda: ch.markdown_section_chunks(text),
    }
    selected = list(methods) if args.method == "all" else [args.method]
    for name in selected:
        if name in ("semantic", "parent-child"):
            continue
        chunks = methods[name]()
        lengths = [len(c.text) for c in chunks]
        print(f"\n--- {name}: {len(chunks)} chunks, length min/avg/max = "
              f"{min(lengths)}/{sum(lengths) // len(lengths)}/{max(lengths)} chars")
        for c in chunks[: args.show]:
            meta = f"  {c.metadata}" if c.metadata else ""
            print(f"  [{c.id}] ({c.start}-{c.end}){meta}\n      {c.text!r}")
    if args.method in ("all", "semantic"):
        from app.embeddings import EmbeddingModel
        model = EmbeddingModel(args.model)
        chunks = ch.semantic_chunks(text.replace("#", ""), model.encode_documents, breakpoint_percentile=80)
        print(f"\n--- semantic ({model.name}): {len(chunks)} chunks")
        for c in chunks[: args.show]:
            print(f"  [{c.id}] {c.metadata}\n      {c.text!r}")
    if args.method in ("all", "parent-child"):
        parents, children = ch.parent_child_chunks(text)
        print(f"\n--- parent-child: {len(parents)} parents, {len(children)} children")
        for c in children[: args.show]:
            print(f"  [{c.id}] parent={c.metadata['parent_id']} ({c.metadata['section']})\n      {c.text!r}")


def cmd_embed(args) -> None:
    import numpy as np
    from app.embeddings import EmbeddingModel, cosine_similarity

    docs = load_docs()[:6]
    model = EmbeddingModel(args.model)
    doc_vecs = model.encode_documents([d["text"] for d in docs])
    q_vec = model.encode_queries([args.query])[0]
    print(f"Model: {model.name} | dimension: {model.dimension}")
    print(f"Document matrix: {doc_vecs.shape}, query vector: {q_vec.shape}")
    print(f"Row norms (normalised -> 1.0): {np.linalg.norm(doc_vecs, axis=1).round(3)}")
    print(f"First 6 values of {docs[0]['id']}: {doc_vecs[0][:6].round(4)}")
    sims = cosine_similarity(q_vec, doc_vecs)[0]
    print(f"\nQuery: {args.query}")
    for i in np.argsort(-sims):
        print(f"  {sims[i]:.4f}  {docs[i]['id']:<8} {docs[i]['text']}")
    tokens = model.tokenizer.tokenize(docs[0]["text"])
    print(f"\n'{docs[0]['text']}'\n  -> {len(docs[0]['text'])} characters, {len(tokens)} tokens: {tokens}")


def cmd_compare_models(args) -> None:
    from app.dense_retriever import DenseRetriever
    from app.embeddings import EmbeddingModel
    from app.evaluation import evaluate, format_summary

    docs, questions = load_docs(), load_questions()
    print("Each model needs its OWN index: vectors from different models are not comparable.\n")
    for key in args.models:
        model = EmbeddingModel(key)
        retriever = DenseRetriever(docs, model)          # re-embeds the whole collection
        print(f"--- {model.name} (dim {model.dimension})")
        for q in questions[: args.show]:
            ids = [r.id for r in retriever.search(q["question"], 3)]
            print(f"  {q['question']:<62} -> {ids}  (expected {q['relevant_ids']})")
        print("  " + format_summary(key, evaluate(lambda s, k: [r.id for r in retriever.search(s, k)], questions, args.k)))
        print()


def _retrievers(model_key: str, docs: list[dict]):
    from app.dense_retriever import DenseRetriever
    from app.embeddings import EmbeddingModel
    from app.hybrid_retriever import HybridRetriever
    from app.sparse_retriever import BM25Retriever

    dense = DenseRetriever(docs, EmbeddingModel(model_key))
    bm25 = BM25Retriever(docs)
    return dense, bm25, HybridRetriever(dense, bm25, candidates=10)


def cmd_search(args) -> None:
    docs = load_docs()
    filters = build_filters(args)
    if filters:
        print(f"Metadata filters: {filters}")
    if args.method in ("bm25", "tfidf"):
        from app.sparse_retriever import BM25Retriever, TfidfRetriever
        r = BM25Retriever(docs) if args.method == "bm25" else TfidfRetriever(docs)
        show(f"{args.method.upper()} | {args.query}", r.search(args.query, args.top_k, filters))
        return
    dense, bm25, hybrid = _retrievers(args.model, docs)
    if args.method == "dense":
        show(f"Dense | {args.query}", dense.search(args.query, args.top_k, filters))
    elif args.method == "hybrid":
        show(f"Hybrid (RRF) | {args.query}", hybrid.search(args.query, args.top_k, filters))
    elif args.method == "rerank":
        from app.reranker import Reranker
        candidates = hybrid.search(args.query, 10, filters)
        show("Before reranking (hybrid top 10)", candidates)
        show("After cross-encoder reranking", Reranker().rerank(args.query, candidates, args.top_k))


def cmd_wfh_demo(args) -> None:
    """The four-document example from Module 4."""
    from app.reranker import Reranker

    by_id = {d["id"]: d for d in load_docs()}
    docs = [by_id[i] for i in ("HR-001", "HR-002", "HR-003", "FIN-001")]
    query = "What is the work-from-home policy?"
    dense, bm25, hybrid = _retrievers(args.model, docs)
    from app.sparse_retriever import tokenize
    print(f"Query: {query}\nBM25 query tokens: {tokenize(query)}")
    show("Dense", dense.search(query, 4))
    show("BM25 (only documents sharing a query token get a score)", bm25.search(query, 4))
    show("Hybrid (RRF, k=60)", hybrid.search(query, 4))
    show("Hybrid + cross-encoder rerank", Reranker().rerank(query, hybrid.search(query, 4)))


def cmd_rrf_demo(_args) -> None:
    from app.hybrid_retriever import reciprocal_rank_fusion

    # Two example rankings (worked example from the tutorial, not model output)
    ranking_a = ["HR-001", "HR-003", "HR-002", "FIN-001"]    # e.g. from dense retrieval
    ranking_b = ["HR-002", "HR-001", "FIN-001"]              # e.g. from BM25
    print("Ranking A (e.g. dense):", ranking_a)
    print("Ranking B (e.g. BM25): ", ranking_b)
    for doc_id, score in reciprocal_rank_fusion([ranking_a, ranking_b], k=60):
        parts = [f"1/(60+{lst.index(doc_id) + 1})" for lst in (ranking_a, ranking_b) if doc_id in lst]
        print(f"  {doc_id:<8} {' + '.join(parts):<24} = {score:.5f}")


def cmd_mmr(args) -> None:
    from app.embeddings import EmbeddingModel
    from app.mmr import mmr

    docs = load_docs()
    model = EmbeddingModel(args.model)
    vecs = model.encode_documents([d["text"] for d in docs])
    q = model.encode_queries([args.query])[0]
    candidates = list((vecs @ q).argsort()[::-1][:10])         # first stage: top-10 by relevance
    for lam in (1.0, args.lambda_mult):
        picked = mmr(q, vecs, top_k=args.top_k, lambda_mult=lam, candidate_ids=candidates)
        print(f"\n=== MMR lambda={lam} {'(pure relevance)' if lam == 1.0 else ''} ===")
        for i in picked:
            print(f"  {float(vecs[i] @ q):.4f}  {docs[i]['id']:<8} [{docs[i]['category']}] {docs[i]['text']}")


def cmd_multi_query(args) -> None:
    from app.dense_retriever import DenseRetriever
    from app.embeddings import EmbeddingModel
    from app.hybrid_retriever import generate_query_variants, multi_query_search

    docs = load_docs()
    retriever = DenseRetriever(docs, EmbeddingModel(args.model))
    variants = args.variants or generate_query_variants(args.query, n=3)
    results, per_query = multi_query_search(retriever, args.query, variants, top_k=args.top_k)
    for q, ids in per_query.items():
        print(f"  {q!r:<70} -> {ids[:4]}")
    show("Fused with RRF", results)


def cmd_parent_child(args) -> None:
    from app.chunking import parent_child_chunks
    from app.dense_retriever import ParentChildRetriever
    from app.embeddings import EmbeddingModel

    parents, children = parent_child_chunks(load_handbook())
    retriever = ParentChildRetriever(parents, children, EmbeddingModel(args.model))
    print(f"Query: {args.query}")
    for parent, child, score in retriever.search(args.query, top_k=2):
        print(f"\n  matched child {child.id} ({score:.4f}): {child.text!r}")
        print(f"  -> returned parent {parent.id} [{parent.metadata['section']}]:\n     {parent.text!r}")


def cmd_evaluate(args) -> None:
    from app.evaluation import evaluate, format_summary

    docs, questions = load_docs(), load_questions()
    dense, bm25, hybrid = _retrievers(args.model, docs)
    systems = {
        "dense": lambda q, k: [r.id for r in dense.search(q, k)],
        "bm25": lambda q, k: [r.id for r in bm25.search(q, k)],
        "hybrid": lambda q, k: [r.id for r in hybrid.search(q, k)],
    }
    if not args.no_rerank:
        from app.reranker import Reranker
        reranker = Reranker()
        systems["hybrid+rerank"] = lambda q, k: [r.id for r in reranker.rerank(q, hybrid.search(q, 10), k)]

    results = {name: evaluate(fn, questions, args.k) for name, fn in systems.items()}
    print(f"Per-question top-{args.k} (✓ = relevant):")
    for i, q in enumerate(questions):
        print(f"\n{q['id']} {q['question']}  expected={q['relevant_ids']}")
        for name, res in results.items():
            row = res["rows"][i]
            marks = " ".join(f"{d}{'✓' if d in q['relevant_ids'] else ''}" for d in row["retrieved"])
            print(f"   {name:<14} {marks}")
    print("\nSummary (these are YOUR measured results on this small dataset):")
    for name, res in results.items():
        print("  " + format_summary(name, res))
    if args.save:
        out = ROOT / "evaluation_results.json"
        out.write_text(json.dumps(results, indent=2), encoding="utf-8")
        print(f"\nSaved {out}")


# ---------------------------------------------------------------------------
def main(argv=None) -> None:
    p = argparse.ArgumentParser(description="RAG chunking, embeddings and retrieval demos")
    p.add_argument("--model", default="minilm", help="embedding model key (minilm, mpnet, bge-small, e5-small, gte-small, nomic)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("chunk", help="compare chunking strategies on data/employee_handbook.md")
    s.add_argument("--method", default="all", choices=["all", "fixed", "overlap", "sentence", "recursive", "semantic", "structure", "parent-child"])
    s.add_argument("--size", type=int, default=200)
    s.add_argument("--overlap", type=int, default=40)
    s.add_argument("--show", type=int, default=3, help="chunks to print per method")
    s.set_defaults(fn=cmd_chunk)

    s = sub.add_parser("embed", help="embed documents and a query, rank by cosine similarity")
    s.add_argument("--query", default="How many vacation days do I get?")
    s.set_defaults(fn=cmd_embed)

    s = sub.add_parser("compare-models", help="same dataset, two or more embedding models")
    s.add_argument("--models", nargs="+", default=["minilm", "bge-small"])
    s.add_argument("--k", type=int, default=3)
    s.add_argument("--show", type=int, default=6)
    s.set_defaults(fn=cmd_compare_models)

    s = sub.add_parser("search", help="dense / bm25 / tfidf / hybrid / rerank search with metadata filters")
    s.add_argument("--query", required=True)
    s.add_argument("--method", default="hybrid", choices=["dense", "bm25", "tfidf", "hybrid", "rerank"])
    s.add_argument("--top-k", type=int, default=5)
    s.add_argument("--department")
    s.add_argument("--doc-type")
    s.add_argument("--category")
    s.set_defaults(fn=cmd_search)

    s = sub.add_parser("wfh-demo", help="Module 4: dense vs BM25 vs hybrid vs rerank on four documents")
    s.set_defaults(fn=cmd_wfh_demo)

    s = sub.add_parser("rrf-demo", help="Module 4: Reciprocal Rank Fusion worked example")
    s.set_defaults(fn=cmd_rrf_demo)

    s = sub.add_parser("mmr", help="Maximum Marginal Relevance vs plain top-k")
    s.add_argument("--query", default="What do I need to know about working from home?")
    s.add_argument("--lambda-mult", type=float, default=0.5)
    s.add_argument("--top-k", type=int, default=4)
    s.set_defaults(fn=cmd_mmr)

    s = sub.add_parser("multi-query", help="several query formulations fused with RRF (Ollama optional)")
    s.add_argument("--query", default="Am I allowed to accept a present from a vendor?")
    s.add_argument("--variants", nargs="*", help="your own rephrasings; if omitted Ollama generates them")
    s.add_argument("--top-k", type=int, default=5)
    s.set_defaults(fn=cmd_multi_query)

    s = sub.add_parser("parent-child", help="search small children, return parent sections")
    s.add_argument("--query", default="Do I need a doctor's note when I am ill?")
    s.set_defaults(fn=cmd_parent_child)

    s = sub.add_parser("evaluate", help="Module 5: P@K, R@K, MRR, nDCG for dense / bm25 / hybrid / rerank")
    s.add_argument("--k", type=int, default=3)
    s.add_argument("--no-rerank", action="store_true", help="skip the cross-encoder (faster)")
    s.add_argument("--save", action="store_true", help="write evaluation_results.json")
    s.set_defaults(fn=cmd_evaluate)

    args = p.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
