"""Runtime settings (environment / .env) and the versioned guardrail policy (policy.yaml)."""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import yaml

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover
    pass

ROOT = Path(__file__).resolve().parents[1]
APP_VERSION = "1.0.0"


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    # LLM: "ollama" for real runs, "mock" for tests/CI (deterministic, offline)
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "ollama"))
    ollama_host: str = field(default_factory=lambda: os.getenv("OLLAMA_HOST", "http://localhost:11434"))
    chat_model: str = field(default_factory=lambda: os.getenv("CHAT_MODEL", "llama3.2:3b"))
    judge_model: str = field(default_factory=lambda: os.getenv("JUDGE_MODEL", os.getenv("CHAT_MODEL", "llama3.2:3b")))
    llm_timeout_s: float = field(default_factory=lambda: float(os.getenv("LLM_TIMEOUT_SECONDS", "60")))
    use_llm_judge: bool = field(default_factory=lambda: _bool("USE_LLM_JUDGE", True))

    # Retrieval: "minilm" = sentence-transformers/all-MiniLM-L6-v2, "hashing" = offline test embedder
    embedder: str = field(default_factory=lambda: os.getenv("EMBEDDER", "minilm"))
    embedding_model: str = field(default_factory=lambda: os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"))
    chroma_dir: str = field(default_factory=lambda: os.getenv("CHROMA_DIR", str(ROOT / "chroma_db")))
    collection: str = field(default_factory=lambda: os.getenv("CHROMA_COLLECTION", "hr_policies"))
    documents_dir: str = field(default_factory=lambda: os.getenv("DOCUMENTS_DIR", str(ROOT / "data" / "documents")))

    # Identity, tools, approvals
    users_file: str = field(default_factory=lambda: os.getenv("USERS_FILE", str(ROOT / "data" / "users.json")))
    approvals_db: str = field(default_factory=lambda: os.getenv("APPROVALS_DB", str(ROOT / "data" / "approvals.sqlite3")))
    leave_balances_file: str = field(default_factory=lambda: os.getenv("LEAVE_BALANCES_FILE", str(ROOT / "data" / "leave_balances.json")))

    # Telemetry
    telemetry_fallback_log: str = field(default_factory=lambda: os.getenv("TELEMETRY_FALLBACK_LOG", str(ROOT / "logs" / "telemetry_fallback.jsonl")))
    environment: str = field(default_factory=lambda: os.getenv("APP_ENV", "dev"))

    # Policy file (versioned)
    policy_file: str = field(default_factory=lambda: os.getenv("POLICY_FILE", str(ROOT / "app" / "policy" / "policy.yaml")))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


@dataclass(frozen=True)
class Policy:
    raw: dict
    version: str
    sha256: str

    def __getitem__(self, key):
        return self.raw[key]


def load_policy(path: str | Path | None = None) -> Policy:
    path = Path(path or get_settings().policy_file)
    text = path.read_text(encoding="utf-8")
    raw = yaml.safe_load(text)
    return Policy(raw=raw, version=str(raw["version"]), sha256=hashlib.sha256(text.encode()).hexdigest()[:16])


@lru_cache(maxsize=1)
def get_policy() -> Policy:
    return load_policy()


def reset_caches() -> None:
    """Used by tests after changing environment variables."""
    get_settings.cache_clear()
    get_policy.cache_clear()
