"""Tests run fully offline: mock LLM + temporary storage folder."""
import os
import sys
import tempfile
from pathlib import Path

os.environ["LLM_PROVIDER"] = "mock"          # must be set before config is imported
os.environ["WEATHER_MODE"] = "offline"
os.environ["STORAGE_DIR"] = tempfile.mkdtemp(prefix="agent_lab_")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from memory.long_term import get_store  # noqa: E402


@pytest.fixture
def store():
    return get_store("memory")


@pytest.fixture
def sqlite_path(tmp_path):
    return tmp_path / "memory.db"
