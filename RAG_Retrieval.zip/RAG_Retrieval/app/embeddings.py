"""Embedding models: one wrapper that hides model-specific details.

Some models need different text prefixes for QUERIES and DOCUMENTS
(asymmetric retrieval). Getting this wrong silently lowers retrieval quality,
so the prefixes live in one config table.
"""
from __future__ import annotations

import numpy as np

# name -> settings. Prefixes come from each model card.
MODEL_CONFIGS: dict[str, dict] = {
    "minilm": {"name": "sentence-transformers/all-MiniLM-L6-v2", "query_prefix": "", "doc_prefix": ""},
    "mpnet": {"name": "sentence-transformers/all-mpnet-base-v2", "query_prefix": "", "doc_prefix": ""},
    "bge-small": {"name": "BAAI/bge-small-en-v1.5",
                  "query_prefix": "Represent this sentence for searching relevant passages: ", "doc_prefix": ""},
    "e5-small": {"name": "intfloat/e5-small-v2", "query_prefix": "query: ", "doc_prefix": "passage: "},
    "gte-small": {"name": "thenlper/gte-small", "query_prefix": "", "doc_prefix": ""},
    "nomic": {"name": "nomic-ai/nomic-embed-text-v1.5", "query_prefix": "search_query: ",
              "doc_prefix": "search_document: ", "trust_remote_code": True},
}


class EmbeddingModel:
    """Wraps a sentence-transformers model with the right prefixes and L2 normalisation."""

    def __init__(self, key: str = "minilm"):
        if key not in MODEL_CONFIGS:
            raise ValueError(f"Unknown model '{key}'. Choose from: {', '.join(MODEL_CONFIGS)}")
        from sentence_transformers import SentenceTransformer   # imported lazily (heavy)

        cfg = MODEL_CONFIGS[key]
        self.key, self.name = key, cfg["name"]
        self.query_prefix, self.doc_prefix = cfg["query_prefix"], cfg["doc_prefix"]
        try:
            self.model = SentenceTransformer(cfg["name"], trust_remote_code=cfg.get("trust_remote_code", False))
        except Exception as exc:
            raise RuntimeError(f"Could not load {cfg['name']}: {exc}. "
                               "The first run needs internet access to download the model.") from exc

    @property
    def dimension(self) -> int:
        return self.model.get_sentence_embedding_dimension()

    @property
    def tokenizer(self):
        return self.model.tokenizer

    def _encode(self, texts: list[str]) -> np.ndarray:
        vecs = self.model.encode(texts, normalize_embeddings=True, convert_to_numpy=True,
                                 batch_size=32, show_progress_bar=False)
        return np.asarray(vecs, dtype=np.float32)

    def encode_documents(self, texts: list[str]) -> np.ndarray:
        return self._encode([self.doc_prefix + t for t in texts])

    def encode_queries(self, texts: list[str]) -> np.ndarray:
        return self._encode([self.query_prefix + t for t in texts])


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Cosine similarity between rows of ``a`` (n, d) and ``b`` (m, d) -> (n, m).
    Works for un-normalised vectors too."""
    a = np.atleast_2d(a).astype(np.float32)
    b = np.atleast_2d(b).astype(np.float32)
    a_n = a / np.clip(np.linalg.norm(a, axis=1, keepdims=True), 1e-12, None)
    b_n = b / np.clip(np.linalg.norm(b, axis=1, keepdims=True), 1e-12, None)
    return a_n @ b_n.T
