"""Weather tool — offline sample data by default, live Open-Meteo API optional.

WEATHER_MODE=offline  -> data/weather.json (works in class without internet)
WEATHER_MODE=live     -> https://open-meteo.com (free, no API key)
"""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
from pathlib import Path

from langchain.tools import tool

from config import PROJECT_ROOT, get_settings

_DATA = json.loads((PROJECT_ROOT / "data" / "weather.json").read_text(encoding="utf-8"))
_WMO = {0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast", 45: "Fog",
        51: "Light drizzle", 61: "Light rain", 63: "Rain", 65: "Heavy rain", 80: "Rain showers", 95: "Thunderstorm"}


def _live(city: str) -> str:
    q = urllib.parse.urlencode({"name": city, "count": 1})
    with urllib.request.urlopen(f"https://geocoding-api.open-meteo.com/v1/search?{q}", timeout=10) as r:
        results = json.load(r).get("results") or []
    if not results:
        return f"Error: city {city!r} not found."
    lat, lon = results[0]["latitude"], results[0]["longitude"]
    q = urllib.parse.urlencode({"latitude": lat, "longitude": lon,
                                "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"})
    with urllib.request.urlopen(f"https://api.open-meteo.com/v1/forecast?{q}", timeout=10) as r:
        cur = json.load(r)["current"]
    cond = _WMO.get(cur["weather_code"], f"code {cur['weather_code']}")
    return (f"Weather in {results[0]['name']} (live): {cond}, {cur['temperature_2m']}°C, "
            f"humidity {cur['relative_humidity_2m']}%, wind {cur['wind_speed_10m']} km/h.")


@tool(parse_docstring=True)
def get_weather(city: str) -> str:
    """Get the current weather for a city.

    Args:
        city: City name only, e.g. "Bengaluru", "Mumbai", "London".
    """
    city_key = city.strip().lower()
    if get_settings().weather_mode == "live":
        try:
            return _live(city)
        except Exception as exc:  # network down -> fall back to sample data
            fallback = f" (live API failed: {exc.__class__.__name__}; showing sample data)"
    else:
        fallback = " (sample data)"
    w = _DATA.get(city_key)
    if not w:
        return f"Error: no weather data for {city!r}. Known cities: {', '.join(c.title() for c in _DATA)}."
    return (f"Weather in {city.strip().title()}{fallback}: {w['condition']}, {w['temp_c']}°C, "
            f"humidity {w['humidity']}%, wind {w['wind_kmh']} km/h.")
