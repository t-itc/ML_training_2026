"""STEP 7 · Agentic memory: policy + automatic retrieval before every model call

    user msg ─► @dynamic_prompt: search Store ─► system prompt + memories ─► model ─► tools ─► answer
                                                                     save_memory ─► policy (evaluate) ─► Store

Run:  python -m steps.step7_agentic_memory
NEW in this step: @dynamic_prompt middleware (retrieve on every call), memory policy, updates by key, feedback lessons.
"""
from langchain.agents import create_agent
from langchain.agents.middleware import ModelRequest, dynamic_prompt
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.store.memory import InMemoryStore

from agents.prompts import TOOLS_PROMPT
from config import get_llm
from memory.long_term import UserContext
from tools import save_memory   # project version: applies the policy (no secrets) and stable keys (updates)


@dynamic_prompt
def inject_memories(request: ModelRequest) -> str:
    """Runs before EVERY model call: put this user's memories into the system prompt."""
    uid = request.runtime.context.user_id
    items = request.runtime.store.search((uid, "memories"), limit=20)
    facts = "\n".join(f"- [{i.value['category']}/{i.key}] {i.value['content']}" for i in items) or "(none)"
    return f"{TOOLS_PROMPT}\nSave durable facts with save_memory. Never store secrets.\n\n" \
           f"## What you know about this user (long-term memory)\n{facts}"


store = InMemoryStore()
agent = create_agent(get_llm(), tools=[save_memory], middleware=[inject_memories],
                     checkpointer=InMemorySaver(), store=store, context_schema=UserContext)


def chat(text: str, thread: str) -> str:
    out = agent.invoke({"messages": [{"role": "user", "content": text}]},
                       {"configurable": {"thread_id": thread}}, context=UserContext("mahesh"))
    return out["messages"][-1].content


print("[1]", chat("I prefer explanations with Python examples.", "t1"))   # saved
print("[2]", chat("My password is hunter2", "t1"))                         # ignored by the policy
print("[3]", chat("Explain RAG architecture", "t2")[:160], "...")         # new thread, uses the preference
print("[4]", chat("That was too long.", "t2"))                             # feedback -> lesson
print("[5]", chat("Explain RAG architecture", "t3")[:160], "...")         # shorter + Python
print("\nStore:", [(i.key, i.value["content"]) for i in store.search(("mahesh", "memories"))])
