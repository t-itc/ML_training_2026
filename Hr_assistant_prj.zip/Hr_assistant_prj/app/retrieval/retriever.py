"""Retrieval with server-side authorization.

Two independent checks (defence in depth):
  1. Pre-filter: the vector query only searches chunks whose ACL metadata matches the caller's roles.
  2. Post-filter: every hit is re-checked against catalog.json (the source of truth). A hit that fails
     here means the index is stale or tampered -> dropped and counted (acl_violations) for alerting.
The caller's roles come from the authenticated principal, never from the request body.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from app.config import get_policy, get_settings
from app.retrieval.embeddings import get_embedder
from app.retrieval.store import ROLES, get_collection, is_authorized, load_catalog


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    title: str
    section: str
    text: str
    similarity: float


@dataclass
class RetrievalResult:
    chunks: list[Chunk] = field(default_factory=list)
    candidates: int = 0
    below_threshold: int = 0
    acl_violations: int = 0

    @property
    def doc_ids(self) -> list[str]:
        return sorted({c.doc_id for c in self.chunks})


def acl_where(roles: list[str]) -> dict:
    conds = [{f"acl_{r}": True} for r in roles if r in ROLES]
    if not conds:
        raise PermissionError("Principal has no known role")
    return conds[0] if len(conds) == 1 else {"$or": conds}


def retrieve(query: str, roles: list[str], top_k: int | None = None) -> RetrievalResult:
    pol = get_policy()["retrieval"]
    top_k = top_k or pol["top_k"]
    col = get_collection()
    res = col.query(query_embeddings=[get_embedder().embed_query(query)], n_results=top_k,
                    where=acl_where(roles), include=["documents", "metadatas", "distances"])
    catalog = load_catalog()
    out = RetrievalResult()
    for cid, text, meta, dist in zip(res["ids"][0], res["documents"][0], res["metadatas"][0], res["distances"][0]):
        out.candidates += 1
        doc = catalog.get(meta["doc_id"])
        if doc is None or not is_authorized(roles, doc):
            out.acl_violations += 1
            continue
        sim = round(1 - dist, 4)
        if sim < pol["min_similarity"][get_settings().embedder]:
            out.below_threshold += 1
            continue
        out.chunks.append(Chunk(cid, meta["doc_id"], meta["title"], meta["section"], text, sim))
    return out
