"""HTTP layer: schema, size limits, authentication, approvals workflow."""
import json
import os
from pathlib import Path


def test_valid_request(client, auth):
    r = client.post("/v1/chat", json={"message": "How many leave days can I carry forward?", "session_id": "s-1"},
                    headers=auth("ravi"))
    body = r.json()
    assert r.status_code == 200 and body["status"] == "answered" and body["citations"]
    assert body["request_id"] and body["policy_version"] and body["telemetry"]["mode"] in ("langfuse", "fallback")


def test_request_id_header_is_used(client, auth):
    r = client.post("/v1/chat", json={"message": "What is my leave balance?"}, headers=auth("ravi") | {"X-Request-ID": "abc-123"})
    assert r.json()["request_id"] == "abc-123"


def test_message_length_limit_422(client, auth):
    assert client.post("/v1/chat", json={"message": "a" * 2001}, headers=auth("ravi")).status_code == 422
    assert client.post("/v1/chat", json={"message": "   "}, headers=auth("ravi")).status_code == 422


def test_body_size_limit_413(client, auth):
    r = client.post("/v1/chat", content=b'{"message": "' + b"a" * 9000 + b'"}',
                    headers=auth("ravi") | {"content-type": "application/json"})
    assert r.status_code == 413


def test_unknown_fields_rejected_no_role_injection(client, auth):
    r = client.post("/v1/chat", json={"message": "What is the salary range for band E5?", "roles": ["hr_admin"]},
                    headers=auth("ravi"))
    assert r.status_code == 422


def test_control_characters_rejected(client, auth):
    assert client.post("/v1/chat", json={"message": "leave\x00policy"}, headers=auth("ravi")).status_code == 422


def test_bad_session_id_rejected(client, auth):
    assert client.post("/v1/chat", json={"message": "leave policy", "session_id": "../etc"}, headers=auth("ravi")).status_code == 422


def test_authentication_required(client):
    assert client.post("/v1/chat", json={"message": "leave"}).status_code == 401
    assert client.post("/v1/chat", json={"message": "leave"}, headers={"Authorization": "Bearer nope"}).status_code == 401


def test_approvals_require_hr_admin(client, auth):
    assert client.get("/v1/approvals", headers=auth("ravi")).status_code == 403
    assert client.get("/v1/approvals", headers=auth("priya")).status_code == 403
    assert client.get("/v1/approvals", headers=auth("anita")).status_code == 200


def test_high_impact_tool_waits_for_human_and_executes_once(client, auth):
    r = client.post("/v1/chat", json={"message": "Please apply for leave from 2026-12-14 to 2026-12-18."}, headers=auth("ravi")).json()
    assert r["status"] == "pending_approval"
    aid = r["approval_id"]
    log = Path(os.environ["APPROVALS_DB"]).with_name("executed_actions.jsonl")
    before = log.read_text().count(aid) if log.exists() else 0
    assert before == 0, "nothing may execute before approval"
    item = next(a for a in client.get("/v1/approvals", headers=auth("anita")).json() if a["id"] == aid)
    assert item["tool"] == "submit_leave_request" and item["arguments"]["start"] == "2026-12-14"

    ok = client.post(f"/v1/approvals/{aid}/decision", json={"decision": "approve", "comment": "ok"}, headers=auth("anita"))
    assert ok.status_code == 200 and ok.json()["status"] == "approved"
    again = client.post(f"/v1/approvals/{aid}/decision", json={"decision": "approve"}, headers=auth("anita"))
    assert again.status_code == 409
    entries = [json.loads(l) for l in log.read_text().splitlines() if aid in l]
    assert len(entries) == 1 and entries[0]["employee_id"] == "E1001" and entries[0]["approved_by"] == "E3001"


def test_cannot_approve_own_request(client, auth):
    r = client.post("/v1/chat", json={"message": "Please update my bank details."}, headers=auth("anita")).json()
    assert r["status"] == "pending_approval"
    d = client.post(f"/v1/approvals/{r['approval_id']}/decision", json={"decision": "approve"}, headers=auth("anita"))
    assert d.status_code == 403


def test_rejected_request_is_not_executed(client, auth):
    r = client.post("/v1/chat", json={"message": "Please update my bank details."}, headers=auth("ravi")).json()
    d = client.post(f"/v1/approvals/{r['approval_id']}/decision", json={"decision": "reject"}, headers=auth("anita"))
    assert d.json()["status"] == "rejected"
    log = Path(os.environ["APPROVALS_DB"]).with_name("executed_actions.jsonl")
    assert not log.exists() or r["approval_id"] not in log.read_text()


def test_review_route_creates_review_item(client, auth):
    r = client.post("/v1/chat", json={"message": "I am being bullied by my team lead."}, headers=auth("ravi")).json()
    assert r["status"] == "review" and r["approval_id"]
    items = client.get("/v1/approvals", headers=auth("anita")).json()
    assert any(i["id"] == r["approval_id"] and i["kind"] == "review" for i in items)


def test_health(client):
    h = client.get("/healthz").json()
    assert h["index_chunks"] > 0 and h["policy_version"] and h["prompt_version"]
