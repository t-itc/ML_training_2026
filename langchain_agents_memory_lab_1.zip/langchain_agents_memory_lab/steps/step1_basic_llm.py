"""STEP 1 · Basic LLM call (no agent yet)

    you ──► LLM ──► answer            one call, no tools, no memory

Run:  python -m steps.step1_basic_llm
NEW in this step: a chat model and messages.
"""
from langchain.messages import HumanMessage, SystemMessage

from config import describe_llm, get_llm

llm = get_llm()                                   # ChatOllama / ChatOpenAI / mock (from .env)
print("Model:", describe_llm())

messages = [
    SystemMessage("You are a concise assistant."),          # behaviour
    HumanMessage("In one sentence: what is an AI agent?"),  # the question
]
reply = llm.invoke(messages)                      # ONE request, ONE response

print("Type  :", type(reply).__name__)             # AIMessage
print("Answer:", reply.content)
print("Tokens:", reply.usage_metadata)            # input/output token counts
