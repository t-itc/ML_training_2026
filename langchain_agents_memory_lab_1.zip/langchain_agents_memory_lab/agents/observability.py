"""Observability — see what the agent did: model calls, tool calls, errors, tokens and latency.

AgentTracer is a plain LangChain callback handler (works offline).
get_callbacks() also adds Langfuse automatically when LANGFUSE_* keys are set
(see the Guardrails + Langfuse session). LangSmith needs no code: set LANGSMITH_TRACING=true.
"""
from __future__ import annotations

import os
import time
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler


class AgentTracer(BaseCallbackHandler):
    def __init__(self, echo: bool = True):
        self.echo = echo
        self.events: list[dict] = []
        self._starts: dict[Any, float] = {}
        self.t0 = time.perf_counter()

    # ---- helpers
    def _log(self, kind: str, **data):
        data = {"t_ms": round((time.perf_counter() - self.t0) * 1000), "kind": kind, **data}
        self.events.append(data)
        if self.echo:
            detail = " ".join(f"{k}={v}" for k, v in data.items() if k not in {"t_ms", "kind"})
            print(f"   [{data['t_ms']:>6} ms] {kind:<11} {detail}")

    # ---- model
    def on_chat_model_start(self, serialized, messages, *, run_id, **kw):
        self._starts[run_id] = time.perf_counter()

    def on_llm_end(self, response, *, run_id, **kw):
        ms = round((time.perf_counter() - self._starts.pop(run_id, time.perf_counter())) * 1000)
        msg = getattr(response.generations[0][0], "message", None)
        usage = (getattr(msg, "usage_metadata", None) or {}) if msg else {}
        calls = [tc["name"] for tc in (getattr(msg, "tool_calls", None) or [])]
        self._log("llm", ms=ms, in_tok=usage.get("input_tokens", "?"), out_tok=usage.get("output_tokens", "?"),
                  decision=("call " + ",".join(calls)) if calls else "final answer")

    # ---- tools
    def on_tool_start(self, serialized, input_str, *, run_id, **kw):
        self._starts[run_id] = time.perf_counter()
        self._log("tool_start", tool=(serialized or {}).get("name", "?"), input=str(input_str)[:70])

    def on_tool_end(self, output, *, run_id, **kw):
        ms = round((time.perf_counter() - self._starts.pop(run_id, time.perf_counter())) * 1000)
        text = getattr(output, "content", output)
        status = "ERROR" if str(text).startswith("Error") else "ok"
        self._log("tool_end", ms=ms, status=status, output=str(text)[:70].replace("\n", " "))

    def on_tool_error(self, error, *, run_id, **kw):
        self._log("tool_error", error=f"{type(error).__name__}: {error}"[:90])

    # ---- summary
    def summary(self) -> dict:
        llm = [e for e in self.events if e["kind"] == "llm"]
        tools = [e for e in self.events if e["kind"] == "tool_end"]
        tok = lambda k: sum(e[k] for e in llm if isinstance(e[k], int))  # noqa: E731
        return {
            "llm_calls": len(llm), "tool_calls": len(tools),
            "tool_errors": sum(e["status"] == "ERROR" for e in tools) + sum(e["kind"] == "tool_error" for e in self.events),
            "input_tokens": tok("in_tok"), "output_tokens": tok("out_tok"),
            "llm_ms": sum(e["ms"] for e in llm), "tool_ms": sum(e["ms"] for e in tools),
            "total_ms": round((time.perf_counter() - self.t0) * 1000),
        }


def get_callbacks(echo: bool = True) -> list:
    cbs: list = [AgentTracer(echo=echo)]
    if os.getenv("LANGFUSE_PUBLIC_KEY") and os.getenv("LANGFUSE_SECRET_KEY"):
        try:
            from langfuse.langchain import CallbackHandler  # pip install langfuse

            cbs.append(CallbackHandler())
        except ImportError:
            print("   (langfuse not installed — pip install langfuse to send traces)")
    return cbs
