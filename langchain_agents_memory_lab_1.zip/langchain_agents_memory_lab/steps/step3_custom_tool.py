"""STEP 3 · One custom tool with @tool

    you ──► model ──(tool_calls)──► tools: calculator ──(ToolMessage)──► model ──► answer

Run:  python -m steps.step3_custom_tool
NEW in this step: @tool, docstring = description for the LLM, the tool-calling loop.
"""
from langchain.agents import create_agent
from langchain.tools import tool

from config import get_llm
from tools.calculator import safe_eval   # evaluates arithmetic via Python's AST — never eval() on LLM output


@tool
def calculator(expression: str) -> str:
    """Evaluate an arithmetic expression such as '250 * 12'. Use it for ANY math."""
    if not expression.strip():                    # input validation
        return "Error: empty expression."
    try:
        return f"{expression} = {safe_eval(expression):,}"
    except ZeroDivisionError:
        return "Error: division by zero."         # expected errors are RETURNED so the LLM can explain them
    except (ValueError, SyntaxError) as exc:
        return f"Error: {exc}"


agent = create_agent(get_llm(), tools=[calculator],
                     system_prompt="You are Aria. Always use the calculator for arithmetic.")
result = agent.invoke({"messages": [{"role": "user", "content": "What is 250 multiplied by 12?"}]})

for m in result["messages"]:                      # human -> ai(tool_calls) -> tool -> ai(answer)
    detail = m.tool_calls if m.type == "ai" and m.tool_calls else m.content
    print(f"   {m.type:>6}: {detail}")
