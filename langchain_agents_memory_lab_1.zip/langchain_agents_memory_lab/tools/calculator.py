"""Calculator tool — safe arithmetic with Python's AST (never eval())."""
from __future__ import annotations

import ast
import math
import operator

from langchain.tools import tool

_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos,
}
_FUNCS = {"sqrt": math.sqrt, "round": round, "abs": abs, "log": math.log, "pi": math.pi}


def safe_eval(expression: str) -> float:
    """Evaluate +, -, *, /, //, %, ** and sqrt/round/abs/log on numbers only."""
    expression = expression.replace("^", "**").replace("×", "*").replace("÷", "/").replace(",", "")

    def _eval(node):
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            left, right = _eval(node.left), _eval(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 100:
                raise ValueError("exponent too large")
            return _OPS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.operand))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUNCS:
            return _FUNCS[node.func.id](*[_eval(a) for a in node.args])
        if isinstance(node, ast.Name) and node.id == "pi":
            return math.pi
        raise ValueError(f"unsupported expression element: {ast.dump(node)[:40]}")

    return _eval(ast.parse(expression.strip(), mode="eval"))


def _fmt(x: float) -> str:
    if isinstance(x, float) and x.is_integer():
        x = int(x)
    return f"{x:,}" if isinstance(x, int) else f"{x:,.6g}"


@tool(parse_docstring=True)
def calculator(expression: str) -> str:
    """Evaluate a math expression and return the exact result.

    Use for ANY arithmetic instead of calculating in your head.

    Args:
        expression: Python-style arithmetic, e.g. "250 * 12", "(45 + 5) / 2", "sqrt(144)", "2 ** 10".
    """
    try:
        return f"{expression} = {_fmt(safe_eval(expression))}"
    except ZeroDivisionError:
        return "Error: division by zero. Ask the user for a valid divisor."
    except (ValueError, SyntaxError, TypeError) as exc:
        return f"Error: could not evaluate {expression!r} ({exc}). Use digits and + - * / ** ( )."
